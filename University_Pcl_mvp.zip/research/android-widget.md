# Android 桌面组件与后台刷新技术调研（University_Pcl）

> 目标：Redmi K80 / HyperOS 4.0.3 上的 4×2 桌面组件，固定 5 行显示当天 5 大节（节次 + 课程名 + 地点 + 教师，空课留空），数据来自教务系统，账号密码本地保存。
> 调研日期 2026-11，以官方文档为准；标注「需实测」的条目必须真机验证。

## 0. 结论速览

1. **组件实现选 Jetpack Glance**（`glance-appwidget` 1.1.x 稳定线）。5 行是固定结构，**不需要** `ListView`/`RemoteViewsService`，Glance 的 `Column + 5×Row` 即可；退路是传统 `AppWidgetProvider + RemoteViews` 的静态 5 行 include 布局。
2. **刷新别指望 `updatePeriodMillis`**：最小 30 分钟（1,800,000 ms）且休眠时被跳过；正确组合是 `updatePeriodMillis=0` + WorkManager 周期任务（≥15 分钟，Doze 下延迟）+ 「午夜跨天」定点刷新 + 点击组件/打开 App 兜底刷新。课表 5 行一天只在跨天和教务数据变化时改变，**不需要**高频刷新。
3. **HyperOS/MIUI 是最大风险**：自启动白名单、省电策略「无限制」、最近任务上锁三项都可能被系统默认关闭，后台任务会被冻结（需实测 + 引导页）。
4. **凭据**：`EncryptedSharedPreferences` 已废弃，用 Android Keystore 直存（或 DataStore + Tink）；教务系统 HTTPS/自签证书与验证码登录是**最大的不确定性，需实测**。
5. **构建**：本机（proot、无 JDK/SDK）**不能**构建 APK，结论只能是「电脑 Android Studio 或 GitHub Actions CI」。

## 1. 组件实现路径：RemoteViews vs Glance

### 1.1 RemoteViews 的能力边界

- 只支持 @RemoteView 的子集，**不能放自定义 View、Compose、WebView、RecyclerView**：
  - 布局：`FrameLayout`、`LinearLayout`、`RelativeLayout`、`GridLayout`
  - 控件：`AnalogClock`、`Button`、`Chronometer`、`ImageButton`、`ImageView`、`ProgressBar`（仅确定进度）、`TextView`、`ViewFlipper`、`ListView`、`GridView`、`StackView`、`AdapterViewFlipper`；Android 12+ 增加 `CheckBox`/`Switch`/`RadioButton`（互动组件）[官方 layouts](https://developer.android.com/develop/ui/views/appwidgets/layouts)
- 动态集合三选一：① `ListView`/`GridView` + `RemoteViewsService`/`RemoteViewsFactory`（跨进程 binder，成本高）② Android 12+ `RemoteViews.RemoteCollectionItems` ③ 固定行静态布局 [collections](https://developer.android.com/develop/ui/views/appwidgets/collections)
- 尺寸：`minWidth/minHeight` 用 `70 × n − 30` dp 估算（2 格 ≈110dp、4 格 ≈250dp），Android 12+ 更推荐 `targetCellWidth/targetCellHeight`，由 launcher 决定实际网格（K80 桌面网格 **需实测**）[layouts](https://developer.android.com/develop/ui/views/appwidgets/layouts)

### 1.2 Glance 现状

- Compose 风格 API，1.0 稳定（2024）、**1.1.0 / 1.1.1 为当前稳定线**、1.2.0-beta01 已发布（版本号以 [release notes](https://developer.android.com/jetpack/androidx/releases/glance) 为准）；`androidx.glance:glance-appwidget`，**minSdk 21**（建议仍设 26+）。
- 支持 `Text`、`Image`、`Box/Row/Column`、`Spacer`、`Button`、进度条、`LazyColumn`（纵向列表，横向 `LazyRow` 不支持）、`actionStartActivity`/`actionRunCallback` 点击。仍受 RemoteViews 底层限制（无自定义绘制、动画有限、渲染有延迟）[Glance 文档](https://developer.android.com/develop/ui/compose/glance)
- 优点：Kotlin 代码即 UI，无 XML 与 `RemoteViews` 桥接，5 行课表用 `Column{ row { Text×4 } }` 十几行搞定；支持 `GlanceAppWidget` + `GlanceAppWidgetReceiver` 的 `stateDefinition`（比 RemoteViews 少写样板）。
- 缺点：mapping 层偶发兼容问题（尤其厂商 launcher）、首帧渲染慢于 RemoteViews、依赖 Compose runtime（APK 约 +1~2 MB）。

### 1.3 结论（明确）

**选 Glance。** 理由：5 行固定行不触发集合限制，代码量与维护成本最低；若后续要支持「本周/更多节次」滚动，Glance 的 `LazyColumn` 是唯一低成本路径。风险等级：中（HyperOS 渲染兼容需实测）。若实测发现 HyperOS 4 上 Glance 组件白屏/不刷新，退化方案 = 传统 `AppWidgetProvider + RemoteViews` + 5 行静态布局（不引入 `ListView`）。

## 2. 更新机制与尺寸

| 机制 | 最小/约束 | 适用场景 | 备注 |
|---|---|---|---|
| `updatePeriodMillis` | **最小 30 分钟**（1,800,000 ms，低于该值被系统抬到 30 min） | 低频兜底 | 官方 [AppWidgetProviderInfo](https://developer.android.com/reference/android/appwidget/AppWidgetProviderInfo)；**任务书里的 300000 ms（5 分钟）不成立**；Doze 下更新被跳过 |
| WorkManager 周期任务 | **≥15 分钟**（`PeriodicWorkRequest`），实际受 Doze/厂商限制 | 定时拉取教务数据 | [PeriodicWorkRequest](https://developer.android.com/reference/androidx/work/PeriodicWorkRequest)、[Doze 文档](https://developer.android.com/develop/background-work/background-tasks/scheduling/doze-standby)；重启后自动恢复，无需 BOOT_COMPLETED |
| AlarmManager 精确闹钟 | `setExact*` 需 `SCHEDULE_EXACT_ALARM`（Android 12+ 默认不给新装应用） | 不推荐用于课表 | Doze 下 `setExactAndAllowWhileIdle` 也会被延迟（约 9~15 分钟级，需实测）；用 `USE_EXACT_ALARM` 有商店政策风险 |
| 组件点击 → Activity | `PendingIntent.getActivity` + `setOnClickPendingIntent`（RemoteViews）/ `actionStartActivity`（Glance） | 打开 App、进入登录或手动刷新 | **Android 15+ BAL 限制**：targetSdk 35 时 PendingIntent 拉起 Activity 默认可能被拦，需 `ActivityOptions.setPendingIntentBackgroundActivityStartMode(...)` 或验证系统 launcher 放行——**需实测**（见 §4） |
| 删除/重建 | `onDeleted()`/`onRestored()`（API 21+）、`onEnabled/onDisabled` | 清理 WorkManager、重建状态 | 组件被删需取消周期任务，否则白耗电；重建后 `onUpdate` 会重发 |

**推荐刷新策略（组合拳）**：
- `updatePeriodMillis = 0`（交给代码控制），`initialLayout` 先渲染占位。
- 跨天刷新：每天 00:05 的 `OneTimeWorkRequest`（`initialDelay` 到下一个零点），每次成功后重新排下一天；比精确闹钟省权限、Doze 下通常 15 分钟内补跑。
- 兜底刷新：① 用户点击组件打开 App 时立即刷新；② 组件内放「刷新」小按钮（`actionRunCallback`）；③ App 内下拉/手动刷新；④ 教务数据「周次」变化时（周一）强制刷新。
- 数据变化不频繁 → 不建议 15 分钟周期轮询教务系统（有风控/限流与耗电风险），周期任务建议 6~12 小时 + 事件触发。

## 3. HyperOS / MIUI 厂商后台限制（最大风险）

- **自启动**：第三方应用默认关闭，重启后后台任务/广播不执行。设置路径：设置 → 应用设置 → 应用管理 → University_Pcl → 自启动（需实测 HyperOS 4 路径）。
- **省电策略**：默认「智能限制」会在息屏后冻结进程，WorkManager 被推迟到打开 App 才跑；需引导用户改为「无限制」（或「不限制后台」）。
- **最近任务上锁**：多任务卡片下拉加锁可降低被清理概率（需实测）。
- **组件刷新被冻结**：HyperOS launcher 对第三方组件有缓存/节流，`RemoteViews` 更新可能延迟到下次亮屏；社区报告 Xiaomi Launcher 拦截组件刷新与 Digital Wellbeing（[Xiaomi 社区报告](https://it.xiaomi-miui.gr/hyperos-widgets-pagonoun-xiaomi-launcher-digital-wellbeing/)），第三方日程应用在 Xiaomi 上需手动加自启动/省电白名单（[aCalendar 支持页](https://acalendar.tapirapps.de/en/support/solutions/articles/36000105446/thumbs_down)）。
- **通知权限（Android 13+ `POST_NOTIFICATIONS`）**：仅影响通知与前台服务可见性；前台服务在 HyperOS 上并不能保证不被杀，不建议依赖。
- **规避方案（工程侧）**：WorkManager（系统会尽量恢复）+ 打开 App 兜底刷新 + 组件点击刷新 + App 内「保活引导页」跳转设置（可考虑 `ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`，但商店政策敏感；自签名分发可接受）。
- **需实测清单**：HyperOS 4 设置页路径、息屏 30 分钟后 WorkManager 是否执行、组件更新是否延迟、杀进程后组件是否还响应点击、是否需「允许后台弹出界面」。

## 4. 凭据安全与网络

- **存储**：`androidx.security:security-crypto`（EncryptedSharedPreferences/EncryptedFile）**已被标记废弃**（1.1.0-alpha07 起，官方建议迁出），[API 参考](https://developer.android.com/reference/androidx/security/crypto/package-summary)。推荐：
  - 方案 A（推荐）：Android Keystore 生成 AES-GCM 密钥 → 加密后写 DataStore/普通 SharedPreferences（[Keystore 文档](https://developer.android.com/privacy-and-security/keystore)）；
  - 方案 B：DataStore + Tink（Google 官方迁移方向）。
  - 无论哪种，Keystore 需要 API 23+；**不要**明文存密码，也**不要**在组件 RemoteViews 里放账号信息。
- **明文 HTTP**：Android 9（API 28）起默认禁止 cleartext，教务系统若是 `http://` 必须配置 `networkSecurityConfig`（`cleartextTrafficPermitted` 仅对该域名开启），并避免全局放开。[网络安全配置](https://developer.android.com/privacy-and-security/security-config)
- **校园网自签证书**：优先确认教务系统是否有合法证书；若无，选项 ① 把学校 CA 打进 `res/raw` 并在 `networkSecurityConfig` 中 `trust-anchors` 引用（仅限该域名）② 允许用户 CA（`<certificates src="user"/>`，需用户手动装证书）③ 证书固定（pinning）+ 明确的失败提示。**绝不**在 release 包里 `trustAllCerts`/`HostnameVerifier` 全放开。
- **登录态**：教务系统多为 Cookie/Session + 可能验证码/二次验证。组件不能弹登录界面，必须「后台可静默续登」才能自动刷新；若必须验证码 → 组件显示「登录已过期，点击打开 App」，**需实测目标教务系统**。
- **Doze 下联网**：后台任务在 Doze 维护窗口才联网，失败要指数退避重试，不能假设实时。

## 5. 推荐技术栈 / minSdk / 权限

- **技术栈**：Kotlin + Jetpack Compose（App 主界面）+ **Glance**（组件）+ OkHttp/Retrofit + kotlinx.serialization + Room（课表缓存）/ DataStore（设置与凭据密文）+ WorkManager（刷新与跨天）+ Hilt（可选）。APK 体积：Compose App ≈ 6~9 MB，引入 Glance 再 +1~2 MB（含 Compose runtime），可接受。
- **minSdk**：HyperOS 4 对应 Android 版本 **需实测**（社区推断为 Android 16；K80 出厂 HyperOS 2 = Android 15）。建议 `minSdk 26`（覆盖 Android 8.0+，避开旧机型兼容坑，且满足 Keystore 需求）、`targetSdk 35`（Play 政策要求；若要上 Play 未来需 36）、`compileSdk 35/36`。
- **权限清单**：
  - `INTERNET`、`ACCESS_NETWORK_STATE`（联网）
  - `RECEIVE_BOOT_COMPLETED`（仅当自己写 BOOT receiver；WorkManager 可省）
  - `POST_NOTIFICATIONS`（Android 13+，有通知/前台服务时）
  - `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_DATA_SYNC`（若坚持前台服务；**建议不用**）
  - `SCHEDULE_EXACT_ALARM`（**不建议**）；`REQUEST_IGNORE_BATTERY_OPTIMIZATIONS`（可选，引导页用）
  - 组件声明：`<receiver android:exported="false">` + `APPWIDGET_UPDATE` intent-filter + `android.appwidget.provider` meta-data + `<uses-feature android:name="android.software.app_widgets" android:required="false"/>`
- **Android 15/16 新限制**：targetSdk 35+ 前台服务必须声明类型且 `dataSync` 每 24h 限 6 小时、`BOOT_COMPLETED` 不能启动部分 FGS（[FGS 后台启动限制](https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start)）；BAL 收紧影响 PendingIntent 拉起 Activity（组件点击需实测）；Android 16 继续收紧 Job/Work 配额与 FGS。**组件本身在 15/16 无破坏性变更，但 targetSdk 越高越要真机回归**（[15 行为变更](https://developer.android.com/about/versions/15/behavior-changes-15)、[16 行为变更](https://developer.android.com/about/versions/16/behavior-changes-16)）。

## 6. 本机能否构建 APK？

**结论：不能，需电脑 Android Studio 或 GitHub Actions CI。**
- 依据：本机为 Ubuntu 24.04 proot（arm64）、无 JDK、无 Android SDK；Gradle/AGP 需 JDK 17+、SDK Platform + build-tools（aapt2 官方以 x86_64 为主，arm64 支持不完整）；proot 下 Gradle daemon/文件锁不稳定，内存与磁盘也吃紧。
- **GitHub Actions 要点**：`ubuntu-latest` 自带 Android SDK 与 Temurin JDK → `actions/setup-java@v4`（17/21）+ `actions/cache` 缓存 Gradle → `./gradlew assembleDebug` → `actions/upload-artifact` 取 APK；release 签名把 keystore 以 base64 存 Secrets（`KEYSTORE_BASE64`/`STORE_PASSWORD`/`KEY_ALIAS`/`KEY_PASSWORD`），在 CI 里解码并用环境变量注入 `signingConfig`；tag 触发发版、`versionCode` 自增；私有仓库免费 2000 min/月，公开仓库免费。
- 手机侧安装需允许「安装未知应用」；组件与 App 同一次构建，无额外步骤。

## 7. 风险清单（按严重度）

| 风险 | 影响 | 对策 | 状态 |
|---|---|---|---|
| HyperOS 后台冻结 WorkManager | 课表不自动更新 | 引导自启动+省电白名单；打开 App/点组件兜底 | 需实测 |
| 教务系统验证码/风控 | 无法静默续登 | 组件显示过期状态，点击进 App 登录 | **需实测** |
| 自签证书/明文 HTTP | 接口不可用 | networkSecurityConfig 定向放开 + CA 打包 | 需实测 |
| Android 15+ PendingIntent BAL | 点击组件打不开 App | ActivityOptions 允许后台启动 / 真机验证 | 需实测 |
| Glance 在 HyperOS 渲染异常 | 组件白屏 | 退化 RemoteViews 静态 5 行 | 需实测 |
| `updatePeriodMillis` 5 分钟不可行 | 刷新不及时 | 改用 WorkManager + 事件刷新 | 已确认 |

## 8. 官方参考

- App Widgets 总览：https://developer.android.com/develop/ui/views/appwidgets/overview
- 组件布局与尺寸：https://developer.android.com/develop/ui/views/appwidgets/layouts
- 集合组件：https://developer.android.com/develop/ui/views/appwidgets/collections
- 组件更新：https://developer.android.com/develop/ui/views/appwidgets/update
- 组件交互：https://developer.android.com/develop/ui/views/appwidgets/interact-with-widgets
- Jetpack Glance：https://developer.android.com/develop/ui/compose/glance
- Glance 版本：https://developer.android.com/jetpack/androidx/releases/glance
- PeriodicWorkRequest：https://developer.android.com/reference/androidx/work/PeriodicWorkRequest
- Doze/App Standby：https://developer.android.com/develop/background-work/background-tasks/scheduling/doze-standby
- 网络安全配置：https://developer.android.com/privacy-and-security/security-config
- Keystore：https://developer.android.com/privacy-and-security/keystore

# 山东科技大学教务系统接口调研（强智 V8，非正方）

> 结论先行：**技术上可行**。但前提必须修正——`jwglxt.sdust.edu.cn` 不是正方教务，而是**湖南强智科技 V8 新L（newL）**，走 `/jsxsd/` 路径。登录为「种子码 + 字符插入编码 + 验证码」，课表为 HTML 表格解析。开源有可直接复用的同校实现（山科小站 SHST-ULTRA，2026-11 仍在更新）。最大风险是**登录验证码**与**学期/周次来源**。
> 调研日：2026-11-26；只做了匿名只读 GET，未做任何登录尝试。

## 0. 版本判定（事实，高置信度）

| 证据 | 内容 |
|---|---|
| 登录页 footer | `Copyright © 2020.湖南强智科技发展有限公司`（[登录页](https://jwglxt.sdust.edu.cn/jsxsd/)） |
| 前端技术 | `/assets_newL/` 前缀 + layui，页面含 `htmlx` 后缀，是强智 2020 后「新L」学生端 |
| 正方路径 | `/xtgl/login_slogin.html`、`/xtgl/login_getPublicKey.html` 均 **404**（强智 404 页） |
| 学生端路径 | `/jsxsd/`、`/jsxsd/framework/xsMainV.htmlx`、`/jsxsd/xskb/xskb_list.do` 均 200（未登录=登录页） |
| 验证码接口 | `GET /verifycode.servlet` → 200 `image/jpeg`，存在且匿名可取 |
| 智校园 JSON 接口 | `GET /app.do?method=authUser|getKbcxAzc|getXnxq` → 200 强智错误页「用户没有登录，请重新登录！」；`/app/app.ashx` → 404 |
| 老域名 | `jwgl.sdust.edu.cn`（SHST 代码里用的 host）从当前网络 **502**（WAF/下线），`jwglxt` 上 `/jsxsd/` 可用 → 直接以 `jwglxt` 为准 |
| 账号范围 | 山科小站登录页提示「强智教务系统只对本科生开放，研究生暂时无法登录」— 见 [SHST-ULTRA](https://github.com/SHST-SDUST/SHST-ULTRA) |
| 其他登录方式 | 微信扫码登录、滑块 rail、USBKey 加密狗（桌面端用，App 可忽略） |

**给产品的影响**：URL 自填的默认值应是 `https://jwglxt.sdust.edu.cn`，适配类型选「强智（新L）」，不要选「正方」。

## 1. 登录流程（两条，需真机二选一验证）

### 路线 A：新L 表单 `/Logon.do`（Lead 实测页面 JS；置信度高）
1. `GET /` → 拿 `JSESSIONID` Cookie。
2. `POST /Logon.do?method=logon&flag=sess` → 返回 `scode#sxh`，如 `xDMHt381...Z5#1221111232...`。
3. 本地编码：`code = 账号 + "%%%" + 密码`；对 `i<55` 的每个字符，`encoded += code[i] + scode[0:digit(sxh[i])]`，然后 `scode = scode[digit:]`；`i>=55` 直接拼剩余。
4. `POST /Logon.do?method=logon`，`application/x-www-form-urlencoded`：
   `loginMethod=logon&userAccount=<学号>&userPassword=&userlanguage=0&encoded=<上一步结果>`（密码字段必须置空）。
5. 成功标志：HTTP 302 → `/jsxsd/framework/xsMainV.htmlx`。

> 佐证（通用强智，[skkk.uno 2026-03 逆向博客](https://skkk.uno/2026/03/30/%E5%85%B3%E4%BA%8E%E5%AD%A6%E6%A0%A1%E5%BC%BA%E6%99%BA%E6%95%99%E5%8A%A1%E7%B3%BB%E7%BB%9F%E7%9A%84%E7%99%BB%E5%BD%95%E6%B5%81%E7%A8%8B%E8%A7%A3%E6%9E%90/)）流程与提交字段一致，但该文阈值是 `i<20`，且明确列出 `RANDOMCODE`（验证码）字段——**阈值 20/55 属于强智版本差异，SDUT 以页面 JS 实测的 55 为准**。

### 路线 B：`/jsxsd/xk/LoginToXk`（同校最新开源实现；置信度高）
- 请求：`POST /jsxsd/xk/LoginToXk`，form 字段 `encoded = base64(账号) + "%%%" + base64(密码)`，`RANDOMCODE = 验证码`。
- 先 `GET /jsxsd/verifycode.servlet` 取验证码图（62×22 JPG；SHST 的 OCR 字典仅含 `1 2 3 b c m n v x z`）。
- 成功判定：`302`，或响应体含 `calender_user_schedule` / `TopUserSetting`；失败响应里 `<font>` 内文字含 `!!` 即验证码错。
- 来源：[SHST-ULTRA login/model.ts](https://github.com/SHST-SDUST/SHST-ULTRA/blob/master/src/pages/plus/login/model.ts)（仓库 `pushed_at` = 2026-11-14）。

**验证码是最大分歧点**：登录页可见表单没有验证码输入框，但 `/verifycode.servlet` 存在、路线 B 与逆向博客都必须带 `RANDOMCODE`。→ 真机确认（见第 6 节第 1 条）。合规底线：**不要做自动识别验证码**，App 应弹图让用户手输。

## 2. 课表接口（主方案，HTML 解析）

请求（同校最新实现）：`GET /jsxsd/xskb/xskb_list.do?week=<周次>&term=<2025-2026-1>`，需带登录后的 `JSESSIONID` Cookie，默认 `content-type: x-www-form-urlencoded`（[timetable/model.ts](https://github.com/SHST-SDUST/SHST-ULTRA/blob/master/src/pages/plus/study/timetable/model.ts)）。
`term` 形如 `YYYY-YYYY-1|2`；另有老版参数 `xnxq01id`（学期）+`zc`（周次），适配其他学校时要做参数回退。

解析规则（[parser.ts](https://github.com/SHST-SDUST/SHST-ULTRA/blob/master/src/pages/plus/study/timetable/parser.ts)）：
1. 正则抽出所有 `<div class="kbcontent">…</div>`，**按出现顺序**编号：`day = index % 7`（0=周一 … 6=周日），`serial = index / 7`（第几行=第几个小节）。
2. 单元格内多门课用 **10 个以上 `-`** 分隔（`split(/-{10,}/)`），`&nbsp;` 开头即空课 → 桌面组件「空课留空」用这个判据。
3. 单门课字段：
   - 课程名：第一行（第一个 `<br>` 之前）
   - 教师：`<font title='老师'>…</font>`
   - 周次(节次)：`<font title='周次(节次)'>…</font>`，形如 `1-16周`、`1-8周(单)`、`1-4,6-8周`
   - 地点：`<font title='教室'>…</font>`
4. 周次字符串解析：去掉 `单/双/周/括号`，`单周`→后缀 `/1`、`双周`→后缀 `/2`；生成三种模式：`^\d+-\d+$`（连续区间）、`^\d+$`（单周次）、`^\d+-\d+/[12]$`（单双周区间），再判断「本周是否上课」。
5. 节次 → 5 大节：`1-2→大节1、3-4→2、5-6→3、7-8→4、9-10→5`（置信度中，SDUT 作息表需真机核对；若课表里出现 `3-5节` 这类合并节次，取首节所属大节）。
6. 学期/周次来源：开源实现把 `curTerm/curWeek` 放在**自己的配置里**（说明客户端拿不到），App 需自备：用户手填开学日期推算周次，或解析 `xsMainV.htmlx` 首页的学期/周次控件（待真机确认）。

## 3. 备选：智校园 App JSON 接口 `app.do`（置信度中，当前不可用）

强智对「智校园」App 开放的一套 JSON 接口，字段最省事（[SHST README](https://github.com/WindRunnerMax/SHST)、[QZAPI](https://github.com/Letki/QZAPI_Archive)、[classCrawl](https://github.com/inannan423/classCrawl)）：
- `POST/GET {root}/app.do?method=authUser&xh=&pwd=` → `token`（另有 `flag` 或 `success` 字段，因学校而异）
- `?method=getCurrentTime&currDate=` → `zc`（当前周次）、`xnxqh`（学年学期）
- `?method=getKbcxAzc&xh=&xnxqid=2025-2026-1&zc=3`（Header 带 `token`）→ JSON 数组：`kcmc` 课程名、`jsxm` 教师、`jsmc` 教室、`kssj/jssj` 起止时间、`kkzc` 教学周、`kcsj` 时间码 `x0a0b`（星期 x 第 a,b 节）、`sjbz` 单双周标记（1 单 / 2 双，推测）
- SDUT 现状：老域名 `jwgl.sdust.edu.cn/app.do` 502；`jwglxt.sdust.edu.cn/app.do` 返回「用户没有登录」页 → **要么接口关闭，要么需智校园 UA**，只能在真机上试。若可用，它比 HTML 解析稳得多，建议做成「先试 app.do，失败再回退 HTML」。

## 4. 正方 2019 新版（仅当用户把 URL 填成其他学校时用，置信度中，本次未实测）
`/xtgl/login_slogin.html` 取 `csrftoken` → `GET /xtgl/login_getPublicKey.html?time=<ms>` 取 `modulus/exponent`（base64）→ RSA(PKCS#1 v1.5) 加密密码转 base64 → `POST /xtgl/login_slogin.html` 带 `csrftoken/yhm/mm`（[CSDN 逆向+实现](https://blog.csdn.net/Koevas/article/details/88384604)）。课表 `POST /kbcx/xskbcx_cxXsKb.html?gnmkdm=N2151&su=<学号>`，参数 `xnm`（学年）、`xqm`（学期 3/12/16），返回 `kbList[]`：`kcmc` 课程、`cdmc` 地点、`xm` 教师、`xqj` 星期、`jcs` 节次 `"1-2"`、`zcd` 周次 `"1-16周"`、`xqmc` 校区。**SDUT 用不到，别按这个写默认实现。**

## 5. 安全与工程风险
- TLS/证书：`jwglxt` HTTPS 正常可取（本次无证书告警）；未发现 robots/爬虫声明（未知）。
- 凭据：账号密码只能存本机 `EncryptedSharedPreferences`/Keystore，绝不经第三方服务器；`app.do` 走 GET 明文密码，注意日志脱敏。
- 会话：依赖 `JSESSIONID`；有效期、单点互踢（和用户浏览器互踢）未知。
- 验证码：人工输入，不做 OCR/绕过；失败次数限制未知，需避免暴力重试（建议 ≤3 次/次登录）。
- 匿名只读探测未触发封禁；正式版请限频（课表 1 次/小时）。
- 网络：从外网可直接打开登录页，说明登录页**不需要校园网/VPN**（登录后功能是否限制未知）。

## 6. 必须真机 + 真实账号才能确认的未知项
1. **验证码是否每次登录必填**（页面无输入框 vs 开源实现必带 `RANDOMCODE`）——最高优先级。
2. 滑块 rail / 加密狗是否强制；微信扫码是否可替代账号登录。
3. 路径选择：`/Logon.do`（`scode/sxh`，阈值 55）与 `/xk/LoginToXk`（base64+验证码）哪个仍有效。
4. 课表接口真实参数名（`week/term` vs `xnxq01id/zc`）与 HTML 结构（`div.kbcontent` 是否仍在）。
5. 课表页/首页能否解析出**当前学期与当前周次**（决定「今天第几周」是否要用户手填）。
6. `app.do` 是否对 SDUT 开放（若开，优先用 JSON）。
7. SDUT 5 大节作息时间与「大节」划分。
8. 教师/地点字段格式（多教师、合班课、校区前缀）、实践课/停课调课的表示。
9. 会话有效期、是否与浏览器互踢、失败几次出验证码/锁号。
10. 其他学校兼容：同一套「强智」逻辑能否覆盖用户可能填的其它强智学校（参数与阈值 20/55 差异）。

## 7. 开源参考（可直接抄的部分）
| 项目 | 语言/规模 | 可复用 |
|---|---|---|
| [SHST-SDUST/SHST-ULTRA](https://github.com/SHST-SDUST/SHST-ULTRA)（2026-11 更新） | TypeScript / 5★ | **同校强智**登录、验证码图、`xskb_list.do` HTML 解析、周次解析（本文核心依据） |
| [WindRunnerMax/SHST](https://github.com/WindRunnerMax/SHST) | Java/Python/PHP / 172★ | SDUT 智校园 `app.do` JSON 接口清单 |
| [inannan423/classCrawl](https://github.com/inannan423/classCrawl) + [博客](https://jetzihan.netlify.app/blog/qiangzhi/) | Python / 15★ | `app.do` 字段语义、`kcsj` 时间码解析 |
| [Letki/QZAPI_Archive](https://github.com/Letki/QZAPI_Archive) → [TLingC/QZAPI](https://github.com/TLingC/QZAPI) | 文档 / 数十★ | 智校园接口全量字段（跨校可配） |
| [HF-CYGG/Dawn-Course](https://github.com/HF-CYGG/Dawn-Course) | Kotlin+Compose / 49★ | **同款产品架构**：Glance 桌面组件、WebView+JS 解析脚本、WorkManager 刷新、新正方/强智/青果适配 |
| [codelumos/xiaomi-aischedule-adapter](https://github.com/codelumos/xiaomi-aischedule-adapter) | JS | 强智学校小爱适配样例；[WakeUp 文档](https://i.wakeup.fun/doc/import_from_eas.html) 的教务类型判别（看 footer 公司名） |
| [WindRunnerMax/SWVerifyCode](https://github.com/WindRunnerMax/SWVerifyCode) | Python / 56★ | 仅作了解；本项目**不使用**自动破解 |

## 8. 对 University_Pcl 的落地建议
1. 适配层做成 `StrongZhiAdapter`（默认，SDUT）+ `ZhengFangAdapter`（URL 自填时可选），接口统一为 `login()/fetchWeek(term, week)`。
2. 登录只做一次：OkHttp 取 Cookie + 验证码图 → 用户输入 → 编码提交；成功后保存 Cookie，课表刷新复用；Cookie 失效再提示重新登录。
3. 课表归一化成 `{day:1-7, bigSection:1-5, name, room, teacher, weeks}`，桌面组件只读本地缓存（今天=星期几 + 本周周次过滤），空课留空。
4. 周次来源保底：首次导入时让用户选「本学期第 1 周起始日期」，之后自动推算；若能解析则自动覆盖。
5. 参考 Dawn-Course 的 WebView+JS 解析方案做「解析脚本可更新」兜底：强智改版时不用发版。

# 实测记录：jwglxt.sdust.edu.cn（2026-11-26，匿名只读 GET/POST 探测，未使用任何真实账号）

## 结论：是「湖南强智科技」教务系统 + 学校统一身份认证(CAS)，不是正方

证据：
- 首页 footer：`Copyright © 2020.湖南强智科技发展有限公司`，前端 `/assets_newL/` + layui。
- 正方特征路径 `/xtgl/login_slogin.html`、`/xtgl/login_getPublicKey.html` → 404。
- 未登录访问 `/jsxsd/xskb/xskb_list.do`、`/jsxsd/framework/xsMain.jsp` → 均 200 但返回登录页（title=登录），说明存在强智 jsxsd 模块且做了会话校验。

## 1) 强智内置账号密码登录（无需 RSA）

表单：`<form name="loginForm" action="/Logon.do?method=logon" method="post">`
字段：`loginMethod=logon`、`userAccount`、`userPassword`、`userlanguage=0`、`encoded`(hidden)。

密码处理（页面内联 JS，可 1:1 复刻到 Kotlin）：
```
POST /Logon.do?method=logon&flag=sess   ->  返回 "scode#sxh"（如 xDMHt381...#1221111232...）
code    = userAccount + "%%%" + userPassword + "%%%" + codeDogSequence(" " 即可)
encoded = 对 i<55：encoded += code[i] + scode[0..sxh[i]]; scode = scode[sxh[i]..]
          对 i>=55：剩余直接拼接
提交：POST /Logon.do?method=logon，userPassword 置空，encoded=上面结果
Cookie：bzb_njw、SERVERID_gld、JSESSIONID（会话）
```
- 登录页**没有验证码输入框**；存在 `/verifycode.servlet` 图片接口（可能仅找回密码/异常时用），登录页有 `rail/sidler` 滑块样式（可能仅特殊登录方式用）、微信扫码登录、USBKey 加密狗（可忽略）。
- 风险：是否多次失败后强制验证码、`codeDogSequence` 在真实登录是否必须为空——需真实账号验证。

## 2) 学校统一身份认证（CAS）

- `/Logon.do?method=logout` 会跳 `https://my.sdust.edu.cn/cas/logout?service=https://jwglxt.sdust.edu.cn/sso.jsp`
- CAS 登录页：`https://my.sdust.edu.cn/cas/login?service=https%3A%2F%2Fjwglxt.sdust.edu.cn%2Fsso.jsp`
  - 表单含 `username`、`password`(hidden，前端由 ppassword 转入，疑似前端加密)、`authcode`(**验证码**)、`execution`(hidden)、`_eventId=submit`、`rememberMe`；还支持短信验证码登录。
  - **验证码是自动登录的主要障碍**。
- 课表入口 `/sso.jsp` 用 CAS ticket 换强智会话。

## 3) 课表接口（待真实账号确认参数）

- 强智传统课表页：`GET/POST /jsxsd/xskb/xskb_list.do`（学期 `xnxq01id`、周次 `zc` 等参数），返回 HTML 表格（需按合并单元格解析课程名/教师/地点/周次/节次）。未登录时被会话校验挡回登录页。
- 建议实现路线：先 WebView 完成 CAS 登录 → 持久化 Cookie → OkHttp 带 Cookie 请求该页面 → Jsoup 解析。

## 4) 其他

- 全程 HTTPS 正常（证书有效）。
- 无需 VPN/校内网（公网可访问登录页）。
- 服务端会话：强智 Cookie 有效期需实测；CAS 单点登录可能互踢（同一账号在两处登录会挤掉网页端会话）。

## 5) 追加实测（强智 jsxsd 登录页 + CAS 入口）

- `GET /jsxsd/` → 返回强智学生端登录页（title=登录），**表单 action="/jsxsd/xk/LoginToXk"**，字段 `loginMethod=LoginToXk`、`userAccount`、`userPassword`、`encoded`；页面 JS 同时含 `/Logon.do?method=logon&flag=sess` 的 scode/sxh 编码逻辑（阈值 55），以及 `#RANDOMCODE`（验证码）占位与 `verifycode.servlet`。
- 结论：`/` 与 `/jsxsd/` 两套登录页都指向强智编码算法；同校开源 SHST-ULTRA 使用 `POST /jsxsd/xk/LoginToXk`（`encoded=base64(账号)%%%base64(密码)` + `RANDOMCODE` 验证码），与页面 JS 一致 → **登录验证码大概率必填**。
- `GET /sso.jsp` → 200，返回 JS：`window.location.href='http://my.sdust.edu.cn/cas/login?service=https://jwglxt.sdust.edu.cn/sso.jsp'` → **教务系统支持学校统一身份认证（CAS）单点登录**；CAS 页面有验证码 + 短信验证码登录。
- 注意：CAS 跳转用的是 **http://my.sdust.edu.cn**（80 端口）。Android 9+ 默认禁明文，WebView/OkHttp 若跟随该跳转会被拦 → 需 networkSecurityConfig 定向允许 `my.sdust.edu.cn` 明文，或在 WebView 里把 http 升级为 https（https 版本实测 200 可用）。
- `GET /jsxsd/framework/xsMainV.htmlx`、`/jsxsd/xskb/xskb_list.do` 未登录时均返回登录页（200），说明会话校验在服务端。

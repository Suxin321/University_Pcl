# HyperOS 4 UI 设计规范与桌面组件视觉参数调研（Redmi K80 / com.university.pcl）

> 目的：给「University_Pcl」仿 HyperOS GUI（主界面 + 当天 5 节大节课表桌面组件）提供**可直接写进代码的参数**。
> 标注约定：**【官方】**= 小米公开文档/官网原文；**【代码】**= 开源项目源码实际值；**【推测】**= 按规范换算或社区信息，需真机核对。
> 调研时间：2026-11。设备：Redmi K80，OS4.0.3.0.XOKCNXM。

## 0. 结论速览

- 小米**没有公开的 HyperOS 设计 token 站**（无 Color/Radius/Type 的机器可读规范）。官方公开的只有：①官网设计宣传页 ②开发者平台的《小部件设计规范》《小部件审核规范》《适配 Q&A》③MiSans 字体站。系统 UI 的通用色板/控件高度属**未公开**，只能**从系统应用截图反推或直接用 Miuix 社区值**。
- 但对本项目**恰好够用**：桌面组件是唯一有官方硬指标（尺寸/圆角/安全区/字体/深浅色）的部分，而本项目的核心交付物正是桌面组件。
- 最省力路径：**Jetpack Compose + Miuix（Apache-2.0，1744★，提供 miuix-squircle / miuix-glass / miuix-blur / Monet 取色）**，配色与字阶直接抄它的 default scheme，圆角用它的 squircle。

## 1. HyperOS 4 设计语言（官方口径）

【官方】HyperOS 4 主题为「**生命感美学**」，四个可落地要点（[hyperos.mi.com](https://hyperos.mi.com/) / [K80 V4.0.3 更新日志](https://miuiver.com/zorn-v4-0-3/)）：

1. **柔光玻璃材质**：感知环境色、自适应通透度 → 组件背景应是「低不透明度 + 细亮边 + 背景模糊」，而不是纯灰卡片。
2. **光效反馈**：点按/拖拽有跟随轨迹的光，动效是「光」不是「缩放」。
3. **柔性框架 / 悬浮框架**：大标题 + 悬浮内容层，导航与内容分离。
4. **可编排空间**：锁屏时钟字体/位置/材质可调，通知堆叠，**小部件支持堆叠与多种形状**，文件夹可拖拽调大小。

与 2/3 的差异（官方 changelog）：4.0 新增柔光玻璃+光效、锁屏时钟可调、通知堆叠、**小部件堆叠 + 多形状**、柔性悬浮框、三方应用一镜到底动画；HyperOS 2/3 的「生命感美学」是静态为主（景深壁纸 + 卡片化），4.0 转成**材质与动效**驱动。

## 2. 设计参数（能写进代码的值）

### 2.1 颜色 —【代码】Miuix default scheme（与 HyperOS 观感最接近的开源值）

| 语义 | Light | Dark |
|---|---|---|
| primary（品牌蓝） | `#3482FF` | `#277AF7` |
| background（页面底） | `#FFFFFF` | `#242424` |
| surface（列表底） | `#F7F7F7` | `#000000` |
| surfaceVariant（卡片） | `#FFFFFF` | `#242424` |
| surfaceContainer（卡内块） | `#FFFFFF` | `#242424` |
| outline（描边） | `#D9D9D9` | `#404040` |
| divider（分割线） | `#E0E0E0` | `#393939` |
| 文字四层 | 100% / 80% / 60% / 40% 黑 | 同比例白 |
| error | `#E94634` | `#F12522` |
| 遮罩 | `#000` 30% | `#000` 60% |

- 来源：`miuix-ui/.../theme/Colors.kt`（Apache-2.0）。**【代码】**
- 动态取色：Miuix `ThemeController(ColorSchemeMode.MonetSystem, keyColor=…)` 支持壁纸取色；系统级取色为 HyperOS 原生能力，组件内自行取色更稳。**【代码】**
- 品牌橙 `#FF6700` 是小米**品牌/营销**色，**不要**用作 HyperOS 系统界面主色（系统 UI 主色是蓝 `#3482FF` 一系）。**【官方/代码】**

### 2.2 字阶 —【代码】Miuix `TextStyles`（sp）

`32 / 24 / 20 / 18 / 17 / 16 / 14 / 13 / 11`，语义：Title1 32、Title2 24、Title3 20、Title4 18、Main/Body1 17/16、Body2/Subtitle 14、Footnote1 13、Footnote2 11、Subtitle = 14 **Bold**。

- 行高：正文 `1.2em` 起。**【代码】**
- 字体：**MiSans**；主信息 **Demibold**，次信息 **Medium**。**【官方·小部件规范】**

### 2.3 圆角 / 间距 / 控件高度

- **小部件圆角【官方】**：2025-03 版规范 → 1080p 交 55px、2K 交 73px（系统裁「平滑圆角」squircle）；2024-09 审核规范仍写 1080p 38px / 2K 50px（=12.67dp / 14.29dp）。**两版并存，按新版为视觉目标**。换算（1080p≈3x，2K≈3.5x）：**≈18dp（1080p）/ ≈21dp（2K）**。
- **内容安全区【官方】**：1080p ≥42px、2K ≥55px → **≈14dp / ≈16dp**。
- 卡片/弹窗圆角：系统 UI 无公开值；Miuix 提供 `miuix-squircle`（超椭圆）组件，直接用它做一致性。**【代码】**
- 间距栅格：**4dp 基准**（8/12/16/24 常用档）——无官方文档，属行业默认 + 系统截图观感。**【推测】**
- 控件高度：**无官方值**。可行近似：列表行 56dp、主按钮 44–48dp、图标按钮 40dp、底部栏 56dp。**【推测·需真机核对】**
- 图标：系统用 Android Adaptive Icon 画布 108dp（安全区 72dp）+ 超椭圆遮罩；HyperOS 4 加了「玻璃图标」层（Miuix 有 `miuix-glass-icons` 可对齐观感）。**【推测+代码】**

## 3. 桌面小部件官方硬指标（本项目最重要，几乎全部【官方】）

来源：《[Xiaomi HyperOS 小部件设计规范](https://dev.mi.com/xiaomihyperos/documentation/detail?pId=1664)》(2025-03) + 《[小部件审核规范](https://dev.mi.com/xiaomihyperos/documentation/detail?pId=1586)》+ 《[适配 Q&A](https://dev.mi.com/xiaomihyperos/documentation/detail?pId=1591)》

### 3.1 尺寸与网格（可直接算 dp）

- 手机（含折叠屏）只支持 **2x2 / 4x2 / 4x4**；平板另有 Pad 4x2。
- 桌面**单格 = 70×80dp**【官方 Q&A】→ 组件实际尺寸：
  - 2x2 ≈ **140×160dp**，4x2 ≈ **280×160dp**，4x4 ≈ **280×320dp**
  - 实际高度 = `ceil(minHeight/80)*80 - padding`，**与 xml 里 minHeight 不是一回事**【官方】
- 设计基准 1080×2340；**2K = 1080p × 1.333**；桌面布局需兼容 **4x6 / 5x8（5x7）**、有无搜索框、有无虚拟键、1080p+2K 四种情况。
- 自适应布局：**尺寸由系统缩放，绝对尺寸不保证与设计稿一致**【官方】。
- 预览图：必须**直角**，系统裁圆角；预览图圆角统一 38px。**【官方】**

### 3.2 视觉规范

- 深色模式：**必须适配**（且新系统只在 xml 静态适配、**不支持 RemoteViews 里动态切**）。**【官方】**
- 字重：主信息 MiSans **Demibold**；次要 MiSans **Medium + 40% 透明**；标题 **Medium + 40% 黑（暗色 40% 白）**。**【官方】**
- 字色三层级：主/次/辅（100/60/40 同 Miuix）。**【官方】**
- 字阶规范只给了图；可用 §2.2 的 12/13/14/16/20/28 近似。**【推测】**
- 日期格式统一 `年–月–日`、`月–日`（如 `2026-11-26`）。**【官方】**
- 时间请用原生 `AnalogClock`/`TextClock`，别自己刷。**【官方】**
- 禁止项：**组件内不能上下/左右滑动、不能文字输入**。**【官方】**
- 无内容场景（未登录/无网络/无数据）必须出占位符 + 说明文字 + 加载骨架。**【官方】**
- 名称：2~10 汉字，格式「应用名·小部件名」，介绍 ≤22 汉字，结尾不加标点。**【官方】**
- 进程：独立 Widget 进程，内存 <40M。**【官方】**

### 3.3 添加与分发（决定侧载可行性）

- 小米小部件进「小部件中心」**必须走小米小部件平台审核**（应用商店审核与小部件审核不同步）；审核前线上不可见，只能测试环境自测。**【官方】**
- **Android 原生组件**另有入口：小部件中心 →「搜索—安卓小部件」。**侧载 APK 的 AppWidget 可以由此添加，不需要小米审核**——本项目若要快速落地，走原生 AppWidget 路线。**【官方，需真机核对入口存在与缩放行为】**
- 4.0 新增「小部件堆叠/多形状」，第三方能否参与堆叠：**【需真机核对】**。

## 4. 「当天 5 节大节课表」组件落地建议

- 主尺寸 **4x4（280×320dp）**：顶部一行「日期 + 周次」，下面 5 行课表，每行约 **44–48dp**（课名 14sp Demibold + 时间 12sp 40% 透明），节次/时间列固定 56dp 宽。**【建议】**
- 备尺寸 **4x2（280×160dp）**：隐藏空节，最多显示 5 行紧凑行（行高 ≈24dp），仅「节次 + 课名」。**【建议】**
- 圆角 21dp、内边距 16dp（安全区 16dp 的 1.25 倍更舒展）；背景 = 白色 82% 或 #242424 88% + 1dp 亮边 + 轻微 blur（柔光玻璃观感）。**【建议/推测】**
- 主界面直接用 Miuix：`MiuixTheme` + 大标题（32sp）+ 分组卡片（surfaceVariant + 圆角 18dp）+ 底部导航 `miuix-nav`。

## 5. MiSans 授权（可随 APK 分发，需署名）

- 官网：[hyperos.mi.com/font](https://hyperos.mi.com/font/download)（MiSans / **MiSans Latin** / TC / L3 / Tibetan / Arabic 等，每款 **10 字重 + 可变字体**；MiSans Latin 1350 字符、311 语言；MiSans 29608 字符、11 语言）。**【官方】**
- 许可：**全球免费商用**（含任何平台/商业项目），可 **嵌入软件**，可调粗细间距；须在软件中**特别注明使用了 MiSans 字体**；**不得单独再分发/售卖字体文件**、不得改编字体外观。→ **打包进 APK 属官方 FAQ 明确允许的「嵌入式使用」，但必须在「关于」页署名。**【官方·[FAQ](https://hyperos.mi.com/font/faq)】**
- 数字字体：**MiSans Latin**（中文文本里的阿拉伯数字用 MiSans 自带拉丁即可；若做等宽数字/大数字时钟，用 MiSans Latin 或 `FontFeature("tnum")`）。**【官方+建议】**
- 节省包体技巧：只打包 **Regular/Medium/Demibold** 三档 + 子集化（中文标题可只打包 GB2312 子集）。**【建议】**

## 6. 可复用代码 / 资源

| 资源 | 链接 | 现状与可用性 |
|---|---|---|
| **Miuix**（Compose Multiplatform，小米风 UI） | [compose-miuix-ui/miuix](https://github.com/compose-miuix-ui/miuix) | **1744★、Apache-2.0、2026-11 仍在日更**。模块：`miuix-ui` / `miuix-glass`（柔光玻璃面）/ `miuix-blur` / `miuix-squircle`（超椭圆圆角）/ `miuix-glass-icons` / `miuix-icons` / `miuix-preference` / `miuix-nav`。**Android/iOS/Desktop/Web 全支持，直接 `implementation("top.yukonga.miuix.kmp:miuix-ui:<ver>")`。首选方案。** 注意 README 声明 experimental，API 会变。在线 demo：[miuix-wasmJs](https://compose-miuix-ui.github.io/miuix-wasmJs/)。 |
| 小米官方 Figma 小部件模板 | [MIUI 小部件设计模版（对外）](https://www.figma.com/file/77WJkiBYLNys7iWpKe8pm0/) | 官方放出，含 2x2/4x2/4x4 画板与安全区。**画板即权威布局参考**。 |
| 小米官方设计系统（非 HyperOS） | [xiaomi-miloco/knowledge/07-design](https://github.com/XiaoMi/xiaomi-miloco/blob/b1887aeac716214d67c2aff527567a55ccc68d1d/knowledge/07-design/README.md) | 小米官方仓库但为 **Mi Console v3 web 设计系统**（品牌橙 #FF6700、字阶 12/14/16/24/32）。**参考写法，勿照搬数值**。 |
| HyperOS 图标复刻 | [stbenjam/HyperIcons](https://github.com/stbenjam/HyperIcons) · [Verisonder/SonderIcons](https://github.com/verisonder/sondericons) | 社区图标覆盖项目，只有主题/图标资源、无设计 token；做图标参考尚可，注意版权。★量级小（百级以下）。 |

## 7. Redmi K80 适配参数（官方 + 实测）

- 屏幕：**6.67" 3200×1440（2K）**、**526 PPI**、120Hz、12bit、直屏 + **中置单挖孔**；峰值 3200nits。**[CNMO 参数页](https://product.cnmo.com/1628/1627260/param.shtml)、[雷科技](https://www.leikeji.com/article/66573)**
- 密度：2K 机型按官方 2K 设计基准 1440×3200 → **density≈3.5（560dpi）→ 逻辑宽 411dp、高 914dp**（官方 Q&A 提到 2K 走 `values-sw411dp`，与此一致）。**【官方换算，需真机核对 `wm density`】**
- 系统：**HyperOS 4.0.3.0.XOKCNXM，Android 17.0**，正式版，2026-11-11 发布。**[miuiver](https://miuiver.com/zorn-v4-0-3/)**
- 四角圆/挖孔尺寸：**未公开**，需真机截图量（建议用 `WindowInsets` + `RoundedCorner` API 运行时读，别写死）。**【需真机核对】**
- 上架/侧载：上架小米应用商店走常规审核；**小部件中心收录另需小部件审核**（邮件 miui-widget@xiaomi.com，10 工作日）；侧载仅用原生 AppWidget 无需审核。**【官方】**

## 8. 事实 / 推测 / 需真机核对 清单

- 事实（官方）：小部件尺寸 2x2/4x2/4x4、格子 70×80dp、圆角 55px(1080p)/73px(2K)、安全区 42/55px、MiSans 字重用法、深色必适配、禁止滑动/输入、独立进程<40M、审核流程、MiSans 免费商用+嵌入需署名、K80 分辨率/Android 17。
- 推测（建议真机定稿）：4dp 栅格、行高/控件高度、图标 108dp+超椭圆、柔光玻璃的不透明度与模糊半径、K80 density=3.5。
- 需真机核对：`wm density`/`wm size`；桌面实际网格（4x6 或 5x8）；侧载 AppWidget 的缩放行为与「安卓小部件」入口；4.0 小部件堆叠是否收三方；屏幕圆角像素与挖孔直径；系统界面主色实测值（是否 ≈ #3482FF）。

## 参考链接

- [HyperOS 4 官网](https://hyperos.mi.com/) · [小部件设计规范](https://dev.mi.com/xiaomihyperos/documentation/detail?pId=1664) · [审核规范](https://dev.mi.com/xiaomihyperos/documentation/detail?pId=1586) · [适配 Q&A（含 70×80dp 网格公式）](https://dev.mi.com/xiaomihyperos/documentation/detail?pId=1591)
- [MiSans 下载](https://hyperos.mi.com/font/download) · [MiSans FAQ（嵌入=可以，需署名）](https://hyperos.mi.com/font/faq)
- [Miuix 仓库](https://github.com/compose-miuix-ui/miuix) · [Colors.kt](https://github.com/compose-miuix-ui/miuix/blob/main/miuix-ui/src/commonMain/kotlin/top/yukonga/miuix/kmp/theme/Colors.kt) · [TextStyles.kt](https://github.com/compose-miuix-ui/miuix/blob/main/miuix-ui/src/commonMain/kotlin/top/yukonga/miuix/kmp/theme/TextStyles.kt)
- [K80 参数（CNMO）](https://product.cnmo.com/1628/1627260/param.shtml) · [K80 V4.0.3 更新日志 / Android 17](https://miuiver.com/zorn-v4-0-3/)

# University_Pcl

适配 Redmi K80（HyperOS 4.0.3.0）的课表 App：**桌面组件显示当天 5 大节课表**，数据来自强智教务系统（默认山东科技大学 `jwglxt.sdust.edu.cn`，地址可自填），界面仿 HyperOS。

> 当前是 **MVP 工程**：完整可构建的 Android 工程（Kotlin + Compose + Glance），业务逻辑按调研结论实现；**登录与课表接口参数需要真机+真实账号验证**（见文末「待验证」）。

## 功能

- **登录**：内嵌 WebView 打开学校教务系统登录页，用户手动输入学号/密码/验证码（或用扫码/短信登录），点「已完成登录」保存 Cookie。账号密码不落盘。
- **课表同步**：OkHttp 带 Cookie 请求 `/jsxsd/xskb/xskb_list.do?week=&term=`，Jsoup 解析强智课表 HTML，归一化为「星期 × 5 大节」的课程列表，缓存到本地 JSON。
- **主界面（仿 HyperOS）**：大标题、周切换、5 大节卡片（课程名 / 地点 / 教师，空课显示「无课」）、登录引导卡。
- **桌面组件**：Jetpack Glance，4×4 显示完整 5 大节；缩到 4×2 自动切换紧凑模式。点击组件打开 App。
- **自动刷新**：WorkManager 6 小时周期 + 每天 00:05 跨天刷新 + 打开 App / 点刷新兜底。
- **设置**：二级目录式（学期与周次 / 课表来源 / 空课表 / 值班时段 / 关于），点进去再改；含学期、周次、第 1 周周一日期、课表导入、空课表导入、值班时段编辑等。
- **排班（v1.0.16 起，v1.0.18 增强）**：在「设置 → 排班 · 空课表」导入社团空课表（.xlsx / .xls；表头星期一到星期日、每行一个大节，单元格写「姓名 + 没课的周次」，如 `刘如航16-20`、`王妍1-6 8-11 19`，姓名后没数字表示所有周都没课）。到「排班」页按空课表自动生成值班表：可选周区间、**哪几天 / 哪几个大节 / 哪些成员**（成员选择支持搜索、全选、清空、反选、选中搜索结果）、每个时段人数、「同一天不重复」「同一周不重复」（默认严格：排不下就留空，可开「允许同一人重复」）；每个大节的值班起止时间在「设置 → 排班 · 值班时段」里调，会显示在排班页左侧和导出的值班表里。排班以课表样式（星期 × 大节彩色格子）展示，点任意格子手动换人；下方有带渐变进度条的「值班次数表」（本周 / 合计，可按本周或合计排序，点人名可手动补录/扣除次数）；「空课详情」能查看某周每个时段没课的人；排到一半想重来可点「重置全部排班」（可选同时清空手动调整）。支持把排班表导出为文字（复制到剪贴板或分享到微信/QQ）。空课表可随时重新导入替换。

## 目录结构

```
app/src/main/java/com/university/pcl/
├── MainActivity.kt            主界面 + 状态
├── LoginActivity.kt           WebView 登录
├── data/
│   ├── Models.kt              CourseSlot / ScheduleCache
│   ├── Prefs.kt               设置与 Cookie（SharedPreferences）
│   ├── CacheStore.kt          课表缓存（JSON）
│   ├── QiangzhiParser.kt      强智课表 HTML 解析 + 周次解析
│   ├── ScheduleRepository.kt  拉取课表 + 缓存
│   └── WeekUtil.kt            周次推算 / 学期猜测 / 跨天毫秒
├── ui/
│   ├── Theme.kt               HyperOS 风格配色（#3482FF）
│   ├── HomeScreen.kt          今日课程
│   └── SettingsScreen.kt      设置
└── widget/
    ├── ScheduleWidget.kt      桌面组件（4×4 / 4×2）
    ├── ScheduleWidgetReceiver.kt
    ├── RefreshWorker.kt       后台刷新
    ├── WidgetRefreshScheduler.kt
    └── WidgetUpdater.kt
```

设计/接口调研见 [可行性分析.md](可行性分析.md)，视觉稿见 [mockup/index.html](mockup/index.html)（手机浏览器打开）。

## 构建

### 方式一：GitHub Actions（推荐，手机/无环境也能出包）

1. 把本目录推到 GitHub 仓库（`.github/workflows/android.yml` 已配置好）。
2. Actions 里跑 `Android CI`，完成后在 Artifacts 下载 `University_Pcl-debug-apk`。
3. 手机安装：允许「安装未知应用」，装好后到桌面 **长按 → 添加小部件 → 搜索「安卓小部件」→ 选 课程表·今日**。

### 方式一（网页版，全程手机可操作）

1. `github.com/new` 建仓库 `University_Pcl`；
2. 仓库页 **Add file → Upload files**，上传 `University_Pcl_mvp.zip`，Commit；
3. **Add file → Create new file**，文件名 `.github/workflows/build.yml`，粘贴 `web-build/build-from-zip.yml` 内容，Commit；
4. 打开 **Actions** → 等 `Build APK` 跑完 → Artifacts 下载 `University_Pcl-debug-apk` → 解压安装。

> 详细图文步骤见 `web-build/网页构建步骤.md`。这个 workflow 会自动解压 zip 并构建，不需要命令行。

### 方式二：本地 Android Studio

- 需要 JDK 17、Android Studio（Gradle 8.9 会自动下载，工程带 wrapper）。
- 打开工程 → Sync → Run。命令行：`./gradlew assembleDebug`（Windows 用 `gradlew.bat`）。

> 技术栈：AGP 8.7.3 / Kotlin 2.0.21 / Compose BOM 2024.10.01 / Glance 1.1.1 / WorkManager 2.9.1 / OkHttp 4.12 / Jsoup 1.18 / kotlinx.serialization 1.7.3；minSdk 26，targetSdk 35。

## 网页版（HarmonyOS / 任意手机浏览器）

纯离线 PWA，源码在 `web/`，部署在 GitHub Pages：

**https://suxin321.github.io/University_Pcl/**

- 鸿蒙 6 / NEXT 装不了 APK，用浏览器打开这个地址即可；浏览器菜单「添加到桌面」后像 App 一样全屏使用。
- 功能：课表 .xls/.xlsx 导入 + 周视图 + 手动加课；空课表导入、自动排班（周区间/星期/大节/成员/人数/不重复/允许重复）、点格子换人、次数表与手动调整、空课详情、排班表导出复制/分享、重置排班；设置二级菜单。
- 数据存在浏览器 localStorage；换浏览器或清缓存会丢，重要排班先导出文字。
- 更新网页：改完 `web/` 里的文件运行 `/root/deploy_web.py`（GitHub Pages 的 gh-pages 分支）。

## 首次使用

**推荐：导入导出的课表文件（离线、最稳）**

1. 教务系统 → 课表页 → 右上角 **导出**，下载 `学生个人课表_yyyyMMddhhmm.xls`
2. 打开 App → **设置 → 导入课表文件（.xls）** → 选中该文件
3. 回主页即可看到课表（学期会自动从文件里读出）

1. 打开 App → 设置：确认学期（导入时自动从文件读取）、周次或第 1 周周一日期（可选）→ 保存。
2. 回主页即可看到课表；换周次点顶部 ‹ ›（会保存），点「本周」按校历自动算。
3. 添加桌面组件（见上）。

**排班（可选）**：设置 → 「排班 · 空课表」→ 导入 `.xlsx`/`.xls` → 底部「排班」→「自动排班」选周区间、每时段人数、是否同天/同周不重复 → 生成后点任意格子手动换人 →「导出排班表」复制或分享。

## 说明

- 当前版本只走「导入教务系统导出的 .xls」这一条路（离线、稳定）；在线自动下载/登录拉取已移除（教务页面不适合手机、导出接口难自动化，后续再研究）。
- 5 大节按 1-2 / 3-4 / 5-6 / 7-8 / 9-10 小节映射。
- 桌面组件刷新：每 6 小时 + 每天 00:05 重绘（离线，只读本地课表），打开 App/点刷新也会更新。

> 详见 [可行性分析.md](可行性分析.md) 第 13 节。

## 合规

- 仅本机读取自己账号的课表，账号密码/Cookie 不上传任何服务器。
- 不做验证码 OCR/破解，不公开分发，不限频滥用；访问频率按自然使用（一天几次）。
- 免责：教务系统接口非官方公开 API，学校改版可能导致失效。

## 后续计划

- P1：课程周视图、组件颜色随课程区分、深色模式细节打磨。
- P2：直接账号密码登录（复刻 `scode#sxh` 编码，作为 WebView 备选）。
- P3：MiSans 字体打包（关于页署名）、HyperOS 灵动通知、组件 2×2 迷你版。

package com.university.pcl

import com.university.pcl.data.PlanEditor
import com.university.pcl.data.PlanItem
import com.university.pcl.data.PlanSort
import com.university.pcl.data.PlanStats
import com.university.pcl.data.PlanText
import com.university.pcl.data.PlanType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PlanTest {

    private val today = "2026-11-28"

    private fun todo(
        id: String,
        title: String,
        date: String = "",
        done: Boolean = false,
        created: Long = 0L
    ) = PlanItem(
        id = id,
        title = title,
        type = PlanType.TODO,
        date = date,
        done = done,
        createdAt = created
    )

    private fun count(
        id: String,
        title: String,
        current: Int,
        target: Int,
        date: String = "",
        created: Long = 0L
    ) = PlanItem(
        id = id,
        title = title,
        type = PlanType.COUNT,
        date = date,
        current = current,
        target = target,
        createdAt = created
    )

    @Test
    fun createNormalizesFields() {
        val item = PlanEditor.create(" 跑步 ", PlanType.COUNT, "2026-12-1", 30, 1000L)
        assertEquals("跑步", item.title)
        assertEquals(PlanType.COUNT, item.type)
        assertEquals("2026-12-01", item.date)
        assertEquals(30, item.targetSafe)
        assertEquals(0, item.currentSafe)
        assertEquals(1000L, item.createdAt)
        assertTrue(item.id.isNotBlank())
        assertFalse(item.isCompleted())
    }

    @Test
    fun createTodoIgnoresTarget() {
        val item = PlanEditor.create("交作业", "unknown-type", "", 99, 1L)
        assertEquals(PlanType.TODO, item.type)
        assertEquals(1, item.targetSafe)
    }

    @Test
    fun todoToggle() {
        val items = listOf(todo("a", "背单词"))
        val done = PlanEditor.toggleTodo(items, "a", 5L)
        assertTrue(done.first().done)
        assertEquals(5L, done.first().updatedAt)
        assertFalse(done.first().isCount)
        assertEquals(PlanType.TODO, done.first().type)
        val undone = PlanEditor.toggleTodo(done, "a", 6L)
        assertFalse(undone.first().done)
        assertEquals(6L, undone.first().updatedAt)
    }

    @Test
    fun incrementCapsAtTarget() {
        var items = listOf(count("c", "跑步", 0, 3))
        items = PlanEditor.increment(items, "c", 1L)
        assertEquals(1, items.first().currentSafe)
        items = PlanEditor.increment(items, "c", 2L)
        items = PlanEditor.increment(items, "c", 3L)
        assertEquals(3, items.first().currentSafe)
        items = PlanEditor.increment(items, "c", 4L)
        assertEquals(3, items.first().currentSafe)
        assertTrue(items.first().isCompleted())
    }

    @Test
    fun decrementNotBelowZero() {
        var items = listOf(count("c", "跑步", 0, 3))
        items = PlanEditor.decrement(items, "c", 1L)
        assertEquals(0, items.first().currentSafe)
        items = listOf(count("c", "跑步", 2, 3))
        items = PlanEditor.decrement(items, "c", 2L)
        assertEquals(1, items.first().currentSafe)
    }

    @Test
    fun toggleOrIncrementDispatchesByType() {
        val todoItems = listOf(todo("t", "写报告"))
        val afterTodo = PlanEditor.toggleOrIncrement(todoItems, "t", 1L)
        assertTrue(afterTodo.first().done)

        val countItems = listOf(count("c", "跑步", 1, 5))
        val afterCount = PlanEditor.toggleOrIncrement(countItems, "c", 1L)
        assertEquals(2, afterCount.first().currentSafe)
    }

    @Test
    fun upsertAndRemove() {
        val item = PlanEditor.create("计划A", PlanType.TODO, "", 1, 10L)
        var items = PlanEditor.upsert(emptyList(), item)
        assertEquals(1, items.size)

        val edited = item.copy(title = "计划A改")
        items = PlanEditor.upsert(items, edited)
        assertEquals(1, items.size)
        assertEquals("计划A改", items.first().title)

        items = PlanEditor.remove(items, item.id)
        assertTrue(items.isEmpty())
    }

    @Test
    fun statsSummary() {
        val items = listOf(
            todo("1", "今天的待办", date = "2026-11-28"),
            todo("2", "已完成的", date = "2026-11-27", done = true),
            todo("3", "过期的", date = "2026-11-20"),
            count("4", "跑步", current = 5, target = 10, date = "2026-11-30"),
            count("5", "读书", current = 2, target = 2)
        )
        val summary = PlanStats.summarize(items, today)
        assertEquals(5, summary.total)
        assertEquals(2, summary.completed) // 待办完成 + 计数达标
        assertEquals(3, summary.pending)
        assertEquals(1, summary.overdue) // 只有「过期的」
        assertEquals(3, summary.todoTotal)
        assertEquals(1, summary.todoDone)
        assertEquals(2, summary.countTotal)
        assertEquals(7, summary.countDone)
        assertEquals(40, summary.percent) // 2/5
        assertEquals(33, summary.todoPercent)
        assertEquals(58, summary.countPercent) // 7/12
    }

    @Test
    fun statsOnEmptyList() {
        val summary = PlanStats.summarize(emptyList(), today)
        assertEquals(0, summary.total)
        assertEquals(0, summary.percent)
        assertEquals(0, summary.todoPercent)
        assertEquals(0, summary.countPercent)
    }

    @Test
    fun sortPutsOverdueFirstThenTodayThenUndatedThenDone() {
        val items = listOf(
            todo("undated", "无日期", date = ""),
            todo("done", "已完成", date = "2026-11-20", done = true),
            todo("today", "今天", date = "2026-11-28"),
            todo("overdue", "过期", date = "2026-11-10"),
            todo("future", "以后", date = "2026-12-10", created = 1L)
        )
        val sorted = PlanSort.forApp(items, today)
        assertEquals(
            listOf("overdue", "today", "future", "undated", "done"),
            sorted.map { it.id }
        )
    }

    @Test
    fun widgetSortRespectsLimit() {
        val items = listOf(
            todo("a", "A", date = "2026-11-20"),
            todo("b", "B", date = "2026-11-28"),
            todo("c", "C", date = "2026-12-01")
        )
        val limited = PlanSort.forWidget(items, today, 2)
        assertEquals(2, limited.size)
        assertEquals("a", limited[0].id)
        assertEquals("b", limited[1].id)
        assertEquals(3, PlanSort.forWidget(items, today, 0).size)
    }

    @Test
    fun textLabels() {
        assertEquals("今天", PlanText.dateLabel(todo("a", "A", date = "2026-11-28"), today))
        assertEquals("明天", PlanText.dateLabel(todo("a", "A", date = "2026-11-29"), today))
        assertEquals("昨天", PlanText.dateLabel(todo("a", "A", date = "2026-11-27"), today))
        assertEquals("12-10", PlanText.dateLabel(todo("a", "A", date = "2026-12-10"), today))
        assertEquals(PlanText.NO_DATE, PlanText.dateLabel(todo("a", "A"), today))
        assertEquals("3/10", PlanText.progressLabel(count("c", "C", 3, 10)))
        assertEquals("", PlanText.progressLabel(todo("t", "T")))
    }

    @Test
    fun statusLabels() {
        assertEquals("已完成", PlanText.statusLabel(todo("a", "A", date = "2026-11-20", done = true), today))
        assertEquals("已过期", PlanText.statusLabel(todo("a", "A", date = "2026-11-20"), today))
        assertEquals("今天", PlanText.statusLabel(todo("a", "A", date = "2026-11-28"), today))
        assertEquals("进行中", PlanText.statusLabel(todo("a", "A"), today))
        assertEquals("未完成", PlanText.statusLabel(todo("a", "A", date = "2026-12-10"), today))
    }

    @Test
    fun dateNormalization() {
        assertEquals("", PlanText.normalizeDate(""))
        assertEquals("", PlanText.normalizeDate("abc"))
        assertEquals("2026-12-01", PlanText.normalizeDate("2026-12-1"))
        assertEquals("2026-12-01", PlanText.normalizeDate(" 2026-12-01 "))
        assertEquals("2026-12-01", PlanText.shift("2026-11-30", 1))
        assertEquals("2026-11-30", PlanText.shift("2026-12-01", -1))
    }

    @Test
    fun targetParsing() {
        assertEquals(30, PlanText.parseTarget("30"))
        assertEquals(30, PlanText.parseTarget("30次"))
        assertEquals(30, PlanText.parseTarget(" 30 个 "))
        assertEquals(null, PlanText.parseTarget(""))
        assertEquals(null, PlanText.parseTarget("0"))
        assertEquals(null, PlanText.parseTarget("abc"))
        assertEquals(999, PlanText.parseTarget("5000"))
    }

    @Test
    fun itemCompletionAndProgress() {
        val target = count("c", "跑步", 10, 10)
        assertTrue(target.isCompleted())
        assertEquals(100, target.progressPercent())

        val half = count("c", "跑步", 5, 10)
        assertFalse(half.isCompleted())
        assertEquals(50, half.progressPercent())

        // 异常数据兜底：current 大于 target / target 为 0
        val weird = PlanItem(id = "w", title = "W", type = PlanType.COUNT, current = 999, target = 0)
        assertEquals(1, weird.targetSafe)
        assertEquals(1, weird.currentSafe)
        assertTrue(weird.isCompleted())

        // 日期字符串必须是 yyyy-MM-dd
        assertEquals(10, PlanText.todayString().length)
        assertNotNull(PlanText.todayString())
    }

    @Test
    fun newIdIsUnique() {
        val ids = (1..50).map { PlanText.newId() }.toSet()
        assertEquals(50, ids.size)
        assertTrue(ids.all { it.length >= 16 })
    }
}

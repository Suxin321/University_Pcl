package com.university.pcl

import com.university.pcl.data.XlsTimetableParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class XlsTimetableParserTest {

    private fun load(): XlsTimetableParser.Result {
        val stream = javaClass.getResourceAsStream("/sample_timetable.xls")
            ?: error("测试资源 sample_timetable.xls 不存在")
        return stream.use { XlsTimetableParser.parse(it) }
    }

    @Test
    fun parsesTermAndSlots() {
        val result = load()
        assertEquals("2026-2027-1", result.term)
        assertTrue("课程数量过少: ${result.slots.size}", result.slots.size >= 30)
        assertTrue(result.slots.all { it.name.isNotBlank() })
        assertTrue(result.slots.all { it.bigSection in 1..5 })
        assertTrue(result.slots.all { it.day in 1..7 })
    }

    @Test
    fun parsesKnownCourseFields() {
        val result = load()
        val course = result.slots.first { it.name.contains("概率论") }
        assertEquals(1, course.day)
        assertEquals(1, course.bigSection)
        assertEquals("赵义军", course.teacher)
        assertTrue(course.room.contains("J7-205"))
        assertTrue(course.weeks.contains(1) && course.weeks.contains(13))
        assertTrue(course.activeIn(5))
        assertTrue(!course.activeIn(15))
    }

    @Test
    fun parsesMultipleCoursesInOneCell() {
        val result = load()
        val java = result.slots.filter { it.name == "Java程序设计" }
        assertTrue("Java 程序设计应有多个周次条目", java.size >= 2)
        val weeks = java.flatMap { it.weeks }.toSet()
        assertTrue(weeks.containsAll(listOf(9, 10, 11, 12)))
    }

    @Test
    fun parsesFifthBigSection() {
        val result = load()
        val labor = result.slots.first { it.name == "劳动教育" }
        assertEquals(5, labor.bigSection)
        assertEquals(1, labor.day)
    }
}

package com.university.pcl

import com.university.pcl.data.BrowserUrls
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BrowserUrlsTest {

    @Test
    fun enginesList() {
        assertEquals(7, BrowserUrls.engines.size)
        assertTrue(BrowserUrls.engines.contains(BrowserUrls.ENGINE_YANDEX))
        assertTrue(BrowserUrls.engines.contains(BrowserUrls.ENGINE_UC))
        assertTrue(BrowserUrls.engines.contains(BrowserUrls.ENGINE_QUARK))
        assertTrue(BrowserUrls.engines.contains(BrowserUrls.ENGINE_BAIDU))
        assertTrue(BrowserUrls.engines.contains(BrowserUrls.ENGINE_BING))
        assertTrue(BrowserUrls.engines.contains(BrowserUrls.ENGINE_GOOGLE))
        assertTrue(BrowserUrls.engines.contains(BrowserUrls.ENGINE_DUCKDUCKGO))
        assertEquals("百度", BrowserUrls.ENGINE_BAIDU)
        assertEquals("DuckDuckGo", BrowserUrls.ENGINE_DUCKDUCKGO)
        assertEquals("Yandex", BrowserUrls.ENGINE_YANDEX)
        assertEquals("夸克", BrowserUrls.ENGINE_QUARK)
        assertEquals("Yandex", BrowserUrls.DEFAULT_ENGINE)
    }

    @Test
    fun isUrlLikeAcceptsUrlForms() {
        assertTrue(BrowserUrls.isUrlLike("example.com"))
        assertTrue(BrowserUrls.isUrlLike("https://example.com"))
        assertTrue(BrowserUrls.isUrlLike("http://a.b.c/path?q=1#x"))
        assertTrue(BrowserUrls.isUrlLike(" sub.example.cn/abc "))
        assertTrue(BrowserUrls.isUrlLike("my-site.org"))
        assertTrue(BrowserUrls.isUrlLike("example.com/"))
    }

    @Test
    fun isUrlLikeRejectsNonUrls() {
        assertFalse(BrowserUrls.isUrlLike(""))
        assertFalse(BrowserUrls.isUrlLike("   "))
        assertFalse(BrowserUrls.isUrlLike("hello world"))
        assertFalse(BrowserUrls.isUrlLike("hello"))
        assertFalse(BrowserUrls.isUrlLike("localhost:8080"))
        assertFalse(BrowserUrls.isUrlLike("ftp://example.com"))
        assertFalse(BrowserUrls.isUrlLike("a..b"))
        assertFalse(BrowserUrls.isUrlLike("中文.com"))
    }

    @Test
    fun normalizeInputHasThreeBranches() {
        // 空串
        assertEquals("", BrowserUrls.normalizeInput(""))
        assertEquals("", BrowserUrls.normalizeInput("   "))
        // 像网址 → 补 https://
        assertEquals("https://example.com", BrowserUrls.normalizeInput("example.com"))
        assertEquals("https://example.com/a?b=1", BrowserUrls.normalizeInput("  example.com/a?b=1  "))
        // 已带 scheme → 原样返回
        assertEquals("http://example.com", BrowserUrls.normalizeInput("http://example.com"))
        assertEquals("https://example.com", BrowserUrls.normalizeInput("https://example.com"))
        // 其余 → 走搜索（中文按 UTF-8 编码，含 %E）
        assertEquals(
            "https://www.baidu.com/s?wd=%E4%B8%AD%E6%96%87",
            BrowserUrls.normalizeInput("中文")
        )
        assertEquals(
            "https://www.bing.com/search?q=%E4%B8%AD%E6%96%87",
            BrowserUrls.normalizeInput("中文", BrowserUrls.ENGINE_BING)
        )
    }

    @Test
    fun searchUrlEncodesQueryPerEngine() {
        val encoded = "%E6%B5%8B%E8%AF%95" // 「测试」
        assertEquals("https://www.baidu.com/s?wd=$encoded", BrowserUrls.searchUrl("百度", "测试"))
        assertEquals("https://www.bing.com/search?q=$encoded", BrowserUrls.searchUrl("Bing", "测试"))
        assertEquals("https://www.google.com/search?q=$encoded", BrowserUrls.searchUrl("Google", "测试"))
        assertEquals("https://duckduckgo.com/?q=$encoded", BrowserUrls.searchUrl("DuckDuckGo", "测试"))
        assertEquals("https://yandex.com/search/?text=$encoded", BrowserUrls.searchUrl("Yandex", "测试"))
        assertEquals("https://m.sm.cn/s?q=$encoded", BrowserUrls.searchUrl("UC", "测试"))
        assertEquals("https://quark.sm.cn/s?q=$encoded", BrowserUrls.searchUrl("夸克", "测试"))
        // 默认引擎就是 Yandex
        assertEquals("https://yandex.com/search/?text=$encoded", BrowserUrls.searchUrl(BrowserUrls.DEFAULT_ENGINE, "测试"))
        // 未知引擎回退百度
        assertEquals("https://www.baidu.com/s?wd=$encoded", BrowserUrls.searchUrl("Sogou", "测试"))
        // 空格按 URLEncoder 规则变成 +
        assertEquals("https://www.baidu.com/s?wd=hello+world", BrowserUrls.searchUrl("百度", "hello world"))
        // 空查询也返回合法的搜索地址
        assertEquals("https://www.baidu.com/s?wd=", BrowserUrls.searchUrl("百度", ""))
    }

    @Test
    fun displayUrlStripsSchemeAndTrailingSlash() {
        assertEquals("www.baidu.com", BrowserUrls.displayUrl("https://www.baidu.com/"))
        assertEquals("a.cn/path", BrowserUrls.displayUrl("http://a.cn/path/"))
        assertEquals("example.com", BrowserUrls.displayUrl("example.com"))
        assertEquals("", BrowserUrls.displayUrl(""))
        // 去掉后为空 → 返回原串兜底
        assertEquals("https://", BrowserUrls.displayUrl("https://"))
    }

    @Test
    fun hostOfHandlesPortAndPath() {
        assertEquals("example.com", BrowserUrls.hostOf("https://Example.COM:8080/path?q=1#top"))
        assertEquals("example.com", BrowserUrls.hostOf("http://example.com"))
        assertEquals("example.com", BrowserUrls.hostOf("example.com?x=1"))
        assertEquals("example.com", BrowserUrls.hostOf("example.com:443/a"))
        assertEquals("sub.a.cn", BrowserUrls.hostOf("https://sub.a.cn"))
        assertEquals("", BrowserUrls.hostOf(""))
        assertEquals("", BrowserUrls.hostOf("https://"))
    }

    @Test
    fun labelOfUsesHostInitial() {
        assertEquals("B", BrowserUrls.labelOf("https://www.baidu.com/"))
        assertEquals("E", BrowserUrls.labelOf("https://example.com"))
        assertEquals("A", BrowserUrls.labelOf("http://a.cn"))
        assertEquals("·", BrowserUrls.labelOf(""))
        assertEquals("·", BrowserUrls.labelOf("https://www."))
    }
}

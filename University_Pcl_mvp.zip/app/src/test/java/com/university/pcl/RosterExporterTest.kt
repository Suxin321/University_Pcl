package com.university.pcl

import com.university.pcl.data.DutyShift
import com.university.pcl.data.RosterExporter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RosterExporterTest {

    @Test
    fun singleWeekTextContainsEverySlot() {
        val shifts = listOf(
            DutyShift(13, 1, 1, listOf("张三", "李四")),
            DutyShift(13, 2, 3, listOf("王五"))
        )
        val text = RosterExporter.text(shifts, 13, 13, listOf(1, 2))
        val lines = text.lines()

        assertEquals("第 13 周值班表", lines[0])
        assertEquals("周一 1-2节：张三、李四", lines[1])
        assertEquals("周一 3-4节：—", lines[2])
        assertEquals("周一 9-10节：—", lines[5])
        assertEquals("周二 5-6节：王五", lines[7])
        assertEquals("周二 9-10节：—", lines[10])
        assertEquals(11, lines.size) // 1 行标题 + 2 天 × 5 大节
    }

    @Test
    fun multiWeekAddsBlankLineBetweenWeeks() {
        val shifts = listOf(DutyShift(13, 1, 1, listOf("张三")))
        val text = RosterExporter.text(shifts, 13, 14, listOf(1))
        val lines = text.lines()

        assertEquals("第 13 周值班表", lines[0])
        assertEquals("", lines[6]) // 一周 5 行 + 标题后空行
        assertEquals("第 14 周值班表", lines[7])
        assertTrue(lines.last() == "周一 9-10节：—")
    }

    @Test
    fun emptyRosterStillExportsPlaceholders() {
        val text = RosterExporter.text(emptyList(), 3, 3, listOf(1))
        assertTrue(text.startsWith("第 3 周值班表"))
        assertTrue(text.contains("周一 1-2节：—"))
    }
}

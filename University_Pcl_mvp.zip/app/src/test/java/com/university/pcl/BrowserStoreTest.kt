package com.university.pcl

import com.university.pcl.data.BrowserBookmark
import com.university.pcl.data.BrowserDownloadEntry
import com.university.pcl.data.BrowserHistoryEntry
import com.university.pcl.data.BrowserQuickLink
import com.university.pcl.data.BrowserSettings
import com.university.pcl.data.BrowserStore
import com.university.pcl.data.BrowserUrls
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class BrowserStoreTest {

    @get:Rule
    val temp = TemporaryFolder()

    private fun newStore(): BrowserStore = BrowserStore(File(temp.root, "browser"))

    @Test
    fun bookmarksRoundTripAndFilterBlankUrl() {
        val store = newStore()
        assertTrue(store.loadBookmarks().isEmpty())

        val items = listOf(
            BrowserBookmark(id = "1", title = "百度", url = "https://www.baidu.com", createdAt = 100L),
            BrowserBookmark(id = "2", title = "空的", url = "   ", createdAt = 200L),
            BrowserBookmark(id = "3", title = "Bing", url = "https://www.bing.com", createdAt = 300L)
        )
        store.saveBookmarks(items)

        val loaded = store.loadBookmarks()
        assertEquals(2, loaded.size)
        assertEquals("1", loaded[0].id)
        assertEquals("百度", loaded[0].title)
        assertEquals("https://www.baidu.com", loaded[0].url)
        assertEquals(100L, loaded[0].createdAt)
        assertEquals("3", loaded[1].id)
        assertTrue(loaded.none { it.url.isBlank() })
    }

    @Test
    fun loadBookmarksFiltersBlankUrlFromDisk() {
        val store = newStore()
        store.saveBookmarks(listOf(BrowserBookmark(id = "1", title = "A", url = "https://a.com")))
        val dir = File(temp.root, "browser")
        dir.mkdirs()
        File(dir, "bookmarks.json").writeText(
            """{"items":[{"id":"1","title":"A","url":"https://a.com"},{"id":"2","title":"B","url":""}]}"""
        )
        val loaded = store.loadBookmarks()
        assertEquals(1, loaded.size)
        assertEquals("1", loaded[0].id)
    }

    @Test
    fun historyDeduplicatesSameUrlAndNewestFirst() {
        val store = newStore()
        store.addHistory(BrowserHistoryEntry(title = "A", url = "https://a.com", visitedAt = 1L))
        store.addHistory(BrowserHistoryEntry(title = "B", url = "https://b.com", visitedAt = 2L))
        store.addHistory(BrowserHistoryEntry(title = "A2", url = "https://a.com", visitedAt = 3L))
        store.addHistory(BrowserHistoryEntry(title = "空", url = "  ", visitedAt = 9L))

        val history = store.loadHistory()
        assertEquals(2, history.size)
        assertEquals("https://a.com", history[0].url)
        assertEquals("A2", history[0].title)
        assertEquals(3L, history[0].visitedAt)
        assertEquals("https://b.com", history[1].url)
        assertEquals(2L, history[1].visitedAt)
    }

    @Test
    fun historyCapsAt500() {
        val store = newStore()
        repeat(505) { index ->
            store.addHistory(
                BrowserHistoryEntry(title = "T$index", url = "https://site$index.com", visitedAt = index.toLong())
            )
        }
        val history = store.loadHistory()
        assertEquals(500, history.size)
        assertEquals("T504", history.first().title)
        assertEquals("https://site504.com", history.first().url)
        assertEquals("https://site5.com", history.last().url)
        assertEquals(5L, history.last().visitedAt)
    }

    @Test
    fun downloadsCapAt100() {
        val store = newStore()
        repeat(105) { index ->
            store.addDownload(
                BrowserDownloadEntry(
                    id = "d$index",
                    name = "文件$index",
                    url = "https://dl.example.com/$index",
                    createdAt = index.toLong()
                )
            )
        }
        val downloads = store.loadDownloads()
        assertEquals(100, downloads.size)
        assertEquals("d104", downloads.first().id)
        assertEquals("已加入下载", downloads.first().status)
        assertEquals("d5", downloads.last().id)
        assertEquals(5L, downloads.last().createdAt)
    }

    @Test
    fun settingsDefaultAndRoundTrip() {
        val store = newStore()
        assertEquals(BrowserSettings(), store.loadSettings())
        assertEquals(BrowserUrls.DEFAULT_ENGINE, store.loadSettings().searchEngine)
        assertEquals(BrowserUrls.ENGINE_YANDEX, store.loadSettings().searchEngine)
        assertTrue(store.loadSettings().adBlock)
        assertFalse(store.loadSettings().defaultIncognito)

        val custom = BrowserSettings(
            searchEngine = BrowserUrls.ENGINE_BING,
            adBlock = false,
            desktopMode = true,
            defaultIncognito = true,
            forceDark = true
        )
        store.saveSettings(custom)
        assertEquals(custom, store.loadSettings())
    }

    @Test
    fun clearHistoryAndDownloads() {
        val store = newStore()
        store.addHistory(BrowserHistoryEntry(title = "A", url = "https://a.com"))
        store.addDownload(BrowserDownloadEntry(id = "1", name = "a.apk", url = "https://a.com/a.apk"))
        assertTrue(store.loadHistory().isNotEmpty())
        assertTrue(store.loadDownloads().isNotEmpty())

        store.clearHistory()
        store.clearDownloads()
        assertTrue(store.loadHistory().isEmpty())
        assertTrue(store.loadDownloads().isEmpty())
    }

    @Test
    fun clearAllRemovesEverything() {
        val store = newStore()
        store.saveBookmarks(listOf(BrowserBookmark(id = "1", title = "A", url = "https://a.com")))
        store.addHistory(BrowserHistoryEntry(title = "A", url = "https://a.com"))
        store.addDownload(BrowserDownloadEntry(id = "1", name = "a.apk", url = "https://a.com/a.apk"))
        store.saveSettings(BrowserSettings(searchEngine = BrowserUrls.ENGINE_GOOGLE))

        store.clearAll()

        assertTrue(store.loadBookmarks().isEmpty())
        assertTrue(store.loadHistory().isEmpty())
        assertTrue(store.loadDownloads().isEmpty())
        assertEquals(BrowserSettings(), store.loadSettings())
        val dir = File(temp.root, "browser")
        assertTrue(dir.listFiles().isNullOrEmpty())
    }

    @Test
    fun corruptedFilesFallBackToEmptyOrDefaults() {
        val store = newStore()
        val dir = File(temp.root, "browser")
        dir.mkdirs()
        File(dir, "bookmarks.json").writeText("not json")
        File(dir, "history.json").writeText("[1,2,3]")
        File(dir, "downloads.json").writeText("null")
        File(dir, "settings.json").writeText("{ 这不是 JSON")

        assertTrue(store.loadBookmarks().isEmpty())
        assertTrue(store.loadHistory().isEmpty())
        assertTrue(store.loadDownloads().isEmpty())
        assertEquals(BrowserSettings(), store.loadSettings())
    }

    @Test
    fun newIdIsUniqueAndNonBlank() {
        val ids = (1..20).map { BrowserStore.newId() }.toSet()
        assertEquals(20, ids.size)
        assertTrue(ids.all { it.isNotBlank() })
    }

    @Test
    fun quickLinksDefaultWhenFileMissing() {
        val store = newStore()
        val defaults = store.loadQuickLinks()
        assertEquals(8, defaults.size)
        assertEquals(BrowserStore.defaultQuickLinks(), defaults)
        assertEquals(8, defaults.map { it.id }.toSet().size)
        assertTrue(defaults.all { it.id.isNotBlank() && it.name.isNotBlank() && it.url.isNotBlank() })
        assertTrue(defaults.all { it.createdAt == 0L })
        assertEquals("default-baidu", defaults[0].id)
        assertEquals("百度", defaults[0].name)
        assertEquals("https://www.baidu.com", defaults[0].url)
        assertEquals("default-bilibili", defaults[1].id)
        assertEquals("https://www.bilibili.com", defaults[1].url)
        assertEquals("default-campus", defaults[7].id)
        assertEquals("校园网", defaults[7].name)
        assertEquals("https://www.sdust.edu.cn", defaults[7].url)
        // 保存空列表后读取也回到默认（契约：为空 → defaultQuickLinks()）
        store.saveQuickLinks(emptyList())
        assertEquals(BrowserStore.defaultQuickLinks(), store.loadQuickLinks())
    }

    @Test
    fun quickLinksSaveLoadRoundTrip() {
        val store = newStore()
        val custom = listOf(
            BrowserQuickLink(id = "q1", name = "百度", url = "https://www.baidu.com", createdAt = 1L),
            BrowserQuickLink(id = "q2", name = "示例", url = "https://example.com", createdAt = 2L)
        )
        store.saveQuickLinks(custom)
        assertEquals(custom, store.loadQuickLinks())
    }

    @Test
    fun resetQuickLinksRestoresDefaults() {
        val store = newStore()
        store.saveQuickLinks(listOf(BrowserQuickLink(id = "only", name = "只剩一个", url = "https://a.com")))
        assertEquals(1, store.loadQuickLinks().size)

        store.resetQuickLinks()
        assertEquals(BrowserStore.defaultQuickLinks(), store.loadQuickLinks())
        assertEquals(8, store.loadQuickLinks().size)
    }

    @Test
    fun removeHistoryOnlyDeletesMatchingUrl() {
        val store = newStore()
        store.addHistory(BrowserHistoryEntry(title = "A", url = "https://a.com", visitedAt = 1L))
        store.addHistory(BrowserHistoryEntry(title = "B", url = "https://b.com", visitedAt = 2L))
        store.addHistory(BrowserHistoryEntry(title = "C", url = "https://c.com", visitedAt = 3L))
        // 当前顺序：C, B, A
        store.removeHistory("https://b.com")
        val history = store.loadHistory()
        assertEquals(2, history.size)
        assertEquals(listOf("https://c.com", "https://a.com"), history.map { it.url })
        // 删除不存在的 url 不影响其余记录
        store.removeHistory("https://not-exist.com")
        assertEquals(2, store.loadHistory().size)
    }

    @Test
    fun removeDownloadOnlyDeletesMatchingId() {
        val store = newStore()
        repeat(3) { index ->
            store.addDownload(
                BrowserDownloadEntry(id = "d$index", name = "文件$index", url = "https://dl.example.com/$index")
            )
        }
        // 当前顺序：d2, d1, d0
        store.removeDownload("d1")
        val downloads = store.loadDownloads()
        assertEquals(2, downloads.size)
        assertEquals(listOf("d2", "d0"), downloads.map { it.id })
        store.removeDownload("not-exist")
        assertEquals(2, store.loadDownloads().size)
    }
}

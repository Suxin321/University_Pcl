package com.university.pcl

import com.university.pcl.data.AdBlockRules
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AdBlockRulesTest {

    @Test
    fun parseHandlesHostsFormatAndComments() {
        val rules = AdBlockRules.parse(
            """
            # 注释行
            0.0.0.0 ads.example.com
            127.0.0.1 tracker.example.net   # 行内注释
            plain.example.org

            """.trimIndent()
        )
        assertEquals(setOf("ads.example.com", "tracker.example.net", "plain.example.org"), rules)
    }

    @Test
    fun parseLowercasesAndSkipsBogusEntries() {
        val rules = AdBlockRules.parse(
            """
            # 本机 / 保留地址与非法条目都要跳过
            0.0.0.0 localhost
            0.0.0.0 127.0.0.1
            0.0.0.0 0.0.0.0
            0.0.0.0 ::1
            0.0.0.0 path/with/slash.example.com
            0.0.0.0 ADS.Example.COM
            """.trimIndent()
        )
        assertEquals(setOf("ads.example.com"), rules)
    }

    @Test
    fun parseHandlesTabsAndMultipleSpaces() {
        val rules = AdBlockRules.parse("0.0.0.0\tads.example.com\n0.0.0.0   track.example.net\n")
        assertEquals(setOf("ads.example.com", "track.example.net"), rules)
    }

    @Test
    fun blockedHostMatchesExactAndSubdomain() {
        val rules = AdBlockRules.parse("0.0.0.0 doubleclick.net")
        assertTrue(AdBlockRules.isBlockedHost("doubleclick.net", rules))
        assertTrue(AdBlockRules.isBlockedHost("stats.g.doubleclick.net", rules))
        assertTrue(AdBlockRules.isBlockedHost("DOUBLECLICK.NET.", rules)) // 大写 + 尾部点
        assertFalse(AdBlockRules.isBlockedHost("notdoubleclick.net", rules))
        assertFalse(AdBlockRules.isBlockedHost("doubleclick.net.evil.com", rules))
        assertFalse(AdBlockRules.isBlockedHost("", rules))
        assertFalse(AdBlockRules.isBlockedHost("doubleclick.net", emptySet()))
    }

    @Test
    fun blockedHostDoesNotMatchSuffixImpostor() {
        val rules = AdBlockRules.parse("0.0.0.0 ads.example.com")
        assertTrue(AdBlockRules.isBlockedHost("ads.example.com", rules))
        assertTrue(AdBlockRules.isBlockedHost("x.ads.example.com", rules))
        assertFalse(AdBlockRules.isBlockedHost("notads.example.com.evil", rules))
    }

    @Test
    fun shouldBlockChecksUrlHost() {
        val rules = AdBlockRules.parse("0.0.0.0 ads.doubleclick.net\n0.0.0.0 tracker.example.net")
        assertTrue(AdBlockRules.shouldBlock("https://ads.doubleclick.net/pagead/x", rules))
        assertTrue(AdBlockRules.shouldBlock("http://Tracker.Example.NET:8080/a", rules))
        assertFalse(AdBlockRules.shouldBlock("https://example.com/", rules))
        assertFalse(AdBlockRules.shouldBlock("", rules))
        assertFalse(AdBlockRules.shouldBlock("https://example.com", emptySet()))
    }
}

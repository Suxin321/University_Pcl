package com.university.pcl

import com.university.pcl.data.FreeTimetableParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class FreeTimetableParserTest {

    @Test
    fun weekSpecVariants() {
        assertEquals(true to emptyList<Int>(), FreeTimetableParser.parseWeekSpec(""))
        assertEquals(true to emptyList<Int>(), FreeTimetableParser.parseWeekSpec("   "))
        assertEquals(false to (16..20).toList(), FreeTimetableParser.parseWeekSpec("16-20"))
        assertEquals(
            false to (1..8).toList() + (13..20).toList(),
            FreeTimetableParser.parseWeekSpec("1-8 13-20")
        )
        assertEquals(
            false to listOf(1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 19),
            FreeTimetableParser.parseWeekSpec("1-6 8-11 19")
        )
        assertEquals(
            false to listOf(14, 15, 17, 18, 19, 20),
            FreeTimetableParser.parseWeekSpec("14 15 17-20")
        )
        assertEquals(false to (16..20).toList(), FreeTimetableParser.parseWeekSpec("16~20"))
        // 全角数字也认
        assertEquals(false to (3..5).toList(), FreeTimetableParser.parseWeekSpec("３－５"))
        // 写了数字但全部超出有效周次：按「所有周」处理，别把人静默排除
        assertEquals(true to emptyList<Int>(), FreeTimetableParser.parseWeekSpec("45"))
    }

    @Test
    fun memberLines() {
        val a = FreeTimetableParser.parseMemberLine("刘如航16-20")
        assertNotNull(a)
        assertEquals("刘如航", a!!.name)
        assertFalse(a.allWeeks)
        assertEquals((16..20).toList(), a.weeks)

        val b = FreeTimetableParser.parseMemberLine("孙继泽")
        assertNotNull(b)
        assertEquals("孙继泽", b!!.name)
        assertTrue(b.allWeeks)

        val c = FreeTimetableParser.parseMemberLine(" 王妍1-6 8-11 19 ")
        assertNotNull(c)
        assertEquals("王妍", c!!.name)
        assertEquals(listOf(1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 19), c.weeks)

        assertNull(FreeTimetableParser.parseMemberLine(""))
        assertNull(FreeTimetableParser.parseMemberLine("   "))
    }

    @Test
    fun weekdaysAndBigSections() {
        assertEquals(1, FreeTimetableParser.weekdayOf("星期一")!!)
        assertEquals(2, FreeTimetableParser.weekdayOf("周二")!!)
        assertEquals(7, FreeTimetableParser.weekdayOf("星期日")!!)
        assertEquals(5, FreeTimetableParser.bigSectionOf("第五大节")!!)
        assertEquals(3, FreeTimetableParser.bigSectionOf("第3大节")!!)
    }

    @Test
    fun parseXlsxFixture() {
        val url = FreeTimetableParserTest::class.java.classLoader!!.getResource("sample_free_timetable.xlsx")
        assertNotNull("测试用 xlsx 资源缺失", url)
        val temp = File.createTempFile("free_timetable", ".xlsx")
        try {
            url!!.openStream().use { input -> temp.outputStream().use { output -> input.copyTo(output) } }
            val table = FreeTimetableParser.parse(temp)
            assertEquals(listOf(1, 2, 3), table.days)
            assertEquals(listOf("张三", "李四", "王五"), table.members)
            assertEquals(8, table.maxWeek)
            assertEquals(3 * 5, table.cells.size)

            // 第 1 周周一第一大节：张三(1-2) 和李四（所有周）有空，王五只有 3-4、6 有空
            assertEquals(listOf("张三", "李四"), table.freeNames(1, 1, 1))
            assertEquals(listOf("李四", "王五"), table.freeNames(1, 1, 6))
            // 周二第一大节：李四 1-8
            assertEquals(listOf("张三", "李四", "王五"), table.freeNames(2, 1, 3))
        } finally {
            temp.delete()
        }
    }

    @Test
    fun parseInlineStringSheet() {
        val xml = """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>
              <row r="1"><c r="A1" t="inlineStr"><is><t>空课表</t></is></c></row>
              <row r="2">
                <c r="B2" t="inlineStr"><is><t>星期一</t></is></c>
                <c r="C2" t="inlineStr"><is><t>星期二</t></is></c>
              </row>
              <row r="3">
                <c r="A3" t="inlineStr"><is><t>第一大节</t></is></c>
                <c r="B3" t="inlineStr"><is><t>张三</t></is></c>
              </row>
            </sheetData></worksheet>
        """.trimIndent()
        val rows = FreeTimetableParser.parseSheetXml(xml, emptyList())
        assertTrue(rows.size >= 3)
        val table = FreeTimetableParser.parseGrid(rows)
        assertEquals(listOf(1, 2), table.days)
        assertEquals(listOf("张三"), table.members)
        assertTrue(table.freeNames(1, 1, 5).contains("张三"))
        // 周二第一大节没填人
        assertTrue(table.freeNames(2, 1, 5).isEmpty())
    }
}

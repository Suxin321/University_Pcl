package com.university.pcl

import com.university.pcl.data.FreeCell
import com.university.pcl.data.FreeTableEditor
import com.university.pcl.data.FreeTimetable
import com.university.pcl.data.MemberFree
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FreeTableEditorTest {

    private fun table(): FreeTimetable {
        val cells = ArrayList<FreeCell>()
        for (day in 1..2) {
            for (big in 1..2) {
                cells.add(
                    FreeCell(
                        day = day,
                        bigSection = big,
                        members = listOf(MemberFree("张三", allWeeks = true), MemberFree("李四", weeks = listOf(1, 2)))
                    )
                )
            }
        }
        return FreeTimetable(days = listOf(1, 2), cells = cells, members = listOf("张三", "李四"), maxWeek = 2)
    }

    @Test
    fun addMemberOnlyInSelectedSlots() {
        val updated = FreeTableEditor.addMember(
            table(), "新人", allWeeks = false, weeks = listOf(1, 3),
            slots = setOf(1 to 1, 2 to 2)
        )
        assertTrue(updated.members.contains("新人"))
        assertTrue(updated.cell(1, 1)!!.members.any { it.name == "新人" })
        assertTrue(updated.cell(2, 2)!!.members.any { it.name == "新人" })
        assertTrue(updated.cell(1, 2)!!.members.none { it.name == "新人" })
        val member = updated.cell(1, 1)!!.members.first { it.name == "新人" }
        assertEquals(listOf(1, 3), member.weeks)
        assertTrue(!member.allWeeks)
    }

    @Test
    fun updateAndRemoveMember() {
        var updated = FreeTableEditor.updateMember(
            table(), "张三", allWeeks = false, weeks = listOf(4), slots = setOf(2 to 1)
        )
        assertTrue(updated.cell(2, 1)!!.members.any { it.name == "张三" })
        assertTrue(updated.cell(1, 1)!!.members.none { it.name == "张三" })
        assertEquals(setOf(2 to 1), FreeTableEditor.slotsOf(updated, "张三"))
        assertEquals("4", FreeTableEditor.weeksTextOf(updated, "张三"))

        updated = FreeTableEditor.removeMember(updated, "张三")
        assertTrue(updated.members.none { it == "张三" })
        assertTrue(FreeTableEditor.slotsOf(updated, "张三").isEmpty())
    }
}

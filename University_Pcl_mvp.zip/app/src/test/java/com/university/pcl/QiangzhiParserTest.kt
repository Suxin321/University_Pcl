package com.university.pcl

import com.university.pcl.data.QiangzhiParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class QiangzhiParserTest {

    private val emptyCell = "<div class=\"kbcontent\">&nbsp;</div>"

    private fun courseInner(name: String, teacher: String, weeks: String, room: String): String =
        "$name<br>" +
            "<font title='老师'>$teacher</font><br>" +
            "<font title='周次(节次)'>$weeks</font><br>" +
            "<font title='教室'>$room</font>"

    private fun courseCell(name: String, teacher: String, weeks: String, room: String): String =
        "<div class=\"kbcontent\">${courseInner(name, teacher, weeks, room)}</div>"

    private fun table(vararg rows: List<String>): String {
        val sb = StringBuilder("<html><body><table>")
        rows.forEach { row ->
            sb.append("<tr>")
            row.forEach { sb.append("<td>").append(it).append("</td>") }
            sb.append("</tr>")
        }
        sb.append("</table></body></html>")
        return sb.toString()
    }

    private fun emptyRow(): List<String> = List(7) { emptyCell }

    private fun rowWith(dayIndex: Int, cell: String): List<String> =
        List(7) { index -> if (index == dayIndex) cell else emptyCell }

    @Test
    fun parsesOneCourse() {
        val items = QiangzhiParser.parse(table(rowWith(0, courseCell("高等数学", "张伟", "1-16周", "J1-101"))))
        assertEquals(1, items.size)
        val course = items[0]
        assertEquals("高等数学", course.name)
        assertEquals("张伟", course.teacher)
        assertEquals("J1-101", course.room)
        assertEquals(1, course.day)
        assertEquals(1, course.bigSection)
        assertEquals((1..16).toList(), course.weeks)
        assertEquals(0, course.parity)
        assertTrue(course.activeIn(3))
        assertFalse(course.activeIn(17))
    }

    @Test
    fun mapsBigSectionsFromRowIndex() {
        val items = QiangzhiParser.parse(
            table(
                emptyRow(),
                emptyRow(),
                rowWith(2, courseCell("线性代数", "李娜", "1-16周", "J3-205"))
            )
        )
        assertEquals(1, items.size)
        val course = items[0]
        assertEquals("线性代数", course.name)
        assertEquals(3, course.day)
        assertEquals(2, course.bigSection)
    }

    @Test
    fun weekParityFiltering() {
        val items = QiangzhiParser.parse(table(rowWith(0, courseCell("大学英语", "王芳", "1-8周(单)", "文科楼A302"))))
        val course = items[0]
        assertEquals((1..8).toList(), course.weeks)
        assertEquals(1, course.parity)
        assertTrue(course.activeIn(3))
        assertFalse(course.activeIn(4))
        assertFalse(course.activeIn(9))
    }

    @Test
    fun parsesWeekTextVariants() {
        assertEquals((1..16).toList() to 0, QiangzhiParser.parseWeekText("1-16周"))
        assertEquals((1..8).toList() to 1, QiangzhiParser.parseWeekText("1-8周(单)"))
        assertEquals((1..8).toList() to 2, QiangzhiParser.parseWeekText("1-8周（双）"))
        assertEquals(listOf(1, 2, 3, 4, 6, 7, 8), QiangzhiParser.parseWeekText("1-4,6-8周").first)
        assertEquals(listOf(5), QiangzhiParser.parseWeekText("5周").first)
        assertEquals(emptyList<Int>() to 0, QiangzhiParser.parseWeekText(""))
        // 周次字段带节次时，节次不能混进周次
        assertEquals((1..16).toList() to 0, QiangzhiParser.parseWeekText("1-16周(1-2节)"))
        assertEquals((1..16).toList() to 1, QiangzhiParser.parseWeekText("1-16周(1-2节)(单)"))
        // 无括号但带节次的写法：不能把节次当成周次
        assertEquals((1..8).toList() to 0, QiangzhiParser.parseWeekText("1-8周 1-2节"))
    }

    @Test
    fun splitsMultipleCoursesInOneCell() {
        val cell = "<div class=\"kbcontent\">" +
            courseInner("数据结构实验", "刘强", "1-16周", "信息楼B401") +
            "----------" +
            courseInner("程序设计", "赵敏", "9-16周", "信息楼B305") +
            "</div>"
        val items = QiangzhiParser.parse(table(rowWith(4, cell)))
        assertEquals(2, items.size)
        assertEquals("数据结构实验", items[0].name)
        assertEquals("程序设计", items[1].name)
        assertEquals(5, items[0].day)
        assertEquals(5, items[1].day)
        assertEquals(items[0].bigSection, items[1].bigSection)
    }

    @Test
    fun bigSectionFromJieciBeatsRowIndex() {
        // 单元格在第 1 行（行号回退应为大节1），但周次字段写着 5-6节 -> 大节3
        val items = QiangzhiParser.parse(
            table(rowWith(0, courseCell("计算机网络", "孙磊", "1-16周(5-6节)", "信息楼C201")))
        )
        assertEquals(1, items.size)
        assertEquals(3, items[0].bigSection)
    }

    @Test
    fun ignoresEmptyCells() {
        assertEquals(0, QiangzhiParser.parse(table(emptyRow(), emptyRow())).size)
    }
}

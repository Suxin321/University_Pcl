package com.university.pcl

import com.university.pcl.data.DutyScheduler
import com.university.pcl.data.DutyShift
import com.university.pcl.data.FreeCell
import com.university.pcl.data.FreeTimetable
import com.university.pcl.data.MemberFree
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DutySchedulerTest {

    private fun fullyFreeTable(people: List<String>, days: Int = 5): FreeTimetable {
        val cells = ArrayList<FreeCell>()
        for (day in 1..days) {
            for (big in 1..5) {
                cells.add(FreeCell(day, big, people.map { MemberFree(it, allWeeks = true) }))
            }
        }
        return FreeTimetable(days = (1..days).toList(), cells = cells, members = people, maxWeek = 0)
    }

    @Test
    fun fillsEverySlotAndBalances() {
        val people = (1..10).map { "成员$it" }
        val free = fullyFreeTable(people)
        val shifts = DutyScheduler.generate(free, 1, 2, 1, false)

        assertEquals(50, shifts.size) // 2 周 × 5 天 × 5 大节
        shifts.forEach { assertEquals(1, it.names.size) }
        val counts = people.map { person -> shifts.count { it.names.contains(person) } }
        assertEquals("总数应平均分配：$counts", 5, counts.minOrNull() ?: -1)
        assertEquals(5, counts.maxOrNull() ?: -1)
    }

    @Test
    fun perSlotPlacesRequestedCount() {
        val people = (1..20).map { "成员$it" }
        val free = fullyFreeTable(people)
        val shifts = DutyScheduler.generate(free, 1, 1, 2, false)

        assertEquals(25, shifts.size)
        shifts.forEach { assertEquals(2, it.names.size) }
        assertEquals(50, shifts.sumOf { it.names.size })
    }

    @Test
    fun onlyAssignsPeopleFreeThatWeek() {
        val cells = ArrayList<FreeCell>()
        for (day in 1..5) {
            for (big in 1..5) {
                cells.add(
                    FreeCell(
                        day, big,
                        listOf(
                            MemberFree("甲", allWeeks = false, weeks = listOf(1)),
                            MemberFree("乙", allWeeks = false, weeks = listOf(2))
                        )
                    )
                )
            }
        }
        val free = FreeTimetable(days = (1..5).toList(), cells = cells, members = listOf("甲", "乙"), maxWeek = 2)
        val shifts = DutyScheduler.generate(free, 1, 2, 1, false)

        shifts.filter { it.week == 1 }.forEach { assertEquals(listOf("甲"), it.names) }
        shifts.filter { it.week == 2 }.forEach { assertEquals(listOf("乙"), it.names) }
    }

    @Test
    fun skipsSlotsWithNobodyFree() {
        val cells = ArrayList<FreeCell>()
        for (day in 1..5) {
            for (big in 1..5) {
                val members = if (day == 1 && big == 1) {
                    emptyList()
                } else {
                    listOf(MemberFree("甲", allWeeks = true))
                }
                cells.add(FreeCell(day, big, members))
            }
        }
        val free = FreeTimetable(days = (1..5).toList(), cells = cells, members = listOf("甲"), maxWeek = 0)
        val shifts = DutyScheduler.generate(free, 1, 1, 1, false)

        assertEquals(25, shifts.size)
        assertTrue(shifts.first { it.day == 1 && it.bigSection == 1 }.names.isEmpty())
    }

    @Test
    fun avoidSameDayKeepsOneShiftPerDay() {
        val people = (1..10).map { "成员$it" }
        val free = fullyFreeTable(people)
        val shifts = DutyScheduler.generate(free, 1, 1, 1, true)

        shifts.groupBy { it.day }.forEach { (_, list) ->
            val names = list.flatMap { it.names }
            assertEquals("同一天不应重复：$names", names.size, names.distinct().size)
        }
        assertTrue(shifts.all { it.names.size == 1 })
    }

    @Test
    fun countByPersonSortsByCount() {
        val shifts = listOf(
            DutyShift(1, 1, 1, listOf("甲", "乙")),
            DutyShift(1, 1, 2, listOf("甲"))
        )
        assertEquals(listOf("甲" to 2, "乙" to 1), DutyScheduler.countByPerson(shifts))
    }

    @Test
    fun emptyTimetableProducesNothing() {
        val empty = FreeTimetable()
        assertTrue(DutyScheduler.generate(empty, 1, 3, 1, false).isEmpty())
    }
}

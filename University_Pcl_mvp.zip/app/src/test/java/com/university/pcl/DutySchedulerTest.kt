package com.university.pcl

import com.university.pcl.data.DutyScheduler
import com.university.pcl.data.DutyShift
import com.university.pcl.data.FreeCell
import com.university.pcl.data.FreeTimetable
import com.university.pcl.data.MemberFree
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DutySchedulerTest {

    private fun fullyFreeTable(people: List<String>, days: Int = 5): FreeTimetable {
        val cells = ArrayList<FreeCell>()
        for (day in 1..days) {
            for (big in 1..5) {
                cells.add(FreeCell(day, big, people.map { MemberFree(it, allWeeks = true) }))
            }
        }
        return FreeTimetable(days = (1..days).toList(), cells = cells, members = people, maxWeek = 0)
    }

    @Test
    fun fillsEverySlotAndBalances() {
        val people = (1..10).map { "成员$it" }
        val free = fullyFreeTable(people)
        val shifts = DutyScheduler.generate(free, 1, 2, 1, false)

        assertEquals(50, shifts.size) // 2 周 × 5 天 × 5 大节
        shifts.forEach { assertEquals(1, it.names.size) }
        val counts = people.map { person -> shifts.count { it.names.contains(person) } }
        assertEquals("总数应平均分配：$counts", 5, counts.minOrNull() ?: -1)
        assertEquals(5, counts.maxOrNull() ?: -1)
    }

    @Test
    fun perSlotPlacesRequestedCount() {
        val people = (1..20).map { "成员$it" }
        val free = fullyFreeTable(people)
        val shifts = DutyScheduler.generate(free, 1, 1, 2, false)

        assertEquals(25, shifts.size)
        shifts.forEach { assertEquals(2, it.names.size) }
        assertEquals(50, shifts.sumOf { it.names.size })
    }

    @Test
    fun onlyAssignsPeopleFreeThatWeek() {
        val cells = ArrayList<FreeCell>()
        for (day in 1..5) {
            for (big in 1..5) {
                cells.add(
                    FreeCell(
                        day, big,
                        listOf(
                            MemberFree("甲", allWeeks = false, weeks = listOf(1)),
                            MemberFree("乙", allWeeks = false, weeks = listOf(2))
                        )
                    )
                )
            }
        }
        val free = FreeTimetable(days = (1..5).toList(), cells = cells, members = listOf("甲", "乙"), maxWeek = 2)
        val shifts = DutyScheduler.generate(free, 1, 2, 1, false)

        shifts.filter { it.week == 1 }.forEach { assertEquals(listOf("甲"), it.names) }
        shifts.filter { it.week == 2 }.forEach { assertEquals(listOf("乙"), it.names) }
    }

    @Test
    fun skipsSlotsWithNobodyFree() {
        val cells = ArrayList<FreeCell>()
        for (day in 1..5) {
            for (big in 1..5) {
                val members = if (day == 1 && big == 1) {
                    emptyList()
                } else {
                    listOf(MemberFree("甲", allWeeks = true))
                }
                cells.add(FreeCell(day, big, members))
            }
        }
        val free = FreeTimetable(days = (1..5).toList(), cells = cells, members = listOf("甲"), maxWeek = 0)
        val shifts = DutyScheduler.generate(free, 1, 1, 1, false)

        assertEquals(25, shifts.size)
        assertTrue(shifts.first { it.day == 1 && it.bigSection == 1 }.names.isEmpty())
    }

    @Test
    fun avoidSameDayKeepsOneShiftPerDay() {
        val people = (1..10).map { "成员$it" }
        val free = fullyFreeTable(people)
        val shifts = DutyScheduler.generate(free, 1, 1, 1, true)

        shifts.groupBy { it.day }.forEach { (_, list) ->
            val names = list.flatMap { it.names }
            assertEquals("同一天不应重复：$names", names.size, names.distinct().size)
        }
        assertTrue(shifts.all { it.names.size == 1 })
    }

    @Test
    fun strictAvoidSameDayLeavesSlotsEmpty() {
        // 只有 3 个人但要每时段 2 人：严格模式不重复于同一天，排不满就留空（不再偷偷重复）
        val people = listOf("甲", "乙", "丙")
        val free = fullyFreeTable(people)
        val shifts = DutyScheduler.generate(free, 1, 1, 2, true)

        assertEquals(25, shifts.size)
        shifts.groupBy { it.day }.forEach { (_, list) ->
            val names = list.flatMap { it.names }
            assertEquals("同一天不应重复：$names", names.size, names.distinct().size)
            assertTrue("一天最多 3 人：$names", names.size <= people.size)
        }
        assertTrue("严格模式应留空：${shifts.map { it.names.size }}", shifts.any { it.names.isEmpty() })
    }

    @Test
    fun allowRepeatFillsRequestedCount() {
        // 打开「允许同一人重复」后才回退顶人
        val people = listOf("甲", "乙", "丙")
        val free = fullyFreeTable(people)
        val shifts = DutyScheduler.generate(free, 1, 1, 2, true, false, allowRepeat = true)

        assertEquals(25, shifts.size)
        shifts.forEach { shift -> assertEquals("每时段应排满 2 人：$shift", 2, shift.names.size) }
    }

    @Test
    fun strictAvoidSameWeekLeavesSlotsEmpty() {
        // 一天 5 个时段、3 个人、开「同一周不重复」：严格模式最多排 3 个班，其余留空
        val people = listOf("甲", "乙", "丙")
        val cells = ArrayList<FreeCell>()
        for (big in 1..5) {
            cells.add(FreeCell(1, big, people.map { MemberFree(it, allWeeks = true) }))
        }
        val free = FreeTimetable(days = listOf(1), cells = cells, members = people, maxWeek = 1)
        val shifts = DutyScheduler.generate(free, 1, 1, 1, false, true)

        assertEquals(5, shifts.size)
        assertEquals(3, shifts.count { it.names.isNotEmpty() })
        assertEquals(3, shifts.flatMap { it.names }.distinct().size)
    }

    @Test
    fun avoidSameWeekKeepsOneShiftPerWeek() {
        // 一天 5 个时段、10 个人：开了「同一周不重复」后，一周内 5 个班必须是 5 个不同的人
        val people = (1..10).map { "成员$it" }
        val cells = ArrayList<FreeCell>()
        for (big in 1..5) {
            cells.add(FreeCell(1, big, people.map { MemberFree(it, allWeeks = true) }))
        }
        val free = FreeTimetable(days = listOf(1), cells = cells, members = people, maxWeek = 1)
        val shifts = DutyScheduler.generate(free, 1, 1, 1, false, true)

        assertEquals(5, shifts.size)
        val names = shifts.flatMap { it.names }
        assertEquals(5, names.size)
        assertEquals("同一周不应重复：$names", 5, names.distinct().size)
    }

    @Test
    fun onlySelectedSectionsAreScheduled() {
        val people = (1..10).map { "成员$it" }
        val free = fullyFreeTable(people)
        val shifts = DutyScheduler.generate(free, 1, 1, 1, false, false, sections = listOf(2, 4))

        assertEquals(2 * 5, shifts.size) // 1 周 × 5 天 × 2 节
        assertEquals(setOf(2, 4), shifts.map { it.bigSection }.toSet())
        shifts.forEach { assertEquals(1, it.names.size) }
    }

    @Test
    fun onlySelectedMembersAreScheduled() {
        val people = (1..10).map { "成员$it" }
        val free = fullyFreeTable(people)
        val chosen = listOf("成员1", "成员2")
        val shifts = DutyScheduler.generate(free, 1, 1, 1, false, false, members = chosen)

        assertEquals(25, shifts.size)
        shifts.forEach { shift -> assertTrue("只应排选中的人：$shift", shift.names.all { it in chosen }) }
        assertEquals(chosen.sorted(), shifts.flatMap { it.names }.distinct().sorted())
    }

    @Test
    fun onlySelectedDaysAreScheduled() {
        val people = (1..10).map { "成员$it" }
        val free = fullyFreeTable(people)
        val shifts = DutyScheduler.generate(free, 1, 1, 1, false, false, days = listOf(2, 4))

        assertEquals(2 * 5, shifts.size)
        assertEquals(setOf(2, 4), shifts.map { it.day }.toSet())
        shifts.forEach { assertEquals(1, it.names.size) }
    }

    @Test
    fun countByPersonSortsByCount() {
        val shifts = listOf(
            DutyShift(1, 1, 1, listOf("甲", "乙")),
            DutyShift(1, 1, 2, listOf("甲"))
        )
        assertEquals(listOf("甲" to 2, "乙" to 1), DutyScheduler.countByPerson(shifts))
    }

    @Test
    fun emptyTimetableProducesNothing() {
        val empty = FreeTimetable()
        assertTrue(DutyScheduler.generate(empty, 1, 3, 1, false).isEmpty())
    }
}

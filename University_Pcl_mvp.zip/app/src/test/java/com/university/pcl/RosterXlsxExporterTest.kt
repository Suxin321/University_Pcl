package com.university.pcl

import com.university.pcl.data.DutyShift
import com.university.pcl.data.RosterXlsxExporter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.zip.ZipInputStream

class RosterXlsxExporterTest {

    private fun entries(bytes: ByteArray): Map<String, String> {
        val result = LinkedHashMap<String, String>()
        ZipInputStream(bytes.inputStream()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                result[entry.name] = zip.readBytes().toString(Charsets.UTF_8)
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        return result
    }

    @Test
    fun dutyTimeLabelMatchesSampleStyle() {
        assertEquals("8：00-9：50", RosterXlsxExporter.dutyTimeLabel("08:00-09:50"))
        assertEquals("2：00-3：50", RosterXlsxExporter.dutyTimeLabel("14:00-15:50"))
        assertEquals("", RosterXlsxExporter.dutyTimeLabel(""))
    }

    @Test
    fun buildsWeeklySheetsAndCountStats() {
        val shifts = listOf(
            DutyShift(13, 4, 1, listOf("张煜祺")),
            DutyShift(13, 5, 1, listOf("孙继泽")),
            DutyShift(13, 4, 1, listOf("张煜祺"))
        )
        val bytes = RosterXlsxExporter.buildRoster(
            shifts = shifts,
            startWeek = 13,
            endWeek = 13,
            days = listOf(1, 2, 3, 4, 5),
            sections = listOf(1, 2),
            slotTimes = listOf("08:00-09:50", "10:10-12:00"),
            members = listOf("张煜祺", "孙继泽", "王妍"),
            adjust = mapOf("王妍" to 1)
        )
        val entries = entries(bytes)

        assertTrue(entries.containsKey("xl/workbook.xml"))
        assertTrue(entries.containsKey("xl/worksheets/sheet1.xml"))
        assertTrue(entries.containsKey("xl/worksheets/sheet2.xml"))

        val workbook = entries.getValue("xl/workbook.xml")
        assertTrue(workbook.contains("第13周值班表"))
        assertTrue(workbook.contains("值班次数统计"))

        assertTrue(entries.containsKey("xl/styles.xml"))
        assertTrue(entries.containsKey("xl/sharedStrings.xml"))
        assertTrue(entries.containsKey("docProps/core.xml"))
        assertTrue(entries.containsKey("docProps/app.xml"))

        val strings = entries.getValue("xl/sharedStrings.xml")
        assertTrue(strings.contains("时间"))
        assertTrue(strings.contains("序号. 姓名"))
        assertTrue(strings.contains("次数"))
        assertTrue(strings.contains("周一"))
        assertTrue(strings.contains("8：00-9：50"))
        assertTrue(strings.contains("张煜祺"))
        assertTrue(strings.contains("1. 张煜祺"))
        assertTrue(strings.contains("3. 王妍"))

        val weekSheet = entries.getValue("xl/worksheets/sheet1.xml")
        assertTrue(weekSheet.contains("<dimension"))
        assertTrue(weekSheet.contains("t=\"s\""))

        val statSheet = entries.getValue("xl/worksheets/sheet2.xml")
        assertTrue(statSheet.contains("<v>1</v>"))
    }
}

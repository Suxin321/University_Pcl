package com.university.pcl.ui.browser

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import com.university.pcl.data.AdBlockRules
import com.university.pcl.data.BrowserSettings
import java.io.ByteArrayInputStream

/**
 * 为每个标签页创建一个 WebView，并统一配置：
 * JS / DOM 存储 / 混合内容放行 / 第三方 Cookie / UA（桌面版）/ 强制深色 / 广告拦截 / 下载 / 文件选择 / JS 弹窗。
 *
 * 「限制少」的具体落点都在这里：明文 HTTP、混合内容、第三方 Cookie、任意下载、可改 UA 都默认放开。
 */
@SuppressLint("SetJavaScriptEnabled")
class BrowserWebViewFactory(
    private val context: Context,
    private val adRules: Set<String>,
    initialSettings: BrowserSettings,
    /** 拦截到一条广告请求（回来在主线程，可以安全写 Compose 状态）。 */
    private val onBlocked: () -> Unit,
    /** 该标签页的加载进度变化。 */
    private val onProgress: (BrowserTab, Int) -> Unit,
    /** 该标签页的标题变化。 */
    private val onTitle: (BrowserTab, String) -> Unit,
    /** 页面加载完成后回调：用来记历史、刷新前进/后退状态。 */
    private val onVisited: (BrowserTab) -> Unit,
    /** 收到下载请求：文件名 + 链接。 */
    private val onDownload: (String, String) -> Unit,
    /** 网页请求选择文件：把回调交给 ActivityResult，返回是否接管。 */
    private val onFileChooser: (ValueCallback<Array<Uri>>) -> Boolean,
    /** 长按链接 / 页面内滚动（标签页、当前滚动位置、上一次位置）。 */
    private val onScroll: (BrowserTab, Int, Int) -> Unit
) {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var settings: BrowserSettings = initialSettings
    private val defaultUa: String = WebSettings.getDefaultUserAgent(context)
    private val desktopUa: String =
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/122.0.0.0 Safari/537.36"

    fun updateSettings(newSettings: BrowserSettings) {
        settings = newSettings
    }

    /** 设置变化后（桌面版 / 深色）应用到已经创建的 WebView。 */
    fun applyTo(webView: WebView) {
        applyUa(webView)
        applyDarkMode(webView)
    }

    fun create(tab: BrowserTab): WebView {
        val webView = WebView(context)
        webView.layoutParams = ViewGroup.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = true
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
            javaScriptCanOpenWindowsAutomatically = true
            // 弹窗/新窗口统一在当前标签页打开，不额外接 onCreateWindow
            setSupportMultipleWindows(false)
            // 限制少：https 页面里允许加载 http 资源
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            allowFileAccess = false
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        applyUa(webView)
        applyDarkMode(webView)
        webView.setBackgroundColor(0xFFFFFFFF.toInt())

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                val scheme = uri.scheme?.lowercase() ?: return false
                return when (scheme) {
                    "http", "https", "about" -> false
                    // 其他 scheme（tel: mailto: 支付宝/微信等）交给系统处理
                    else -> {
                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                        true
                    }
                }
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                if (view == null || url == null) return
                tab.url = url
                tab.canGoBack = view.canGoBack()
                tab.canGoForward = view.canGoForward()
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (view == null) return
                tab.canGoBack = view.canGoBack()
                tab.canGoForward = view.canGoForward()
                val title = view.title?.trim().orEmpty()
                if (title.isNotEmpty()) tab.title = title
                onVisited(tab)
            }

            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                if (request == null) return null
                // 主文档不拦（用户主动打开的页面要能显示），只拦页面内资源
                if (request.isForMainFrame) return null
                if (!settings.adBlock) return null
                val url = request.url?.toString() ?: return null
                if (!AdBlockRules.shouldBlock(url, adRules)) return null
                // 回调可能发生在后台线程，切回主线程再改状态
                mainHandler.post { onBlocked() }
                return WebResourceResponse(
                    "text/plain",
                    "utf-8",
                    ByteArrayInputStream(ByteArray(0))
                )
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                onProgress(tab, newProgress)
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                if (!title.isNullOrBlank()) onTitle(tab, title)
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                if (filePathCallback == null) return false
                return onFileChooser(filePathCallback)
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                // 相机/麦克风默认拒绝，避免网页无提示占用
                request?.deny()
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                // 地理位置默认拒绝（App 没有申请定位权限）
                callback?.invoke(origin, false, false)
            }

            override fun onJsAlert(
                view: WebView?,
                url: String?,
                message: String?,
                result: JsResult?
            ): Boolean = showJsDialog("网页提示", message.orEmpty(), result, null)

            override fun onJsConfirm(
                view: WebView?,
                url: String?,
                message: String?,
                result: JsResult?
            ): Boolean = showJsDialog("网页询问", message.orEmpty(), result, true)

            override fun onJsPrompt(
                view: WebView?,
                url: String?,
                message: String?,
                defaultValue: String?,
                result: JsPromptResult?
            ): Boolean {
                val input = EditText(context).apply {
                    setText(defaultValue.orEmpty())
                    setSingleLine()
                }
                return runCatching {
                    AlertDialog.Builder(context)
                        .setTitle("网页输入")
                        .setMessage(message.orEmpty())
                        .setView(input)
                        .setPositiveButton("确定") { _, _ -> result?.confirm(input.text.toString()) }
                        .setNegativeButton("取消") { _, _ -> result?.cancel() }
                        .setOnCancelListener { result?.cancel() }
                        .show()
                    true
                }.getOrDefault(false)
            }
        }

        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            val fileName = runCatching {
                android.webkit.URLUtil.guessFileName(url, contentDisposition, mimeType)
            }.getOrDefault("download")
            onDownload(fileName, url)
        }

        webView.setOnScrollChangeListener { _, _, scrollY, _, oldScrollY ->
            onScroll(tab, scrollY, oldScrollY)
        }

        return webView
    }

    private fun applyUa(webView: WebView) {
        runCatching {
            webView.settings.userAgentString = if (settings.desktopMode) desktopUa else defaultUa
        }
    }

    private fun applyDarkMode(webView: WebView) {
        if (Build.VERSION.SDK_INT >= 33) {
            runCatching { webView.settings.setAlgorithmicDarkeningAllowed(settings.forceDark) }
        }
    }

    private fun showJsDialog(
        title: String,
        message: String,
        result: JsResult?,
        confirmOnly: Boolean?
    ): Boolean = runCatching {
        val builder = AlertDialog.Builder(context)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("确定") { _, _ -> result?.confirm() }
            .setOnCancelListener { result?.cancel() }
        if (confirmOnly == null) {
            // alert：没有取消按钮
        } else {
            builder.setNegativeButton("取消") { _, _ -> result?.cancel() }
        }
        builder.show()
        true
    }.getOrDefault(false)
}

package com.university.pcl.data

import kotlinx.serialization.Serializable
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.UUID

/** 计划类型：待办（勾选完成）/ 计数（点一次 +1，累计到目标次数）。 */
object PlanType {
    const val TODO = "todo"
    const val COUNT = "count"
}

/**
 * 一条计划。
 * - type = todo：用 done 表示是否完成；
 * - type = count：用 current/target 表示进度（如「跑步 30 次」→ current=3, target=30）。
 * - date 为空表示没有日期（长期计划），否则为 yyyy-MM-dd。
 */
@Serializable
data class PlanItem(
    val id: String = "",
    val title: String = "",
    val type: String = PlanType.TODO,
    val date: String = "",
    val done: Boolean = false,
    val current: Int = 0,
    val target: Int = 1,
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L
) {
    val isCount: Boolean get() = type == PlanType.COUNT

    /** 计数类目标值，至少 1。 */
    val targetSafe: Int get() = target.coerceIn(1, 999)

    /** 计数类当前值，限制在 0..targetSafe。 */
    val currentSafe: Int get() = current.coerceIn(0, targetSafe)

    fun isCompleted(): Boolean =
        if (isCount) currentSafe >= targetSafe else done

    fun progressPercent(): Int =
        if (isCount) (currentSafe * 100 / targetSafe) else if (done) 100 else 0
}

/** 本地 JSON 文件结构（便于以后加字段）。 */
@Serializable
data class PlanFile(val items: List<PlanItem> = emptyList())

/** 计划统计（「计划统计表」用）。 */
data class PlanSummary(
    val total: Int = 0,
    val completed: Int = 0,
    val pending: Int = 0,
    val overdue: Int = 0,
    val todoTotal: Int = 0,
    val todoDone: Int = 0,
    val countTotal: Int = 0,
    val countDone: Int = 0,
    val countTargetTotal: Int = 0,
    val percent: Int = 0
) {
    val todoPercent: Int
        get() = if (todoTotal == 0) 0 else todoDone * 100 / todoTotal

    /** 计数类累计完成次数 / 累计目标次数。 */
    val countPercent: Int
        get() = if (countTargetTotal == 0) 0 else (countDone * 100 / countTargetTotal).coerceIn(0, 100)
}

object PlanStats {

    /** 汇总统计；today 为 yyyy-MM-dd（用于判断过期）。 */
    fun summarize(items: List<PlanItem>, today: String): PlanSummary {
        var completed = 0
        var overdue = 0
        var todoTotal = 0
        var todoDone = 0
        var countTotal = 0
        var countDone = 0
        var countTargetTotal = 0
        for (item in items) {
            if (item.isCompleted()) completed++
            if (item.isOverdue(today)) overdue++
            if (item.isCount) {
                countTotal++
                countDone += item.currentSafe
                countTargetTotal += item.targetSafe
            } else {
                todoTotal++
                if (item.done) todoDone++
            }
        }
        val total = items.size
        val pending = total - completed
        val percent = if (total == 0) 0 else completed * 100 / total
        return PlanSummary(
            total = total,
            completed = completed,
            pending = pending,
            overdue = overdue,
            todoTotal = todoTotal,
            todoDone = todoDone,
            countTotal = countTotal,
            countDone = countDone,
            countTargetTotal = countTargetTotal,
            percent = percent
        )
    }
}

fun PlanItem.isOverdue(today: String): Boolean =
    !isCompleted() && date.isNotBlank() && date < today

object PlanText {
    const val NO_DATE = "无日期"

    fun todayString(): String = LocalDate.now().toString()

    fun newId(): String = UUID.randomUUID().toString().replace("-", "")

    /** 日期显示：今天 / 明天 / 昨天 / MM-dd / 无日期。 */
    fun dateLabel(item: PlanItem, today: String): String {
        if (item.date.isBlank()) return NO_DATE
        return when (item.date) {
            today -> "今天"
            shift(today, 1) -> "明天"
            shift(today, -1) -> "昨天"
            else -> shortDate(item.date)
        }
    }

    /** MM-dd，用于小空间显示。 */
    fun shortDate(date: String): String =
        if (date.length == 10) date.substring(5) else date

    /** 计数进度显示：3/10。 */
    fun progressLabel(item: PlanItem): String =
        if (item.isCount) "${item.currentSafe}/${item.targetSafe}" else ""

    /** 状态文案（计划统计表里的「状态」列）。 */
    fun statusLabel(item: PlanItem, today: String): String = when {
        item.isCompleted() -> "已完成"
        item.isOverdue(today) -> "已过期"
        item.date == today -> "今天"
        item.date.isBlank() -> "进行中"
        else -> "未完成"
    }

    /** 保存计划时统一日期格式；非法返回空串（= 无日期）。 */
    fun normalizeDate(raw: String): String {
        val text = raw.trim()
        if (text.isEmpty()) return ""
        return runCatching {
            val parsed = LocalDate.parse(text, DateTimeFormatter.ofPattern("yyyy-M-d"))
            parsed.toString()
        }.getOrNull() ?: runCatching {
            LocalDate.parse(text)
        }.getOrNull()?.toString().orEmpty()
    }

    /** date 加 n 天，返回 yyyy-MM-dd；解析失败原样返回。 */
    fun shift(date: String, days: Long): String {
        if (date.isBlank()) return ""
        return runCatching { LocalDate.parse(date).plusDays(days).toString() }.getOrDefault(date)
    }

    /** 把 "30" / "30次" / "30个" 解析成次数，非法返回 null。 */
    fun parseTarget(raw: String): Int? {
        val digits = raw.trim().filter { it.isDigit() }
        if (digits.isEmpty()) return null
        val value = digits.toIntOrNull() ?: return null
        if (value <= 0) return null
        return value.coerceIn(1, 999)
    }
}

/** 计划排序：默认按 过期 → 今天/日期近 → 创建时间。 */
object PlanSort {

    fun forApp(items: List<PlanItem>, today: String): List<PlanItem> =
        items.sortedWith(comparator(today))

    /**
     * 桌面组件用：先把「过期 / 今天」的排前面，再按日期和创建时间。
     * limit <= 0 表示不限制条数。
     */
    fun forWidget(items: List<PlanItem>, today: String, limit: Int): List<PlanItem> {
        val sorted = items.sortedWith(comparator(today))
        return if (limit > 0) sorted.take(limit) else sorted
    }

    private fun comparator(today: String): Comparator<PlanItem> = Comparator { a, b ->
        val aDone = if (a.isCompleted()) 1 else 0
        val bDone = if (b.isCompleted()) 1 else 0
        if (aDone != bDone) return@Comparator aDone - bDone

        val aOverdue = if (a.isOverdue(today)) 0 else 1
        val bOverdue = if (b.isOverdue(today)) 0 else 1
        if (aOverdue != bOverdue) return@Comparator aOverdue - bOverdue

        // 有日期的排前面，日期近的排前面
        val aHas = if (a.date.isBlank()) 1 else 0
        val bHas = if (b.date.isBlank()) 1 else 0
        if (aHas != bHas) return@Comparator aHas - bHas
        if (a.date != b.date) return@Comparator a.date.compareTo(b.date)

        val aCreated = a.createdAt
        val bCreated = b.createdAt
        if (aCreated != bCreated) return@Comparator if (aCreated < bCreated) -1 else 1
        a.title.compareTo(b.title)
    }
}

/** 计划的增删改与打卡操作（纯函数，便于单测；组件回调和应用界面共用）。 */
object PlanEditor {

    /** 新建一条计划（补全 id / 时间戳 / 计数默认值）。 */
    fun create(
        title: String,
        type: String,
        date: String = "",
        target: Int = 1,
        now: Long = System.currentTimeMillis()
    ): PlanItem {
        val cleanTitle = title.trim()
        val cleanType = if (type == PlanType.COUNT) PlanType.COUNT else PlanType.TODO
        return PlanItem(
            id = PlanText.newId(),
            title = cleanTitle,
            type = cleanType,
            date = PlanText.normalizeDate(date),
            done = false,
            current = 0,
            target = if (cleanType == PlanType.COUNT) target.coerceIn(1, 999) else 1,
            createdAt = now,
            updatedAt = now
        )
    }

    fun upsert(items: List<PlanItem>, item: PlanItem): List<PlanItem> {
        val exists = items.any { it.id == item.id }
        return if (exists) items.map { if (it.id == item.id) item else it } else items + item
    }

    fun remove(items: List<PlanItem>, id: String): List<PlanItem> =
        items.filterNot { it.id == id }

    /** 待办：勾选/取消完成。 */
    fun toggleTodo(items: List<PlanItem>, id: String, now: Long = System.currentTimeMillis()): List<PlanItem> =
        items.map {
            if (it.id == id && !it.isCount) {
                it.copy(done = !it.done, updatedAt = now)
            } else {
                it
            }
        }

    /** 计数：+1（到目标后不再增加，视为完成）。 */
    fun increment(items: List<PlanItem>, id: String, now: Long = System.currentTimeMillis()): List<PlanItem> =
        items.map {
            if (it.id == id && it.isCount) {
                val next = (it.currentSafe + 1).coerceAtMost(it.targetSafe)
                it.copy(current = next, updatedAt = now)
            } else {
                it
            }
        }

    /** 计数：-1（不低于 0）。 */
    fun decrement(items: List<PlanItem>, id: String, now: Long = System.currentTimeMillis()): List<PlanItem> =
        items.map {
            if (it.id == id && it.isCount) {
                val next = (it.currentSafe - 1).coerceAtLeast(0)
                it.copy(current = next, updatedAt = now)
            } else {
                it
            }
        }

    /** 组件/应用里统一的「打卡」：待办翻转，计数 +1。 */
    fun toggleOrIncrement(
        items: List<PlanItem>,
        id: String,
        now: Long = System.currentTimeMillis()
    ): List<PlanItem> {
        val item = items.firstOrNull { it.id == id } ?: return items
        return if (item.isCount) increment(items, id, now) else toggleTodo(items, id, now)
    }

    /** 计数类计划设为完成（current = target）。 */
    fun finish(items: List<PlanItem>, id: String, now: Long = System.currentTimeMillis()): List<PlanItem> =
        items.map {
            if (it.id == id && it.isCount) {
                it.copy(current = it.targetSafe, updatedAt = now)
            } else if (it.id == id) {
                it.copy(done = true, updatedAt = now)
            } else {
                it
            }
        }
}

package com.university.pcl.widget

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.university.pcl.data.WeekUtil
import java.util.concurrent.TimeUnit

/** 组件/课表的自动刷新调度：6 小时周期 + 每天 00:05 跨天刷新。 */
object WidgetRefreshScheduler {

    private const val PERIODIC_WORK = "pcl_periodic_refresh"
    private const val DAILY_WORK = "pcl_daily_refresh"

    fun ensureScheduled(context: Context) {
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            PERIODIC_WORK,
            ExistingPeriodicWorkPolicy.UPDATE,
            PeriodicWorkRequestBuilder<RefreshWorker>(6, TimeUnit.HOURS).build()
        )
        scheduleDaily(context)
        MinuteTickAlarm.schedule(context)
    }

    /** 桌面上没有组件实例时停掉每分钟的自动刷新（由 [MinuteTickReceiver] 调用）。 */
    fun cancelMinuteTick(context: Context) {
        MinuteTickAlarm.cancel(context)
    }

    fun scheduleDaily(context: Context) {
        WorkManager.getInstance(context).enqueueUniqueWork(
            DAILY_WORK,
            ExistingWorkPolicy.REPLACE,
            OneTimeWorkRequestBuilder<RefreshWorker>()
                .setInitialDelay(WeekUtil.millisToNextDay(), TimeUnit.MILLISECONDS)
                .build()
        )
    }
}

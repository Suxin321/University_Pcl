package com.university.pcl.data

import java.time.LocalDate
import java.time.temporal.ChronoUnit

object WeekUtil {

    /** 由开学日期推算当前周次；无有效日期返回 0。 */
    fun weekFromStart(startDate: String, today: LocalDate = LocalDate.now()): Int {
        if (startDate.isBlank()) return 0
        return runCatching {
            val start = LocalDate.parse(startDate)
            val days = ChronoUnit.DAYS.between(start, today)
            if (days < 0) 1 else (days / 7).toInt() + 1
        }.getOrDefault(0)
    }

    /** 按当前日期猜学期，形如 2026-2027-1。 */
    fun guessTerm(today: LocalDate = LocalDate.now()): String {
        val y = today.year
        val m = today.monthValue
        return when {
            m >= 8 -> "$y-${y + 1}-1"
            m >= 2 -> "${y - 1}-$y-2"
            else -> "${y - 1}-$y-1"
        }
    }

    /** 距离下一个 00:05 的毫秒数（用于跨天刷新）。 */
    fun millisToNextDay(): Long {
        val now = System.currentTimeMillis()
        val next = LocalDate.now().plusDays(1).atTime(0, 5)
            .atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        return (next - now).coerceAtLeast(60_000L)
    }
}

package com.university.pcl.ui.browser

import android.net.Uri
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebStorage
import android.webkit.WebView
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.university.pcl.data.AdBlockRules
import com.university.pcl.data.BrowserBookmark
import com.university.pcl.data.BrowserDownloadEntry
import com.university.pcl.data.BrowserHistoryEntry
import com.university.pcl.data.BrowserQuickLink
import com.university.pcl.data.BrowserSettings
import com.university.pcl.data.BrowserStore
import com.university.pcl.data.BrowserUrls
import kotlinx.coroutines.delay

private const val MAX_TABS = 8

/** 一个标签页：标题 / 地址 / 是否无痕 / 进度 / 是否能前进后退 + 自己的 WebView。 */
@Stable
class BrowserTab(val id: Int, incognito: Boolean = false) {
    var title by mutableStateOf("新标签页")
    var url by mutableStateOf("")
    var incognito by mutableStateOf(incognito)
    var progress by mutableStateOf(0)
    var canGoBack by mutableStateOf(false)
    var canGoForward by mutableStateOf(false)
    var webView: WebView? = null
}

/**
 * 「浏览」页：地址栏 + WebView + 多标签 + 书签/历史/下载/设置。
 *
 * 返回键优先级：关菜单/标签总览 → 网页后退 → 回主页 → 切到课表页（不退出 App）。
 */
@Composable
fun BrowserContent(
    isActive: Boolean,
    onExitToSchedule: () -> Unit
) {
    val context = LocalContext.current
    val store = remember { BrowserStore(context) }

    var settings by remember { mutableStateOf(store.loadSettings()) }
    var bookmarks by remember { mutableStateOf(store.loadBookmarks()) }
    var history by remember { mutableStateOf(store.loadHistory()) }
    var downloads by remember { mutableStateOf(store.loadDownloads()) }
    var quickLinks by remember { mutableStateOf(store.loadQuickLinks()) }
    var blockedCount by remember { mutableIntStateOf(0) }

    val adRules = remember {
        runCatching {
            context.assets.open("adblock_hosts.txt").bufferedReader().use {
                AdBlockRules.parse(it.readText())
            }
        }.getOrDefault(emptySet())
    }

    val tabs = remember { mutableStateListOf(BrowserTab(0, settings.defaultIncognito)) }
    var currentIndex by remember { mutableIntStateOf(0) }
    var nextTabId by remember { mutableIntStateOf(1) }
    var internalPage by remember { mutableStateOf<BrowserPage?>(null) }
    var shownInternal by remember { mutableStateOf<BrowserPage?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    var tabsOpen by remember { mutableStateOf(false) }
    var addressEditing by remember { mutableStateOf(false) }
    var addressText by remember { mutableStateOf("") }
    var topBarVisible by remember { mutableStateOf(true) }
    var toastText by remember { mutableStateOf<String?>(null) }
    var fileCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }

    val fileLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        val callback = fileCallback
        fileCallback = null
        callback?.onReceiveValue(if (uris.isNullOrEmpty()) null else uris.toTypedArray())
    }

    val factory = remember {
        BrowserWebViewFactory(
            context = context,
            adRules = adRules,
            initialSettings = settings,
            onBlocked = { blockedCount++ },
            onProgress = { tab, progress -> tab.progress = progress },
            onTitle = { tab, title -> if (title.isNotBlank()) tab.title = title },
            onVisited = { tab ->
                tab.canGoBack = tab.webView?.canGoBack() ?: false
                tab.canGoForward = tab.webView?.canGoForward() ?: false
                if (!tab.incognito && tab.url.isNotBlank()) {
                    store.addHistory(
                        BrowserHistoryEntry(
                            title = tab.title,
                            url = tab.url,
                            visitedAt = System.currentTimeMillis()
                        )
                    )
                    history = store.loadHistory()
                }
            },
            onDownload = { name, url ->
                store.addDownload(BrowserDownloadEntry(BrowserStore.newId(), name, url))
                downloads = store.loadDownloads()
                toastText = "已加入下载：$name"
            },
            onFileChooser = { callback ->
                fileCallback = callback
                runCatching { fileLauncher.launch(arrayOf("*/*")) }
                true
            },
            onScroll = { tab, scrollY, oldScrollY ->
                if (tab.id == tabs.getOrNull(currentIndex)?.id) {
                    if (scrollY < oldScrollY || scrollY < 40) {
                        topBarVisible = true
                    } else if (scrollY > oldScrollY + 8 && scrollY > 90) {
                        topBarVisible = false
                    }
                }
            }
        )
    }

    // 设置变化：应用到已经创建的 WebView
    LaunchedEffect(settings) {
        factory.updateSettings(settings)
        tabs.forEach { tab -> tab.webView?.let { factory.applyTo(it) } }
    }
    // 地址栏跟随当前标签
    LaunchedEffect(currentIndex, tabs.getOrNull(currentIndex)?.url, addressEditing) {
        if (!addressEditing) {
            val url = tabs.getOrNull(currentIndex)?.url.orEmpty()
            addressText = if (url.isNotEmpty()) BrowserUrls.displayUrl(url) else ""
        }
    }
    // 二级页退出动画期间保留内容，避免闪白
    LaunchedEffect(internalPage) {
        if (internalPage != null) shownInternal = internalPage
    }
    LaunchedEffect(toastText) {
        if (toastText != null) {
            delay(1600)
            toastText = null
        }
    }

    val currentTab = tabs.getOrNull(currentIndex)

    fun showToast(message: String) {
        toastText = message
    }

    fun persistSettings(newSettings: BrowserSettings) {
        settings = newSettings
        store.saveSettings(newSettings)
    }

    fun loadUrlInCurrentTab(input: String) {
        val tab = tabs.getOrNull(currentIndex) ?: return
        val target = BrowserUrls.normalizeInput(input, settings.searchEngine)
        if (target.isBlank()) return
        val webView = tab.webView ?: factory.create(tab).also { tab.webView = it }
        tab.url = target
        tab.title = BrowserUrls.displayUrl(target)
        internalPage = null
        addressEditing = false
        addressText = BrowserUrls.displayUrl(target)
        topBarVisible = true
        addressEditing = false
        webView.loadUrl(target)
    }

    fun newTab() {
        if (tabs.size >= MAX_TABS) {
            showToast("最多同时打开 $MAX_TABS 个标签页")
            return
        }
        tabs.add(BrowserTab(nextTabId++, settings.defaultIncognito))
        currentIndex = tabs.lastIndex
        internalPage = null
        menuOpen = false
        tabsOpen = false
        topBarVisible = true
        addressText = ""
    }

    fun closeTab(tab: BrowserTab) {
        if (tabs.size <= 1) {
            showToast("至少保留一个标签页")
            return
        }
        val index = tabs.indexOf(tab)
        if (index < 0) return
        tabs.removeAt(index)
        tab.webView?.let { webView ->
            runCatching {
                webView.stopLoading()
                webView.loadUrl("about:blank")
                webView.destroy()
            }
        }
        tab.webView = null
        if (currentIndex >= tabs.size) currentIndex = tabs.lastIndex
        else if (index < currentIndex) currentIndex--
        shownInternal = null
        showToast(if (tab.incognito) "已关闭无痕标签页" else "已关闭标签页")
    }

    fun switchTab(tab: BrowserTab) {
        val index = tabs.indexOf(tab)
        if (index < 0) return
        currentIndex = index
        tabsOpen = false
        internalPage = null
        topBarVisible = true
    }

    fun toggleBookmark() {
        val tab = tabs.getOrNull(currentIndex) ?: return
        if (tab.url.isEmpty()) {
            showToast("先打开一个网页再收藏")
            return
        }
        val existing = bookmarks.firstOrNull { it.url == tab.url }
        bookmarks = if (existing != null) {
            bookmarks.filterNot { it.url == tab.url }
        } else {
            listOf(
                BrowserBookmark(
                    id = BrowserStore.newId(),
                    title = tab.title.ifBlank { BrowserUrls.displayUrl(tab.url) },
                    url = tab.url,
                    createdAt = System.currentTimeMillis()
                )
            ) + bookmarks
        }
        store.saveBookmarks(bookmarks)
        showToast(if (existing != null) "已取消收藏" else "已加入书签")
    }

    fun goHome() {
        val tab = tabs.getOrNull(currentIndex) ?: return
        tab.webView?.stopLoading()
        tab.url = ""
        tab.title = "新标签页"
        tab.progress = 0
        addressText = ""
        topBarVisible = true
        internalPage = null
    }

    fun pageBack() {
        val tab = tabs.getOrNull(currentIndex) ?: return
        val webView = tab.webView
        if (webView != null && tab.url.isNotEmpty() && webView.canGoBack()) {
            webView.goBack()
            return
        }
        if (tab.url.isNotEmpty()) {
            goHome()
            return
        }
        onExitToSchedule()
    }

    fun handleBack() {
        when {
            menuOpen -> menuOpen = false
            tabsOpen -> tabsOpen = false
            internalPage != null -> internalPage = null
            else -> pageBack()
        }
    }

    fun addQuickLink(name: String, rawUrl: String): Boolean {
        val input = rawUrl.trim()
        if (input.isEmpty()) {
            showToast("请先填网址")
            return false
        }
        if (!BrowserUrls.isUrlLike(input)) {
            showToast("网址格式不对，例如 baidu.com")
            return false
        }
        val url = BrowserUrls.normalizeInput(input, settings.searchEngine)
        val title = name.trim().ifEmpty {
            BrowserUrls.hostOf(url).ifEmpty { BrowserUrls.displayUrl(url) }
        }
        val updated = quickLinks + BrowserQuickLink(
            id = BrowserStore.newId(),
            name = title,
            url = url,
            createdAt = System.currentTimeMillis()
        )
        quickLinks = updated
        store.saveQuickLinks(updated)
        showToast("已添加：$title")
        return true
    }

    fun deleteQuickLink(link: BrowserQuickLink) {
        quickLinks = quickLinks.filterNot { it.id == link.id }
        store.saveQuickLinks(quickLinks)
        showToast("已删除快捷入口")
    }

    fun resetQuickLinks() {
        store.resetQuickLinks()
        quickLinks = store.loadQuickLinks()
        showToast("已恢复默认快捷入口")
    }

    /** 释放网页占用的缓存（不删书签/历史/登录态）。 */
    fun freeMemory() {
        var count = 0
        tabs.forEach { tab ->
            tab.webView?.let { webView ->
                runCatching {
                    webView.clearCache(true)
                    count++
                }
            }
        }
        runCatching { CookieManager.getInstance().flush() }
        showToast(if (count > 0) "已释放 $count 个标签的网页缓存" else "已释放网页缓存")
    }

    fun clearBrowsingData() {
        store.clearHistory()
        store.clearDownloads()
        history = emptyList()
        downloads = emptyList()
        runCatching {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
        }
        runCatching { WebStorage.getInstance().deleteAllData() }
        tabs.forEach { tab -> tab.webView?.clearCache(true) }
        showToast("已清除浏览数据")
    }

    BackHandler(enabled = isActive) { handleBack() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(Modifier.fillMaxSize()) {
            val showTopBar = internalPage == null &&
                currentTab != null &&
                currentTab.url.isNotEmpty() &&
                (topBarVisible || addressEditing)
            AnimatedVisibility(
                visible = showTopBar,
                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut()
            ) {
                Column {
                    BrowserTopBar(
                        address = addressText,
                        bookmarked = currentTab?.let { tab ->
                            bookmarks.any { it.url == tab.url }
                        } == true,
                        onAddressChange = { addressText = it },
                        onFocusChange = { focused ->
                            addressEditing = focused
                            if (focused) topBarVisible = true
                        },
                        onGo = { loadUrlInCurrentTab(addressText) },
                        onBack = { pageBack() },
                        onStar = { toggleBookmark() },
                        onMenu = { menuOpen = true }
                    )
                    val progress = currentTab?.progress ?: 0
                    if (progress in 1..99) {
                        LinearProgressIndicator(
                            progress = { progress / 100f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(2.dp),
                            color = MaterialTheme.colorScheme.primary,
                            trackColor = Color.Transparent
                        )
                    }
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (currentTab == null) {
                    DesktopHint()
                } else if (currentTab.url.isEmpty()) {
                    BrowserHomePage(
                        engine = settings.searchEngine,
                        quickLinks = quickLinks,
                        onSearch = { input -> loadUrlInCurrentTab(input) },
                        onOpen = { url -> loadUrlInCurrentTab(url) },
                        onEditQuickLinks = { internalPage = BrowserPage.QuickLinks },
                        onMenu = { menuOpen = true }
                    )
                } else {
                    key(currentTab.id) {
                        BrowserWebHost(tab = currentTab, modifier = Modifier.fillMaxSize())
                    }
                }
            }
        }

        // 二级页（书签 / 历史 / 下载 / 设置）
        AnimatedVisibility(
            visible = internalPage != null,
            enter = fadeIn() + slideInVertically(initialOffsetY = { it / 14 }),
            exit = fadeOut() + slideOutVertically(targetOffsetY = { it / 14 }),
            modifier = Modifier.fillMaxSize()
        ) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                when (shownInternal) {
                    BrowserPage.Bookmarks -> BrowserBookmarksPage(
                        items = bookmarks,
                        onOpen = { bookmark -> loadUrlInCurrentTab(bookmark.url) },
                        onDelete = { bookmark ->
                            bookmarks = bookmarks.filterNot { it.id == bookmark.id }
                            store.saveBookmarks(bookmarks)
                            showToast("已删除书签")
                        },
                        onBack = { internalPage = null }
                    )

                    BrowserPage.History -> BrowserHistoryPage(
                        items = history,
                        onOpen = { entry -> loadUrlInCurrentTab(entry.url) },
                        onDelete = { entry ->
                            store.removeHistory(entry.url)
                            history = store.loadHistory()
                            showToast("已删除该条历史")
                        },
                        onClear = {
                            store.clearHistory()
                            history = emptyList()
                            showToast("已清空历史")
                        },
                        onBack = { internalPage = null }
                    )

                    BrowserPage.Downloads -> BrowserDownloadsPage(
                        items = downloads,
                        onDelete = { entry ->
                            store.removeDownload(entry.id)
                            downloads = store.loadDownloads()
                            showToast("已删除该条下载记录")
                        },
                        onClear = {
                            store.clearDownloads()
                            downloads = emptyList()
                            showToast("已清空下载记录")
                        },
                        onBack = { internalPage = null }
                    )

                    BrowserPage.Settings -> BrowserSettingsPage(
                        settings = settings,
                        blockedCount = blockedCount,
                        onChange = { persistSettings(it) },
                        onClearData = { clearBrowsingData() },
                        onBack = { internalPage = null }
                    )

                    BrowserPage.QuickLinks -> BrowserQuickLinksPage(
                        links = quickLinks,
                        onAdd = { name, url -> addQuickLink(name, url) },
                        onDelete = { link -> deleteQuickLink(link) },
                        onReset = { resetQuickLinks() },
                        onBack = { internalPage = null }
                    )

                    null -> Spacer(Modifier.fillMaxSize())
                }
            }
        }

        // 轻提示
        AnimatedVisibility(
            visible = toastText != null,
            enter = fadeIn() + scaleIn(initialScale = 0.92f),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 26.dp)
        ) {
            Surface(shape = RoundedCornerShape(20.dp), color = Color(0xE6222226)) {
                Text(
                    text = toastText.orEmpty(),
                    color = Color.White,
                    fontSize = 12.5.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp)
                )
            }
        }

        // 菜单遮罩 + 底部面板
        if (menuOpen) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.32f))
                    .clickable { menuOpen = false }
            )
        }
        AnimatedVisibility(
            visible = menuOpen,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            BrowserMenuSheet(
                tabCount = tabs.size,
                bookmarkCount = bookmarks.size,
                blockedCount = blockedCount,
                incognito = currentTab?.incognito == true,
                settings = settings,
                onNewTab = { newTab() },
                onTabs = { tabsOpen = true; menuOpen = false },
                onBookmarks = { internalPage = BrowserPage.Bookmarks; menuOpen = false },
                onHistory = { internalPage = BrowserPage.History; menuOpen = false },
                onQuickLinks = { internalPage = BrowserPage.QuickLinks; menuOpen = false },
                onDownloads = { internalPage = BrowserPage.Downloads; menuOpen = false },
                onToggleIncognito = {
                    val tab = tabs.getOrNull(currentIndex)
                    if (tab != null) {
                        tab.incognito = !tab.incognito
                        showToast(if (tab.incognito) "无痕模式已开启 · 不记录历史" else "无痕模式已关闭")
                    }
                },
                onToggleAdBlock = { persistSettings(settings.copy(adBlock = !settings.adBlock)) },
                onToggleDesktop = {
                    persistSettings(settings.copy(desktopMode = !settings.desktopMode))
                    showToast(if (settings.desktopMode) "桌面版网站：开（刷新后生效）" else "桌面版网站：关（刷新后生效）")
                },
                onToggleDark = { persistSettings(settings.copy(forceDark = !settings.forceDark)) },
                onRefresh = {
                    menuOpen = false
                    tabs.getOrNull(currentIndex)?.webView?.reload()
                },
                onHome = {
                    menuOpen = false
                    goHome()
                },
                onSettings = { internalPage = BrowserPage.Settings; menuOpen = false },
                onFreeMemory = { menuOpen = false; freeMemory() }
            )
        }

        // 标签页总览
        AnimatedVisibility(
            visible = tabsOpen,
            enter = fadeIn() + scaleIn(initialScale = 0.98f),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Column(Modifier.fillMaxSize().padding(16.dp)) {
                    Text(
                        "标签页",
                        fontSize = 19.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(Modifier.height(12.dp))
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(11.dp)
                    ) {
                        items(tabs, key = { it.id }) { tab ->
                            BrowserTabCard(
                                tab = tab,
                                selected = tab.id == currentTab?.id,
                                onSelect = { switchTab(tab) },
                                onClose = { closeTab(tab) }
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Surface(
                            shape = RoundedCornerShape(23.dp),
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable { newTab() }
                                    .padding(vertical = 13.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("＋ 新建标签页", color = MaterialTheme.colorScheme.onPrimary, fontSize = 14.sp)
                            }
                        }
                        OutlinedButton(
                            onClick = { tabsOpen = false },
                            modifier = Modifier.height(46.dp),
                            shape = RoundedCornerShape(23.dp)
                        ) {
                            Text("完成", fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }

    // 离开浏览页时，把无痕标签的历史留在内存里即可；这里只做资源回收
    DisposableEffect(Unit) {
        onDispose {
            tabs.forEach { tab ->
                val webView = tab.webView
                if (webView != null) {
                    runCatching { (webView.parent as? ViewGroup)?.removeView(webView) }
                    runCatching { webView.destroy() }
                }
                tab.webView = null
            }
        }
    }
}

/* ============================ 顶栏 ============================ */

@Composable
private fun BrowserTopBar(
    address: String,
    bookmarked: Boolean,
    onAddressChange: (String) -> Unit,
    onFocusChange: (Boolean) -> Unit,
    onGo: () -> Unit,
    onBack: () -> Unit,
    onStar: () -> Unit,
    onMenu: () -> Unit
) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val isHttps = address.startsWith("https://") || address.startsWith("www.")
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .padding(horizontal = 6.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RoundIconText(text = "‹", fontSize = 27.sp, onClick = onBack)
        Spacer(Modifier.width(3.dp))
        Surface(
            shape = RoundedCornerShape(19.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .weight(1f)
                .height(38.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(start = 12.dp, end = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(if (isHttps) Color(0xFF10B981) else muted)
                )
                Spacer(Modifier.width(7.dp))
                BasicTextField(
                    value = address,
                    onValueChange = onAddressChange,
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 13.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { onGo() }),
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    modifier = Modifier
                        .weight(1f)
                        .onFocusChanged { onFocusChange(it.isFocused) },
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (address.isEmpty()) {
                                Text(
                                    "搜索或输入网址",
                                    color = muted,
                                    fontSize = 13.5.sp
                                )
                            }
                            inner()
                        }
                    }
                )
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .clickable(onClick = onStar),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (bookmarked) "★" else "☆",
                        fontSize = 19.sp,
                        color = if (bookmarked) MaterialTheme.colorScheme.primary else muted
                    )
                }
            }
        }
        RoundIconText(text = "⋮", fontSize = 20.sp, onClick = onMenu)
    }
}

@Composable
private fun RoundIconText(text: String, fontSize: androidx.compose.ui.unit.TextUnit, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, fontSize = fontSize, color = MaterialTheme.colorScheme.onSurface)
    }
}

/* ============================ WebView 容器 ============================ */

@Composable
private fun BrowserWebHost(tab: BrowserTab, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier,
        factory = { ctx ->
            FrameLayout(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
        },
        update = { frame ->
            val webView = tab.webView
            if (webView == null) {
                frame.removeAllViews()
            } else if (frame.childCount != 1 || frame.getChildAt(0) !== webView) {
                (webView.parent as? ViewGroup)?.removeView(webView)
                frame.removeAllViews()
                frame.addView(
                    webView,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
            }
        }
    )
}

/* ============================ 菜单面板 ============================ */

@Composable
private fun BrowserMenuSheet(
    tabCount: Int,
    bookmarkCount: Int,
    blockedCount: Int,
    incognito: Boolean,
    settings: BrowserSettings,
    onNewTab: () -> Unit,
    onTabs: () -> Unit,
    onBookmarks: () -> Unit,
    onHistory: () -> Unit,
    onQuickLinks: () -> Unit,
    onDownloads: () -> Unit,
    onToggleIncognito: () -> Unit,
    onToggleAdBlock: () -> Unit,
    onToggleDesktop: () -> Unit,
    onToggleDark: () -> Unit,
    onRefresh: () -> Unit,
    onHome: () -> Unit,
    onSettings: () -> Unit,
    onFreeMemory: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .heightIn(max = 620.dp)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 10.dp, vertical = 12.dp)
        ) {
            Box(
                Modifier
                    .align(Alignment.CenterHorizontally)
                    .size(width = 38.dp, height = 4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(MaterialTheme.colorScheme.outlineVariant)
            )
            Spacer(Modifier.height(10.dp))
            MenuRow("新建标签页", null, null, onNewTab)
            MenuRow("标签页", tabCount.toString(), null, onTabs)
            MenuRow("书签", bookmarkCount.toString(), null, onBookmarks)
            MenuRow("历史记录", null, null, onHistory)
            MenuRow("快捷入口", "编辑新标签页的常用站", null, onQuickLinks)
            MenuRow("下载", null, null, onDownloads)
            MenuDivider()
            MenuRow(
                "无痕模式",
                if (incognito) "已开启，不记录历史" else "关闭：正常记录历史",
                incognito,
                onToggleIncognito
            )
            MenuRow("桌面版网站", null, settings.desktopMode, onToggleDesktop)
            MenuRow("深色网页", null, settings.forceDark, onToggleDark)
            MenuRow("广告拦截", "本次已拦 $blockedCount 项", settings.adBlock, onToggleAdBlock)
            MenuDivider()
            MenuRow("浏览器设置", "搜索引擎 / 广告拦截 / 深色网页", null, onSettings)
            MenuRow("刷新", null, null, onRefresh)
            MenuRow("主页", null, null, onHome)
            MenuRow("释放内存", "清网页缓存，不删书签和历史", null, onFreeMemory)
        }
    }
}

@Composable
private fun MenuRow(
    label: String,
    subtitle: String?,
    switchOn: Boolean?,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                label,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (subtitle != null) {
                Text(
                    subtitle,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        if (switchOn != null) {
            Spacer(Modifier.width(10.dp))
            Switch(checked = switchOn, onCheckedChange = { onClick() })
        }
    }
}

@Composable
private fun MenuDivider() {
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 5.dp)
            .height(1.dp)
            .background(MaterialTheme.colorScheme.outlineVariant)
    )
}

/* ============================ 标签页卡片 ============================ */

@Composable
private fun BrowserTabCard(
    tab: BrowserTab,
    selected: Boolean,
    onSelect: () -> Unit,
    onClose: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        border = if (selected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = tab.title.ifBlank { "新标签页" },
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = if (tab.url.isEmpty()) "搜索或输入网址" else BrowserUrls.displayUrl(tab.url),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (tab.incognito) {
                Text("无痕", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(6.dp))
            }
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onClose),
                contentAlignment = Alignment.Center
            ) {
                Text("×", fontSize = 17.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun DesktopHint() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            "浏览器准备中…",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 13.sp
        )
    }
}

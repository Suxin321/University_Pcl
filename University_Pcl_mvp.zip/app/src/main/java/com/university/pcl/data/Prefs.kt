package com.university.pcl.data

import android.content.Context
import android.content.SharedPreferences

/** 本地配置与会话（MVP 用 SharedPreferences；账号密码不落盘，只存 Cookie）。 */
class Prefs(context: Context) {

    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("university_pcl", Context.MODE_PRIVATE)

    var baseUrl: String
        get() = sp.getString(KEY_BASE_URL, DEFAULT_URL) ?: DEFAULT_URL
        set(value) {
            val normalized = value.trim().trimEnd('/')
            sp.edit().putString(KEY_BASE_URL, normalized.ifBlank { DEFAULT_URL }).apply()
        }

    /** 学期，形如 2025-2026-1；留空时按日期猜。 */
    var term: String
        get() = sp.getString(KEY_TERM, "") ?: ""
        set(value) {
            sp.edit().putString(KEY_TERM, value.trim()).apply()
        }

    /** 手动指定周次；>0 时优先于开学日期推算。 */
    var week: Int
        get() = sp.getInt(KEY_WEEK, 0)
        set(value) {
            sp.edit().putInt(KEY_WEEK, value).apply()
        }

    /** 第 1 周周一日期 yyyy-MM-dd；留空则用手填周次。 */
    var semesterStart: String
        get() = sp.getString(KEY_SEMESTER_START, "") ?: ""
        set(value) {
            sp.edit().putString(KEY_SEMESTER_START, value.trim()).apply()
        }

    var cookies: String
        get() = sp.getString(KEY_COOKIES, "") ?: ""
        set(value) {
            sp.edit().putString(KEY_COOKIES, value).apply()
        }

    /** 首次「导出」时捕获到的课表下载地址，之后用它自动下载 .xls 刷新。 */
    var exportUrl: String
        get() = sp.getString(KEY_EXPORT_URL, "") ?: ""
        set(value) {
            sp.edit().putString(KEY_EXPORT_URL, value).apply()
        }

    /** 手动粘贴的「学期理论课表」页面地址（可选，优先使用）。 */
    var theoryUrl: String
        get() = sp.getString(KEY_THEORY_URL, "") ?: ""
        set(value) {
            sp.edit().putString(KEY_THEORY_URL, value.trim()).apply()
        }

    var lastSync: Long
        get() = sp.getLong(KEY_LAST_SYNC, 0L)
        set(value) {
            sp.edit().putLong(KEY_LAST_SYNC, value).apply()
        }

    /** 排班：每个时段需要几个人（1..6）。 */
    var rosterPerSlot: Int
        get() = sp.getInt(KEY_ROSTER_PER_SLOT, 1).coerceIn(1, 6)
        set(value) {
            sp.edit().putInt(KEY_ROSTER_PER_SLOT, value.coerceIn(1, 6)).apply()
        }

    /** 排班：同一个人同一天是否最多排 1 班。 */
    var rosterAvoidSameDay: Boolean
        get() = sp.getBoolean(KEY_ROSTER_AVOID_SAME_DAY, false)
        set(value) {
            sp.edit().putBoolean(KEY_ROSTER_AVOID_SAME_DAY, value).apply()
        }

    /** 排班：同一个人同一周是否最多排 1 班。 */
    var rosterAvoidSameWeek: Boolean
        get() = sp.getBoolean(KEY_ROSTER_AVOID_SAME_WEEK, false)
        set(value) {
            sp.edit().putBoolean(KEY_ROSTER_AVOID_SAME_WEEK, value).apply()
        }

    /** 排班：要排的大节（1..5），空/无有效值 = 全部。 */
    var rosterSections: List<Int>
        get() {
            val raw = sp.getString(KEY_ROSTER_SECTIONS, "") ?: ""
            val parsed = raw.split(',').mapNotNull { it.trim().toIntOrNull() }
                .filter { it in 1..BigSections.COUNT }
                .distinct()
                .sorted()
            return parsed.ifEmpty { (1..BigSections.COUNT).toList() }
        }
        set(value) {
            val cleaned = value.filter { it in 1..BigSections.COUNT }.distinct().sorted()
                .ifEmpty { (1..BigSections.COUNT).toList() }
            sp.edit().putString(KEY_ROSTER_SECTIONS, cleaned.joinToString(",")).apply()
        }

    /** 排班：每个大节的显示/导出时间，形如 "08:00-09:50"，共 5 项。 */
    var rosterSlotTimes: List<String>
        get() {
            val raw = sp.getString(KEY_ROSTER_SLOT_TIMES, "") ?: ""
            val parts = raw.split('|')
            return (0 until BigSections.COUNT).map { index ->
                parts.getOrNull(index)?.trim()?.takeIf { slotTimeRegex.matches(it) }
                    ?: defaultSlotTimes[index]
            }
        }
        set(value) {
            val cleaned = (0 until BigSections.COUNT).map { index ->
                value.getOrNull(index)?.trim()?.takeIf { slotTimeRegex.matches(it) }
                    ?: defaultSlotTimes[index]
            }
            sp.edit().putString(KEY_ROSTER_SLOT_TIMES, cleaned.joinToString("|")).apply()
        }

    private val slotTimeRegex = Regex("""^\d{1,2}:\d{2}-\d{1,2}:\d{2}$""")

    val isLoggedIn: Boolean
        get() = cookies.isNotBlank()

    fun clearSession() {
        sp.edit().remove(KEY_COOKIES).remove(KEY_LAST_SYNC).apply()
    }

    companion object {
        const val DEFAULT_URL = "https://jwglxt.sdust.edu.cn"
        private const val KEY_BASE_URL = "base_url"
        private const val KEY_TERM = "term"
        private const val KEY_WEEK = "week"
        private const val KEY_SEMESTER_START = "semester_start"
        private const val KEY_COOKIES = "cookies"
        private const val KEY_LAST_SYNC = "last_sync"
        private const val KEY_EXPORT_URL = "export_url"
        private const val KEY_THEORY_URL = "theory_url"
        private const val KEY_ROSTER_PER_SLOT = "roster_per_slot"
        private const val KEY_ROSTER_AVOID_SAME_DAY = "roster_avoid_same_day"
        private const val KEY_ROSTER_AVOID_SAME_WEEK = "roster_avoid_same_week"
        private const val KEY_ROSTER_SECTIONS = "roster_sections"
        private const val KEY_ROSTER_SLOT_TIMES = "roster_slot_times"

        val defaultSlotTimes = listOf(
            "08:00-09:50",
            "10:10-12:00",
            "14:00-15:50",
            "16:10-18:00",
            "19:00-20:50"
        )
    }
}

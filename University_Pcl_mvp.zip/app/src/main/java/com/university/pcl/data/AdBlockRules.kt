package com.university.pcl.data

/**
 * 离线广告拦截规则（hosts 文本的简化解析与匹配，纯函数，方便单测）。
 * 规则来自 assets/adblock_hosts.txt，用户也可以自己补充。
 */
object AdBlockRules {

    /** 本机 / 保留地址永远不拦，避免误伤本地服务。 */
    private val IGNORED_HOSTS = setOf("localhost", "127.0.0.1", "0.0.0.0", "::1")

    private val SPACES = Regex("\\s+")

    /**
     * 解析 hosts 文本：逐行去掉 # 之后的内容，trim 后跳过空行；
     * `0.0.0.0 ads.example.com` 这种取第 2 段，单段直接当域名；统一小写。
     */
    fun parse(text: String): Set<String> {
        val rules = LinkedHashSet<String>()
        for (rawLine in text.lineSequence()) {
            val line = rawLine.substringBefore('#').trim()
            if (line.isEmpty()) continue
            val parts = line.split(SPACES)
            val entry = (parts.getOrNull(1) ?: parts[0]).trim().lowercase()
            if (entry.isEmpty()) continue
            if (entry in IGNORED_HOSTS) continue
            if (entry.contains('/')) continue
            rules.add(entry)
        }
        return rules
    }

    /** host 是否命中规则（含子域）：规则 doubleclick.net 命中 doubleclick.net 和 x.doubleclick.net。 */
    fun isBlockedHost(host: String, rules: Set<String>): Boolean {
        if (rules.isEmpty()) return false
        val clean = host.trim().lowercase().trimEnd('.')
        if (clean.isEmpty()) return false
        for (rule in rules) {
            if (clean == rule || clean.endsWith(".$rule")) return true
        }
        return false
    }

    /** URL 是否命中广告规则（先取域名再匹配）。 */
    fun shouldBlock(url: String, rules: Set<String>): Boolean {
        if (rules.isEmpty()) return false
        val host = BrowserUrls.hostOf(url)
        if (host.isEmpty()) return false
        return isBlockedHost(host, rules)
    }
}

package com.university.pcl.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** HyperOS 风格配色（取自 Miuix 默认 scheme，见 research/hyperos-ui.md）。 */
private val BrandBlue = Color(0xFF3482FF)
private val BrandBlueDark = Color(0xFF277AF7)

private val LightColors = lightColorScheme(
    primary = BrandBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE8F1FF),
    onPrimaryContainer = Color(0xFF0B2B66),
    background = Color(0xFFFFFFFF),
    onBackground = Color(0xFF111111),
    surface = Color(0xFFF7F7F7),
    onSurface = Color(0xFF111111),
    surfaceVariant = Color(0xFFFFFFFF),
    onSurfaceVariant = Color(0xFF666666),
    outline = Color(0xFFD9D9D9),
    outlineVariant = Color(0xFFEFEFEF)
)

private val DarkColors = darkColorScheme(
    primary = BrandBlueDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF17325E),
    onPrimaryContainer = Color(0xFFD6E4FF),
    background = Color(0xFF242424),
    onBackground = Color(0xFFF3F3F3),
    surface = Color(0xFF000000),
    onSurface = Color(0xFFF3F3F3),
    surfaceVariant = Color(0xFF2C2C2E),
    onSurfaceVariant = Color(0xFFB9B9BD),
    outline = Color(0xFF404040),
    outlineVariant = Color(0xFF2F2F31)
)

@Composable
fun UniversityPclTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
        typography = Typography(),
        content = content
    )
}

package com.university.pcl.widget

import android.content.Context
import android.util.Log
import androidx.glance.appwidget.updateAll
import kotlin.coroutines.cancellation.CancellationException

/** 刷新所有桌面组件实例。 */
object WidgetUpdater {
    suspend fun update(context: Context) {
        try {
            ScheduleWidget().updateAll(context.applicationContext)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // 组件刷新失败不影响主流程（可能还没有组件实例）
            Log.w("WidgetUpdater", "updateAll failed", e)
        }
    }
}

package com.university.pcl.data

import org.jsoup.Jsoup
import org.jsoup.nodes.Element

/**
 * 强智教务系统（V8 新L / jsxsd）课表 HTML 解析。
 *
 * 规则：
 * 1. 取所有 div.kbcontent，按出现顺序编号：day = index % 7 + 1（星期），
 *    rowFallback = index / 7 / 2 + 1（按行号回退推算大节）。
 * 2. 一个单元格内多门课用 10 个以上 "-" 分隔；空课单元格含 &nbsp;。
 * 3. 课程名 = 首个 <br> 前文本；教师/周次/地点在 font[title=老师|周次(节次)|教室]。
 * 4. 大节优先从「周次(节次)」里的节次（如 3-4节）推算，缺失时才用行号回退。
 */
object QiangzhiParser {

    private val multiCourse = Regex("-{10,}")
    private val sectionInWeekText = Regex("""(\d+)\s*(?:[-,~]\s*\d+)?\s*节""")
    private val weekRange = Regex("""(\d+)(?:\s*[-~～]\s*(\d+))?""")

    fun parse(html: String): List<CourseSlot> {
        val doc = Jsoup.parse(html)
        val cells = doc.select("div.kbcontent")
        if (cells.isEmpty()) return emptyList()

        val result = ArrayList<CourseSlot>()
        cells.forEachIndexed { index, cell ->
            val day = index % 7 + 1
            val rowFallback = (index / 7 / 2 + 1).coerceIn(1, BigSections.COUNT)

            val rawHtml = cell.html()
            if (rawHtml.isBlank()) return@forEachIndexed
            val plain = cell.text().replace('\u00a0', ' ').trim()
            if (plain.isBlank()) return@forEachIndexed

            rawHtml.split(multiCourse).forEach { chunk ->
                val body = Jsoup.parseBodyFragment(chunk).body()
                parseOne(body, day, rowFallback)?.let(result::add)
            }
        }
        return result
    }

    private fun parseOne(body: Element, day: Int, rowFallback: Int): CourseSlot? {
        val fonts = body.select("font")
        fun fontText(title: String): String =
            fonts.firstOrNull { it.attr("title") == title }?.text()?.trim().orEmpty()

        val own = body.ownText().replace('\u00a0', ' ').trim()
        val name = own.ifBlank { body.selectFirst("font")?.text()?.trim().orEmpty() }
        if (name.isBlank() || name == "-") return null

        val weekText = fontText("周次(节次)")
        val (weeks, parity) = parseWeekText(weekText)
        val bigSection = sectionInWeekText.find(weekText)
            ?.groupValues?.get(1)?.toIntOrNull()
            ?.let { ((it - 1) / 2 + 1).coerceIn(1, BigSections.COUNT) }
            ?: rowFallback

        return CourseSlot(
            day = day,
            bigSection = bigSection,
            name = name,
            room = RoomText.compact(fontText("教室")),
            teacher = fontText("老师"),
            weekText = weekText,
            weeks = weeks,
            parity = parity
        )
    }

    /**
     * "1-16周" / "1-8周(单)" / "1-4,6-8周" / "1-16周(1-2节)" -> (周次集合, 0/1/2 单双周)
     * 只解析 "(" 前的周次段，括号里的节次不参与周次解析。
     */
    fun parseWeekText(raw: String): Pair<List<Int>, Int> {
        if (raw.isBlank()) return emptyList<Int>() to 0
        val normalized = raw.replace('（', '(').replace('）', ')')
        val parity = when {
            normalized.contains("单") -> 1
            normalized.contains("双") -> 2
            else -> 0
        }
        // 先切掉括号里的节次；无括号但带 "节" 的写法再从第一个「周」处截断
        var head = normalized.substringBefore("(")
        if (head.contains("周")) head = head.substringBefore("周")
        head = head.replace(" ", "")
        if (head.isBlank()) return emptyList<Int>() to parity

        val weeks = LinkedHashSet<Int>()
        weekRange.findAll(head).forEach { match ->
            val from = match.groupValues[1].toIntOrNull() ?: return@forEach
            val to = match.groupValues[2].toIntOrNull()
            if (to != null && to >= from) {
                for (week in from..to.coerceAtMost(from + 30)) {
                    if (week in 1..30) weeks.add(week)
                }
            } else if (from in 1..30) {
                weeks.add(from)
            }
        }
        return weeks.toList() to parity
    }
}

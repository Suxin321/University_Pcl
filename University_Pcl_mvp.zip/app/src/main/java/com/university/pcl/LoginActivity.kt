package com.university.pcl

import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.university.pcl.data.Prefs

/**
 * 内嵌 WebView 登录：加载学校教务系统登录页，由用户手动完成
 * 账号 / 密码 / 验证码（或扫码）登录，再点「已完成登录」保存 Cookie。
 */
class LoginActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        CookieManager.getInstance().setAcceptCookie(true)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val hint = TextView(this).apply {
            text = "请用学号 / 密码（及验证码）登录教务系统。登录后能看到课表页面，再点下方「已完成登录」。"
            textSize = 13f
            setPadding(32, 32, 32, 20)
        }

        webView = WebView(this)
        // CAS 跳转场景需要接受第三方 Cookie，否则登录态可能写不进去
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        val done = Button(this).apply {
            text = "已完成登录"
            setOnClickListener { completeLogin() }
        }

        root.addView(hint)
        root.addView(
            webView,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )
        root.addView(done)
        setContentView(root)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = userAgentString.replace("; wv", "")
        }
        webView.webViewClient = object : WebViewClient() {}

        webView.loadUrl(prefs.baseUrl + "/jsxsd/")
    }

    private fun completeLogin() {
        val cookie = collectCookies()
        if (cookie.isBlank()) {
            Toast.makeText(this, "还没检测到登录信息，请先完成网页登录", Toast.LENGTH_SHORT).show()
            return
        }
        prefs.cookies = cookie
        CookieManager.getInstance().flush()
        Toast.makeText(this, "登录状态已保存", Toast.LENGTH_SHORT).show()
        setResult(RESULT_OK)
        finish()
    }

    /** 按多个路径取 Cookie 并合并去重（JSESSIONID 常带 Path=/jsxsd，只取根路径会漏）。 */
    private fun collectCookies(): String {
        val cookieManager = CookieManager.getInstance()
        // 先取更具体的路径，同名 Cookie 保留更具体的那份
        val urls = listOf(
            prefs.baseUrl + "/jsxsd/xskb/xskb_list.do",
            prefs.baseUrl + "/jsxsd/framework/xsMainV.htmlx",
            prefs.baseUrl + "/jsxsd/",
            prefs.baseUrl
        )
        return urls.mapNotNull { cookieManager.getCookie(it) }
            .flatMap { it.split(";") }
            .map { it.trim() }
            .filter { it.contains('=') }
            .distinctBy { it.substringBefore('=') }
            .joinToString("; ")
    }

    override fun onPause() {
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onDestroy() {
        runCatching {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }
}

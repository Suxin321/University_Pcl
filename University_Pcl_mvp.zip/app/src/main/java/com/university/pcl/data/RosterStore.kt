package com.university.pcl.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File
import java.io.IOException

@Serializable
data class RosterFile(val shifts: List<DutyShift> = emptyList())

/** 空课表与排班结果的本地存储（JSON 文件，纯离线）。 */
class RosterStore(context: Context) {

    private val context: Context = context.applicationContext
    private val dir = File(this.context.filesDir, "roster")
    private val freeFile = File(dir, "free_timetable.json")
    private val rosterFile = File(dir, "duty_roster.json")
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun loadFreeTimetable(): FreeTimetable? {
        if (!freeFile.exists()) return null
        return runCatching {
            json.decodeFromString(FreeTimetable.serializer(), freeFile.readText())
        }.getOrNull()
    }

    fun saveFreeTimetable(timetable: FreeTimetable) {
        runCatching {
            dir.mkdirs()
            freeFile.writeText(json.encodeToString(FreeTimetable.serializer(), timetable))
        }
    }

    fun loadRoster(): List<DutyShift> {
        if (!rosterFile.exists()) return emptyList()
        return runCatching {
            json.decodeFromString(RosterFile.serializer(), rosterFile.readText()).shifts
        }.getOrNull().orEmpty().sortedWith(compareBy({ it.week }, { it.day }, { it.bigSection }))
    }

    fun saveRoster(shifts: List<DutyShift>) {
        runCatching {
            dir.mkdirs()
            val cleaned = shifts
                .filter { it.names.isNotEmpty() }
                .sortedWith(compareBy({ it.week }, { it.day }, { it.bigSection }))
            rosterFile.writeText(json.encodeToString(RosterFile.serializer(), RosterFile(cleaned)))
        }
    }

    /** 导入（或更新）一份空课表：复制到应用目录 → 解析 → 保存。 */
    suspend fun importFreeTimetable(uri: Uri): Result<FreeTimetable> = withContext(Dispatchers.IO) {
        runCatching {
            dir.mkdirs()
            val raw = File(dir, "free_timetable_raw")
            context.contentResolver.openInputStream(uri)?.use { input ->
                raw.outputStream().use { output -> input.copyTo(output) }
            } ?: throw IOException("无法读取所选文件")

            val parsed = FreeTimetableParser.parse(raw)
            val saved = parsed.copy(
                importedAt = System.currentTimeMillis(),
                sourceName = displayName(uri)
            )
            saveFreeTimetable(saved)
            raw.delete()
            saved
        }
    }

    private fun displayName(uri: Uri): String {
        val name = runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (index >= 0) cursor.getString(index) else null
                    } else {
                        null
                    }
                }
        }.getOrNull()
        return name?.takeIf { it.isNotBlank() } ?: "空课表"
    }
}

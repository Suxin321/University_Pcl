package com.university.pcl.data

import kotlinx.serialization.Serializable

/** 自动排班的参数（界面上「自动排班」弹窗里的全部选项）。 */
data class RosterRequest(
    val startWeek: Int = 1,
    val endWeek: Int = 1,
    val perSlot: Int = 1,
    val avoidSameDay: Boolean = false,
    val avoidSameWeek: Boolean = false,
    val sections: List<Int> = (1..BigSections.COUNT).toList(),
    val days: List<Int> = emptyList(),
    val members: List<String> = emptyList()
)

/** 一次值班：第 week 周、星期 day、第 bigSection 大节，names 为值班的人。 */
@Serializable
data class DutyShift(
    val week: Int = 1,
    val day: Int = 1,
    val bigSection: Int = 1,
    val names: List<String> = emptyList()
)

/** 自动排班的纯算法：只根据空课表判断「这个时段这个人有没有空」。 */
object DutyScheduler {

    /**
     * 为 startWeek..endWeek 生成排班。
     *
     * - 每个「周 × 星期 × 大节」时段排 perSlot 个人；
     * - 只会排该周该时段确实有空的人；
     * - 尽量让每个人在整个区间内的总班次平均（可排的人少的时段先排）；
     * - members 限定参与排班的人（默认空课表里的全部人）；
     * - avoidSameDay = true 时同一个人同一天最多排 1 班；
     * - avoidSameWeek = true 时同一个人同一周最多排 1 班；
     * - sections 限定要排的大节（默认 1..5），不在其中的大节不排；
     * - days 限定要排的星期（默认空课表里的全部天）；
     * - 约束排不满时会自动退回（同天/同周允许多排），优先保证每个时段都排上人。
     */
    fun generate(
        free: FreeTimetable,
        startWeek: Int,
        endWeek: Int,
        perSlot: Int,
        avoidSameDay: Boolean,
        avoidSameWeek: Boolean = false,
        sections: List<Int> = (1..BigSections.COUNT).toList(),
        days: List<Int> = emptyList(),
        members: List<String> = emptyList()
    ): List<DutyShift> {
        if (!free.loaded) return emptyList()
        val start = startWeek.coerceAtLeast(1)
        val end = endWeek.coerceAtLeast(start)
        val weeks = (start..end).toList()
        val freeDays = free.days.ifEmpty { (1..5).toList() }
        val dayList = days.filter { it in freeDays }.distinct().sorted()
            .ifEmpty { freeDays }
        val sectionList = sections.filter { it in 1..BigSections.COUNT }.distinct().sorted()
            .ifEmpty { (1..BigSections.COUNT).toList() }
        val memberSet = members.map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        fun eligible(day: Int, big: Int, week: Int): List<String> {
            val names = free.freeNames(day, big, week)
            return if (memberSet.isEmpty()) names else names.filter { it in memberSet }
        }
        val need = perSlot.coerceIn(1, 10)
        val anyAvoid = avoidSameDay || avoidSameWeek

        data class Slot(
            val week: Int,
            val day: Int,
            val big: Int,
            val eligible: List<String>
        )

        val slots = ArrayList<Slot>(weeks.size * dayList.size * sectionList.size)
        for (w in weeks) {
            for (d in dayList) {
                for (b in sectionList) {
                    slots.add(Slot(w, d, b, eligible(d, b, w)))
                }
            }
        }

        // 可排人数少的时段先排，避免稀有人员被别的时段先抢走。
        slots.sortWith(
            compareBy<Slot> { it.eligible.size }
                .thenBy { it.week }
                .thenBy { it.day }
                .thenBy { it.big }
        )

        val total = HashMap<String, Int>()
        val perDay = HashMap<String, MutableMap<String, Int>>() // key = "周-星期"
        val perWeek = HashMap<Int, MutableMap<String, Int>>()
        val result = ArrayList<DutyShift>(slots.size)

        for (slot in slots) {
            if (slot.eligible.isEmpty()) {
                result.add(DutyShift(slot.week, slot.day, slot.big, emptyList()))
                continue
            }
            val dayKey = "${slot.week}-${slot.day}"
            val dayCounts = perDay.getOrPut(dayKey) { HashMap() }
            val weekCounts = perWeek.getOrPut(slot.week) { HashMap() }
            val picked = ArrayList<String>(need)
            val ranked = slot.eligible.sortedWith(
                compareBy<String> { total[it] ?: 0 }
                    .thenBy { if (avoidSameDay) dayCounts[it] ?: 0 else 0 }
                    .thenBy { if (avoidSameWeek) weekCounts[it] ?: 0 else 0 }
                    .thenBy { tieRank(it, slot.week, slot.day, slot.big) }
            )
            for (name in ranked) {
                if (picked.size >= need) break
                if (avoidSameDay && (dayCounts[name] ?: 0) > 0) continue
                if (avoidSameWeek && (weekCounts[name] ?: 0) > 0) continue
                picked.add(name)
            }
            // 「同天/同周不重复」导致排不满时，退一步允许重复，优先别留空。
            if (anyAvoid && picked.size < need) {
                for (name in ranked) {
                    if (picked.size >= need) break
                    if (picked.contains(name)) continue
                    picked.add(name)
                }
            }
            picked.forEach { name ->
                total[name] = (total[name] ?: 0) + 1
                dayCounts[name] = (dayCounts[name] ?: 0) + 1
                weekCounts[name] = (weekCounts[name] ?: 0) + 1
            }
            result.add(DutyShift(slot.week, slot.day, slot.big, picked.sorted()))
        }

        return result.sortedWith(
            compareBy<DutyShift>({ it.week }, { it.day }, { it.bigSection })
        )
    }

    /** 用 RosterRequest 调用的重载。 */
    fun generate(free: FreeTimetable, request: RosterRequest): List<DutyShift> = generate(
        free = free,
        startWeek = request.startWeek,
        endWeek = request.endWeek,
        perSlot = request.perSlot,
        avoidSameDay = request.avoidSameDay,
        avoidSameWeek = request.avoidSameWeek,
        sections = request.sections,
        days = request.days,
        members = request.members
    )

    /** 稳定的打散权重：同分时不同周/时段优先不同的人，排出来不会每周一模一样。 */
    private fun tieRank(name: String, week: Int, day: Int, big: Int): Int {
        var h = name.hashCode()
        h = h * 31 + week * 7 + day * 13 + big * 17
        return (h xor (h ushr 16)) and 0x7fffffff
    }

    /** 某周的排班（按 星期、大节 排序）。 */
    fun weekShifts(all: List<DutyShift>, week: Int): List<DutyShift> =
        all.filter { it.week == week }
            .sortedWith(compareBy({ it.day }, { it.bigSection }))

    /** 每人班次统计（次数多的在前）。 */
    fun countByPerson(shifts: List<DutyShift>): List<Pair<String, Int>> =
        shifts.flatMap { it.names }
            .groupingBy { it }
            .eachCount()
            .entries
            .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            .map { it.key to it.value }
}

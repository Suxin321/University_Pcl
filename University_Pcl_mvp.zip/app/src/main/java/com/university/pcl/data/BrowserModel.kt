package com.university.pcl.data

import kotlinx.serialization.Serializable

/** 一条浏览器书签。 */
@Serializable
data class BrowserBookmark(
    val id: String,
    val title: String,
    val url: String,
    val createdAt: Long = 0L
)

/** 一条浏览历史（列表里最新的在前）。 */
@Serializable
data class BrowserHistoryEntry(
    val title: String,
    val url: String,
    val visitedAt: Long = 0L
)

/** 一条下载记录。 */
@Serializable
data class BrowserDownloadEntry(
    val id: String,
    val name: String,
    val url: String,
    val status: String = "已加入下载",
    val createdAt: Long = 0L
)

/** 新标签页的一个快捷入口（常用站，可增删）。 */
@Serializable
data class BrowserQuickLink(
    val id: String,
    val name: String,
    val url: String,
    val createdAt: Long = 0L
)

/** 浏览器设置。 */
@Serializable
data class BrowserSettings(
    val searchEngine: String = BrowserUrls.DEFAULT_ENGINE,
    val adBlock: Boolean = true,
    val desktopMode: Boolean = false,
    val defaultIncognito: Boolean = false,
    val forceDark: Boolean = false
)

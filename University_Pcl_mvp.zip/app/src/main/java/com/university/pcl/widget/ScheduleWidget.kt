package com.university.pcl.widget

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.widget.RemoteViews
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.Action
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.AndroidRemoteViews
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.university.pcl.MainActivity
import com.university.pcl.R
import com.university.pcl.data.BigSections
import com.university.pcl.data.CacheStore
import com.university.pcl.data.CourseSlot
import com.university.pcl.data.ManualCourseStore
import com.university.pcl.data.PlanItem
import com.university.pcl.data.PlanSort
import com.university.pcl.data.PlanStats
import com.university.pcl.data.PlanStore
import com.university.pcl.data.PlanText
import com.university.pcl.data.Prefs
import com.university.pcl.data.ScheduleCache
import com.university.pcl.data.WeekUtil
import com.university.pcl.data.Weekdays
import com.university.pcl.data.isOverdue
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale

/**
 * 桌面组件：上面是今天的课表（固定 5 个大节），下面是计划统计 + 计划列表。
 *
 * 尺寸处理：**不依赖 [androidx.glance.LocalSize]**。HyperOS 桌面不会把组件的实际尺寸
 * 通过 appWidgetOptions 报上来，Glance 的 SizeMode.Exact / Responsive 都只能拿到
 * 最小尺寸（110dp），导致 4x4 的组件也只画紧凑版、下面大片空白。
 * 现在改成：
 *  - 组件最小高度在 xml 里锁到 320dp（`minHeight` / `minResizeHeight`），不会再变成细条；
 *  - 布局全部用 `defaultWeight()` 权重分配空间，内容随实际高度自动拉伸，不需要知道尺寸。
 * 另外 user 反馈「计划行不显示」：Glance 的 CheckBox 在 HyperOS 上不渲染文字，
 * 所以待办勾选用自绘圆点 Box + 独立 Text，不再用 CheckBox。
 */
class ScheduleWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        // 数据统一在组合期读取：Glance 的 update() 在会话存活时不会重跑 provideGlance，
        // 只在 provideGlance 里读的话，手动刷新 / 自动刷新都拿不到最新数据。
        val appContext = context.applicationContext
        provideContent { WidgetContent(appContext) }
    }
}

private fun currentWeek(context: Context): Int {
    val prefs = Prefs(context)
    if (prefs.week > 0) return prefs.week
    val term = prefs.term.ifBlank { WeekUtil.guessTerm() }
    val start = prefs.semesterStart.ifBlank {
        com.university.pcl.data.TermCalendar.startOf(term) ?: ""
    }
    val computed = WeekUtil.weekFromStart(start)
    return if (computed > 0) computed else 1
}

private val widgetPalette = listOf(
    Color(0xFF6FBF4A), Color(0xFF1FA463), Color(0xFF3E8EF7), Color(0xFFD06BD6),
    Color(0xFFC07A16), Color(0xFFF07A79), Color(0xFF8B5CF6), Color(0xFF0EA5A4)
)

private fun courseColor(name: String): Color =
    widgetPalette[kotlin.math.abs(name.hashCode()) % widgetPalette.size]

private val GlassLight = Color(0xF2FFFFFF)
private val GlassDark = Color(0xE6242424)
private val TextLight = Color(0xFF111111)
private val TextDark = Color(0xFFF3F3F3)

private val AccentBlue = Color(0xFF3482FF)
private val AccentBlueNight = Color(0xFF9FC3FF)
private val OverdueColor = Color(0xFFE05656)

private fun bgColor(night: Boolean): Color = if (night) GlassDark else GlassLight
private fun mainColor(night: Boolean): Color = if (night) TextDark else TextLight
private fun subColor(night: Boolean): Color = if (night) Color(0x66FFFFFF) else Color(0x66000000)
private fun emptyPillColor(night: Boolean): Color =
    if (night) Color(0x1AFFFFFF) else Color(0x0F000000)

/** 待办行的勾选圆点：已完成 = 蓝底白勾，未完成 = 明显的灰点（白底/深色底都看得见）。 */
private fun checkDotColor(night: Boolean, completed: Boolean): Color = when {
    completed && night -> AccentBlueNight
    completed -> AccentBlue
    night -> Color(0x2EFFFFFF)
    else -> Color(0x26000000)
}

private fun todaySlots(
    cache: ScheduleCache?,
    manual: List<CourseSlot>,
    week: Int
): List<CourseSlot> {
    val today = LocalDate.now().dayOfWeek.value
    return (cache?.items.orEmpty() + manual).filter { it.day == today && it.activeIn(week) }
}

/** 课表一行：section 是大节 1..5；course 为 null 表示这节课没课（占位行）。 */
private data class CourseLine(val section: Int, val course: CourseSlot?)

/** 5 个大节全部显示（没课的显示「无课」占位），固定 5 行。 */
private fun allSectionLines(slots: List<CourseSlot>): List<CourseLine> =
    (1..BigSections.COUNT).map { section ->
        CourseLine(section, slots.firstOrNull { it.bigSection == section })
    }

/** 头部第二行的「更新 HH:mm」：显示本次渲染时间，随每次自动/手动刷新变化。 */
private fun refreshSuffix(updatedAt: Long): String {
    if (updatedAt <= 0L) return ""
    return try {
        " · 更新 " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(updatedAt))
    } catch (e: Exception) {
        ""
    }
}

/** 组件内容：每次组合都重新读本地数据（课表 / 手动课 / 周次 / 计划）。 */
@Composable
private fun WidgetContent(appContext: Context) {
    val cache = CacheStore(appContext).load()
    val manual = ManualCourseStore(appContext).load().map { it.toSlot() }
    val week = currentWeek(appContext)
    val plans = PlanStore(appContext).load()
    // 头部「更新 HH:mm」用本次渲染时间（自动/手动刷新都会变，能看出组件在更新）
    val updatedAt = System.currentTimeMillis()
    val night = (appContext.resources.configuration.uiMode and
        Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    val openApp: Action = actionStartActivity(Intent(appContext, MainActivity::class.java))
    val addAction: Action = actionStartActivity(planEditIntent(appContext, null))

    val today = LocalDate.now()
    val dayName = Weekdays.long.getOrNull(today.dayOfWeek.value - 1) ?: ""
    val slots = todaySlots(cache, manual, week)

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ColorProvider(bgColor(night)))
            .cornerRadius(21.dp)
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .clickable(openApp),
        verticalAlignment = Alignment.Top
    ) {
        WidgetHeader(
            appContext = appContext,
            title = "${today.monthValue}月${today.dayOfMonth}日 $dayName",
            sub = "第 $week 周" + (if (cache == null) " · 未同步" else "") +
                refreshSuffix(updatedAt),
            night = night,
            addAction = addAction
        )
        Spacer(modifier = GlanceModifier.height(6.dp))
        CourseSection(
            lines = allSectionLines(slots),
            night = night,
            modifier = GlanceModifier.fillMaxWidth().defaultWeight()
        )
        Spacer(modifier = GlanceModifier.height(4.dp))
        PlanSection(
            plans = plans,
            today = PlanText.todayString(),
            night = night,
            appContext = appContext,
            modifier = GlanceModifier.fillMaxWidth().defaultWeight()
        )
    }
}

/**
 * 头部：左边日期 + 「第 N 周 · 更新 HH:mm」，右边实时时钟 + 「↻」刷新 + 「＋」新建。
 * 头部空白处点击会落到最外层 Column 的 clickable（打开 MainActivity）。
 */
@Composable
private fun WidgetHeader(
    appContext: Context,
    title: String,
    sub: String,
    night: Boolean,
    addAction: Action
) {
    Row(
        modifier = GlanceModifier.fillMaxWidth().height(36.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = GlanceModifier.defaultWeight()) {
            Text(
                text = title,
                style = TextStyle(
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = ColorProvider(mainColor(night))
                ),
                maxLines = 1
            )
            Text(
                text = sub,
                style = TextStyle(fontSize = 10.sp, color = ColorProvider(subColor(night))),
                maxLines = 1
            )
        }
        // 真正的实时时钟：TextClock 由桌面进程自己每秒渲染，App 不用唤醒
        LiveClock(appContext = appContext, night = night)
        Spacer(modifier = GlanceModifier.width(6.dp))
        WidgetIconButton("↻", actionRunCallback<WidgetRefreshAction>(), night)
        Spacer(modifier = GlanceModifier.width(6.dp))
        WidgetIconButton("＋", addAction, night)
    }
}

/**
 * 头部实时时钟：把 `res/layout/widget_clock.xml`（里面是 TextClock）通过
 * [AndroidRemoteViews] 嵌进 Glance 布局。时间由桌面自己每秒刷新，不需要 App 推送更新，
 * 这是 HyperOS 时钟/股票组件时间“实时”的同款做法。
 *
 * 尺寸写死：嵌套 RemoteViews 在部分启动器上测量不稳定，wrap_content 会被挤成一条窄缝。
 */
@Composable
private fun LiveClock(appContext: Context, night: Boolean) {
    val clockViews = RemoteViews(appContext.packageName, R.layout.widget_clock).apply {
        setTextColor(R.id.widget_clock, mainColor(night).toArgb())
    }
    AndroidRemoteViews(
        remoteViews = clockViews,
        modifier = GlanceModifier.width(82.dp).height(22.dp)
    )
}

/** 头部的小方形图标按钮（刷新 / 新建）。 */
@Composable
private fun WidgetIconButton(label: String, action: Action, night: Boolean) {
    Box(
        modifier = GlanceModifier
            .size(26.dp)
            .background(ColorProvider(emptyPillColor(night)))
            .cornerRadius(13.dp)
            .clickable(action),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = TextStyle(
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = ColorProvider(mainColor(night))
            ),
            maxLines = 1
        )
    }
}

/**
 * 课表区：固定 5 个大节，行高按权重平分可用高度（组件越高、每行越高）。
 * 单独包一层 Column，避免根 Column 子元素超过 RemoteViews 的限制。
 */
@Composable
private fun CourseSection(
    lines: List<CourseLine>,
    night: Boolean,
    modifier: GlanceModifier = GlanceModifier
) {
    Column(modifier = modifier) {
        for (line in lines) {
            CourseRow(
                line = line,
                night = night,
                modifier = GlanceModifier.fillMaxWidth().defaultWeight()
            )
        }
    }
}

/** 一行课：节次标签 + （有课）彩色课程块 / （没课）「无课」占位块。 */
@Composable
private fun CourseRow(
    line: CourseLine,
    night: Boolean,
    modifier: GlanceModifier = GlanceModifier
) {
    Row(
        modifier = modifier.padding(vertical = 1.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = BigSections.shortLabels.getOrNull(line.section - 1) ?: "",
            style = TextStyle(fontSize = 10.sp, color = ColorProvider(subColor(night))),
            modifier = GlanceModifier.width(26.dp),
            maxLines = 1
        )
        val item = line.course
        if (item == null) {
            Box(
                modifier = GlanceModifier
                    .defaultWeight()
                    .fillMaxHeight()
                    .background(ColorProvider(emptyPillColor(night)))
                    .cornerRadius(8.dp)
                    .padding(horizontal = 8.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text(
                    text = "无课",
                    style = TextStyle(fontSize = 11.sp, color = ColorProvider(subColor(night))),
                    maxLines = 1
                )
            }
            return@Row
        }
        Box(
            modifier = GlanceModifier
                .defaultWeight()
                .fillMaxHeight()
                .background(ColorProvider(courseColor(item.name)))
                .cornerRadius(8.dp)
                .padding(horizontal = 8.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = item.name,
                    style = TextStyle(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = ColorProvider(Color.White)
                    ),
                    modifier = GlanceModifier.defaultWeight(),
                    maxLines = 1
                )
                if (item.room.isNotBlank()) {
                    Text(
                        text = " @" + item.room,
                        style = TextStyle(
                            fontSize = 10.sp,
                            color = ColorProvider(Color(0xD9FFFFFF))
                        ),
                        maxLines = 1
                    )
                }
            }
        }
    }
}

/**
 * 计划区：一行统计「计划 3/8 · 38%」+ 计划列表（最多 3 条，多了到 App 里看）。
 * 空计划时显示「暂无计划，点 ＋ 添加」并居中在剩余空间里。
 */
@Composable
private fun PlanSection(
    plans: List<PlanItem>,
    today: String,
    night: Boolean,
    appContext: Context,
    modifier: GlanceModifier = GlanceModifier
) {
    val summary = PlanStats.summarize(plans, today)
    val rows = PlanSort.forWidget(plans, today, 3)
    val addAction: Action = actionStartActivity(planEditIntent(appContext, null))

    Column(modifier = modifier) {
        Row(
            modifier = GlanceModifier.fillMaxWidth().height(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "计划 ${summary.completed}/${summary.total} · ${summary.percent}%",
                style = TextStyle(
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = ColorProvider(subColor(night))
                ),
                modifier = GlanceModifier.defaultWeight(),
                maxLines = 1
            )
            if (summary.overdue > 0) {
                Text(
                    text = "${summary.overdue} 项过期",
                    style = TextStyle(fontSize = 10.sp, color = ColorProvider(OverdueColor)),
                    maxLines = 1
                )
            }
        }
        if (plans.isEmpty()) {
            Box(
                modifier = GlanceModifier
                    .fillMaxWidth()
                    .defaultWeight()
                    .clickable(addAction),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "暂无计划，点 ＋ 添加",
                    style = TextStyle(fontSize = 11.sp, color = ColorProvider(subColor(night))),
                    maxLines = 1
                )
            }
        } else {
            for (item in rows) {
                PlanRow(item, night, appContext)
            }
            Spacer(modifier = GlanceModifier.defaultWeight())
        }
    }
}

/**
 * 一条计划：
 * - 待办：自绘圆点（已完成 = 蓝底白勾）+ 标题（点标题打开编辑）+ 行尾「›」；
 *   不用 Glance 的 CheckBox：它在 HyperOS 上不渲染文字，整行只剩行尾箭头。
 * - 计数：「＋1」按钮 + 标题与「3/10」进度（点标题打开编辑）+ 行尾「›」。
 */
@Composable
private fun PlanRow(item: PlanItem, night: Boolean, appContext: Context) {
    val params = actionParametersOf(PlanWidgetKeys.planIdKey to item.id)
    val toggleAction: Action = actionRunCallback<TodoToggleAction>(params)
    val incrementAction: Action = actionRunCallback<PlanIncrementAction>(params)
    val editAction: Action = actionStartActivity(planEditIntent(appContext, item.id))
    val completed = item.isCompleted()
    val overdue = item.isOverdue(PlanText.todayString())
    val titleColor = when {
        overdue -> OverdueColor
        completed -> subColor(night)
        else -> mainColor(night)
    }

    Row(
        modifier = GlanceModifier.fillMaxWidth().height(30.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (item.isCount) {
            Box(
                modifier = GlanceModifier
                    .width(28.dp)
                    .height(20.dp)
                    .background(
                        ColorProvider(if (night) Color(0x332F6FCF) else Color(0x1A3482FF))
                    )
                    .cornerRadius(10.dp)
                    .clickable(incrementAction),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "＋1",
                    style = TextStyle(
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = ColorProvider(if (night) AccentBlueNight else AccentBlue)
                    ),
                    maxLines = 1
                )
            }
            Spacer(modifier = GlanceModifier.width(6.dp))
            Row(
                modifier = GlanceModifier.defaultWeight().clickable(editAction),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = item.title,
                    style = TextStyle(
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = ColorProvider(titleColor)
                    ),
                    modifier = GlanceModifier.defaultWeight(),
                    maxLines = 1
                )
                Text(
                    text = PlanText.progressLabel(item),
                    style = TextStyle(fontSize = 10.sp, color = ColorProvider(subColor(night))),
                    modifier = GlanceModifier.padding(start = 4.dp),
                    maxLines = 1
                )
            }
        } else {
            // 自绘勾选圆点（Glance CheckBox 在 HyperOS 上不显示文字/勾选框）
            Box(
                modifier = GlanceModifier
                    .size(18.dp)
                    .background(ColorProvider(checkDotColor(night, completed)))
                    .cornerRadius(9.dp)
                    .clickable(toggleAction),
                contentAlignment = Alignment.Center
            ) {
                if (completed) {
                    Text(
                        text = "✓",
                        style = TextStyle(
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = ColorProvider(Color.White)
                        ),
                        maxLines = 1
                    )
                }
            }
            Text(
                text = item.title,
                style = TextStyle(
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = ColorProvider(titleColor)
                ),
                modifier = GlanceModifier.defaultWeight().padding(start = 6.dp).clickable(editAction),
                maxLines = 1
            )
        }
        EditChevron(editAction, night)
    }
}

/** 计划行尾的「›」：点开编辑 / 删除弹窗。 */
@Composable
private fun EditChevron(action: Action, night: Boolean) {
    Box(
        modifier = GlanceModifier.size(22.dp).clickable(action),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "›",
            style = TextStyle(fontSize = 15.sp, color = ColorProvider(subColor(night))),
            maxLines = 1
        )
    }
}

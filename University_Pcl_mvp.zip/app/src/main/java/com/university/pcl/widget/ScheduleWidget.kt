package com.university.pcl.widget

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.LocalSize
import androidx.glance.action.Action
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.university.pcl.MainActivity
import com.university.pcl.data.BigSections
import com.university.pcl.data.CacheStore
import com.university.pcl.data.ManualCourseStore
import com.university.pcl.data.Prefs
import com.university.pcl.data.ScheduleCache
import com.university.pcl.data.WeekUtil
import com.university.pcl.data.Weekdays
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate

/**
 * 桌面组件：显示「今天」的 5 大节课表。
 * 4x4（高 >= 200dp）显示完整信息；4x2（更矮）显示紧凑版。
 * 周次在渲染时现算（而非用缓存里的旧周次），避免跨周后显示错课。
 */
class ScheduleWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val appContext = context.applicationContext
        val cache = withContext(Dispatchers.IO) { CacheStore(appContext).load() }
        val manual = withContext(Dispatchers.IO) {
            ManualCourseStore(appContext).load().map { it.toSlot() }
        }
        val week = withContext(Dispatchers.IO) { currentWeek(appContext) }
        val night = (context.resources.configuration.uiMode and
            Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val openApp: Action = actionStartActivity(Intent(context, MainActivity::class.java))
        provideContent {
            if (LocalSize.current.height < 200.dp) {
                CompactContent(cache, manual, week, night, openApp)
            } else {
                FullContent(cache, manual, week, night, openApp)
            }
        }
    }

    private fun currentWeek(context: Context): Int {
        val prefs = Prefs(context)
        val computed = WeekUtil.weekFromStart(prefs.semesterStart)
        return if (computed > 0) computed else prefs.week.coerceAtLeast(1)
    }
}

private val GlassLight = Color(0xF2FFFFFF)
private val GlassDark = Color(0xE6242424)
private val TextLight = Color(0xFF111111)
private val TextDark = Color(0xFFF3F3F3)

private val widgetPalette = listOf(
    Color(0xFF6FBF4A), Color(0xFF1FA463), Color(0xFF3E8EF7), Color(0xFFD06BD6),
    Color(0xFFC07A16), Color(0xFFF07A79), Color(0xFF8B5CF6), Color(0xFF0EA5A4)
)

private fun courseColor(name: String): Color =
    widgetPalette[kotlin.math.abs(name.hashCode()) % widgetPalette.size]

private fun bgColor(night: Boolean): Color = if (night) GlassDark else GlassLight
private fun mainColor(night: Boolean): Color = if (night) TextDark else TextLight
private fun subColor(night: Boolean): Color = if (night) Color(0x66FFFFFF) else Color(0x66000000)

private fun todaySlots(cache: ScheduleCache?, manual: List<com.university.pcl.data.CourseSlot>, week: Int): List<com.university.pcl.data.CourseSlot> {
    val today = LocalDate.now().dayOfWeek.value
    val all = cache?.items.orEmpty() + manual
    return all.filter { it.day == today && it.activeIn(week) }
}

@Composable
private fun FullContent(cache: ScheduleCache?, manual: List<com.university.pcl.data.CourseSlot>, week: Int, night: Boolean, openApp: Action) {
    val today = LocalDate.now().dayOfWeek.value
    val slots = todaySlots(cache, manual, week)
    val dayName = Weekdays.long.getOrNull(today - 1) ?: ""
    val weekLabel = if (week > 0) "$dayName · 第 $week 周" else dayName

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ColorProvider(bgColor(night)))
            .cornerRadius(21.dp)
            .padding(16.dp)
            .clickable(openApp),
        verticalAlignment = Alignment.Top
    ) {
        Row(
            modifier = GlanceModifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = GlanceModifier.defaultWeight()) {
                Text(
                    text = weekLabel,
                    style = TextStyle(
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = ColorProvider(mainColor(night))
                    ),
                    maxLines = 1
                )
            }
            Text(
                text = if (cache == null) "未同步" else "今天",
                style = TextStyle(fontSize = 12.sp, color = ColorProvider(subColor(night))),
                maxLines = 1
            )
        }

        Spacer(modifier = GlanceModifier.height(8.dp))

        for (index in 1..BigSections.COUNT) {
            val item = slots.firstOrNull { it.bigSection == index }
            Row(
                modifier = GlanceModifier.fillMaxWidth().height(40.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = BigSections.shortLabels[index - 1],
                    style = TextStyle(fontSize = 11.sp, color = ColorProvider(subColor(night))),
                    modifier = GlanceModifier.width(40.dp),
                    maxLines = 1
                )
                if (item != null) {
                    Box(
                        modifier = GlanceModifier
                            .width(3.dp)
                            .height(30.dp)
                            .background(ColorProvider(courseColor(item.name)))
                            .cornerRadius(2.dp)
                    )
                    Spacer(modifier = GlanceModifier.width(6.dp))
                }
                Column(modifier = GlanceModifier.defaultWeight()) {
                    Text(
                        text = item?.name ?: "—",
                        style = TextStyle(
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = ColorProvider(if (item == null) subColor(night) else mainColor(night))
                        ),
                        maxLines = 1
                    )
                    val meta = listOfNotNull(
                        item?.room?.takeIf { it.isNotBlank() },
                        item?.teacher?.takeIf { it.isNotBlank() }
                    ).joinToString(" · ")
                    if (meta.isNotBlank()) {
                        Text(
                            text = meta,
                            style = TextStyle(fontSize = 11.sp, color = ColorProvider(subColor(night))),
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CompactContent(cache: ScheduleCache?, manual: List<com.university.pcl.data.CourseSlot>, week: Int, night: Boolean, openApp: Action) {
    val today = LocalDate.now().dayOfWeek.value
    val slots = todaySlots(cache, manual, week)
    val dayName = Weekdays.long.getOrNull(today - 1) ?: ""

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ColorProvider(bgColor(night)))
            .cornerRadius(21.dp)
            .padding(12.dp)
            .clickable(openApp),
        verticalAlignment = Alignment.Top
    ) {
        Row(
            modifier = GlanceModifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = GlanceModifier.defaultWeight()) {
                Text(
                    text = if (week > 0) "$dayName · 第 $week 周" else dayName,
                    style = TextStyle(
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = ColorProvider(mainColor(night))
                    ),
                    maxLines = 1
                )
            }
            Text(
                text = if (cache == null) "未同步" else "今天",
                style = TextStyle(fontSize = 10.sp, color = ColorProvider(subColor(night))),
                maxLines = 1
            )
        }
        Spacer(modifier = GlanceModifier.height(4.dp))
        if (slots.isEmpty()) {
            Text(
                text = if (cache == null) "打开 App 登录后同步" else "今天没课",
                style = TextStyle(fontSize = 12.sp, color = ColorProvider(subColor(night))),
                maxLines = 1
            )
        } else {
            slots.sortedBy { it.bigSection }.take(4).forEach { item ->
                Row(
                    modifier = GlanceModifier.fillMaxWidth().height(22.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = BigSections.shortLabels.getOrNull(item.bigSection - 1) ?: "",
                        style = TextStyle(fontSize = 10.sp, color = ColorProvider(subColor(night))),
                        modifier = GlanceModifier.width(34.dp),
                        maxLines = 1
                    )
                    Text(
                        text = item.name,
                        style = TextStyle(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = ColorProvider(mainColor(night))
                        ),
                        modifier = GlanceModifier.defaultWeight(),
                        maxLines = 1
                    )
                }
            }
        }
    }
}

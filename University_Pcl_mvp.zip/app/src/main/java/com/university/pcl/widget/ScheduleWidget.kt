package com.university.pcl.widget

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.LocalSize
import androidx.glance.action.Action
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.university.pcl.MainActivity
import com.university.pcl.data.BigSections
import com.university.pcl.data.CacheStore
import com.university.pcl.data.CourseSlot
import com.university.pcl.data.ManualCourseStore
import com.university.pcl.data.Prefs
import com.university.pcl.data.ScheduleCache
import com.university.pcl.data.WeekUtil
import com.university.pcl.data.Weekdays
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate

/**
 * 桌面组件：显示「今天」的 5 大节课表。
 * 4x4（高 >= 200dp）显示完整信息（彩色课程块 + 时间 + 地点）；
 * 4x2 显示紧凑版（只显示有课的节次 + 课程名）。
 */
class ScheduleWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val appContext = context.applicationContext
        val cache = withContext(Dispatchers.IO) { CacheStore(appContext).load() }
        val manual = withContext(Dispatchers.IO) {
            ManualCourseStore(appContext).load().map { it.toSlot() }
        }
        val week = withContext(Dispatchers.IO) { currentWeek(appContext) }
        val night = (context.resources.configuration.uiMode and
            Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val openApp: Action = actionStartActivity(Intent(context, MainActivity::class.java))
        provideContent {
            if (LocalSize.current.height < 200.dp) {
                CompactContent(cache, manual, week, night, openApp)
            } else {
                FullContent(cache, manual, week, night, openApp)
            }
        }
    }

    private fun currentWeek(context: Context): Int {
        val prefs = Prefs(context)
        if (prefs.week > 0) return prefs.week
        val term = prefs.term.ifBlank { WeekUtil.guessTerm() }
        val start = prefs.semesterStart.ifBlank {
            com.university.pcl.data.TermCalendar.startOf(term) ?: ""
        }
        val computed = WeekUtil.weekFromStart(start)
        return if (computed > 0) computed else 1
    }
}

private val widgetPalette = listOf(
    Color(0xFF6FBF4A), Color(0xFF1FA463), Color(0xFF3E8EF7), Color(0xFFD06BD6),
    Color(0xFFC07A16), Color(0xFFF07A79), Color(0xFF8B5CF6), Color(0xFF0EA5A4)
)

private fun courseColor(name: String): Color =
    widgetPalette[kotlin.math.abs(name.hashCode()) % widgetPalette.size]

private val GlassLight = Color(0xF2FFFFFF)
private val GlassDark = Color(0xE6242424)
private val TextLight = Color(0xFF111111)
private val TextDark = Color(0xFFF3F3F3)

private fun bgColor(night: Boolean): Color = if (night) GlassDark else GlassLight
private fun mainColor(night: Boolean): Color = if (night) TextDark else TextLight
private fun subColor(night: Boolean): Color = if (night) Color(0x66FFFFFF) else Color(0x66000000)
private fun emptyPillColor(night: Boolean): Color =
    if (night) Color(0x1AFFFFFF) else Color(0x0F000000)

private fun todaySlots(
    cache: ScheduleCache?,
    manual: List<CourseSlot>,
    week: Int
): List<CourseSlot> {
    val today = LocalDate.now().dayOfWeek.value
    return (cache?.items.orEmpty() + manual).filter { it.day == today && it.activeIn(week) }
}

@Composable
private fun FullContent(
    cache: ScheduleCache?,
    manual: List<CourseSlot>,
    week: Int,
    night: Boolean,
    openApp: Action
) {
    val today = LocalDate.now()
    val slots = todaySlots(cache, manual, week)
    val dayName = Weekdays.long.getOrNull(today.dayOfWeek.value - 1) ?: ""
    val title = "${today.monthValue}月${today.dayOfMonth}日 $dayName"
    val weekLabel = "第 $week 周"

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ColorProvider(bgColor(night)))
            .cornerRadius(21.dp)
            .padding(14.dp)
            .clickable(openApp),
        verticalAlignment = Alignment.Top
    ) {
        Row(
            modifier = GlanceModifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = GlanceModifier.defaultWeight()) {
                Text(
                    text = title,
                    style = TextStyle(
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = ColorProvider(mainColor(night))
                    ),
                    maxLines = 1
                )
                Text(
                    text = weekLabel,
                    style = TextStyle(fontSize = 10.sp, color = ColorProvider(subColor(night))),
                    maxLines = 1
                )
            }
            Text(
                text = if (cache == null) "未同步" else "今天",
                style = TextStyle(fontSize = 10.sp, color = ColorProvider(subColor(night))),
                maxLines = 1
            )
        }

        Spacer(modifier = GlanceModifier.height(10.dp))

        for (index in 1..BigSections.COUNT) {
            val item = slots.firstOrNull { it.bigSection == index }
            Row(
                modifier = GlanceModifier.fillMaxWidth().height(42.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = BigSections.shortLabels[index - 1],
                    style = TextStyle(fontSize = 10.sp, color = ColorProvider(subColor(night))),
                    modifier = GlanceModifier.width(32.dp),
                    maxLines = 1
                )
                if (item == null) {
                    Box(
                        modifier = GlanceModifier
                            .defaultWeight()
                            .height(34.dp)
                            .background(ColorProvider(emptyPillColor(night)))
                            .cornerRadius(10.dp)
                            .padding(horizontal = 10.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            text = "无课",
                            style = TextStyle(fontSize = 10.sp, color = ColorProvider(subColor(night))),
                            maxLines = 1
                        )
                    }
                } else {
                    Box(
                        modifier = GlanceModifier
                            .defaultWeight()
                            .height(34.dp)
                            .background(ColorProvider(courseColor(item.name)))
                            .cornerRadius(10.dp)
                            .padding(horizontal = 10.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Column {
                            Text(
                                text = item.name,
                                style = TextStyle(
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = ColorProvider(Color.White)
                                ),
                                maxLines = 1
                            )
                            val meta = listOfNotNull(
                                item.room.takeIf { it.isNotBlank() }?.let { "@$it" },
                                item.teacher.takeIf { it.isNotBlank() }
                            ).joinToString(" · ")
                            if (meta.isNotBlank()) {
                                Text(
                                    text = meta,
                                    style = TextStyle(
                                        fontSize = 9.sp,
                                        color = ColorProvider(Color(0xD9FFFFFF))
                                    ),
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }
            }
            if (index < BigSections.COUNT) {
                Spacer(modifier = GlanceModifier.height(2.dp))
            }
        }
    }
}

@Composable
private fun CompactContent(
    cache: ScheduleCache?,
    manual: List<CourseSlot>,
    week: Int,
    night: Boolean,
    openApp: Action
) {
    val today = LocalDate.now()
    val slots = todaySlots(cache, manual, week)
    val dayName = Weekdays.long.getOrNull(today.dayOfWeek.value - 1) ?: ""

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ColorProvider(bgColor(night)))
            .cornerRadius(21.dp)
            .padding(12.dp)
            .clickable(openApp),
        verticalAlignment = Alignment.Top
    ) {
        Row(modifier = GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "$dayName · 第 $week 周",
                style = TextStyle(
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = ColorProvider(mainColor(night))
                ),
                modifier = GlanceModifier.defaultWeight(),
                maxLines = 1
            )
            Text(
                text = if (cache == null) "未同步" else "今天",
                style = TextStyle(fontSize = 9.sp, color = ColorProvider(subColor(night))),
                maxLines = 1
            )
        }
        Spacer(modifier = GlanceModifier.height(6.dp))
        if (slots.isEmpty()) {
            Text(
                text = if (cache == null) "打开 App 导入课表" else "今天没课",
                style = TextStyle(fontSize = 11.sp, color = ColorProvider(subColor(night))),
                maxLines = 1
            )
        } else {
            slots.sortedBy { it.bigSection }.take(4).forEach { item ->
                Row(
                    modifier = GlanceModifier.fillMaxWidth().height(22.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = BigSections.shortLabels.getOrNull(item.bigSection - 1) ?: "",
                        style = TextStyle(fontSize = 9.sp, color = ColorProvider(subColor(night))),
                        modifier = GlanceModifier.width(26.dp),
                        maxLines = 1
                    )
                    Box(
                        modifier = GlanceModifier.width(4.dp).height(14.dp)
                            .background(ColorProvider(courseColor(item.name)))
                            .cornerRadius(2.dp)
                    ) {}
                    Spacer(modifier = GlanceModifier.width(6.dp))
                    Text(
                        text = item.name,
                        style = TextStyle(
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = ColorProvider(mainColor(night))
                        ),
                        modifier = GlanceModifier.defaultWeight(),
                        maxLines = 1
                    )
                    if (item.room.isNotBlank()) {
                        Text(
                            text = "@" + item.room,
                            style = TextStyle(fontSize = 8.sp, color = ColorProvider(subColor(night))),
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

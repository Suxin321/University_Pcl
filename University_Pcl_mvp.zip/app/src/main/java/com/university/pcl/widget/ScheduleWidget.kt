package com.university.pcl.widget

import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.LocalSize
import androidx.glance.action.Action
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.CheckBox
import androidx.glance.appwidget.CheckboxDefaults
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.university.pcl.MainActivity
import com.university.pcl.data.BigSections
import com.university.pcl.data.CacheStore
import com.university.pcl.data.CourseSlot
import com.university.pcl.data.ManualCourseStore
import com.university.pcl.data.PlanItem
import com.university.pcl.data.PlanSort
import com.university.pcl.data.PlanStats
import com.university.pcl.data.PlanStore
import com.university.pcl.data.PlanText
import com.university.pcl.data.Prefs
import com.university.pcl.data.ScheduleCache
import com.university.pcl.data.WeekUtil
import com.university.pcl.data.Weekdays
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale

/**
 * 桌面组件：同时显示「今天的课表」和「计划统计 + 计划列表」。
 *
 * - 4x2（高 < 200dp）紧凑模式：头部 + 今天有课的 1~2 行 + 计划统计（高度够时 1 条计划）；
 * - 4x4（高 >= 200dp）完整模式：头部 + 今天有课的最多 4 行 + 计划统计 + 按剩余高度
 *   动态计算的 2~5 条计划。
 *
 * 组件上可以直接操作计划：待办勾选、计数 +1、「＋」新建、点计划行编辑/删除（弹窗）、
 * 右上角「↻」手动刷新。
 */
class ScheduleWidget : GlanceAppWidget() {

    /**
     * 用 [SizeMode.Exact]，LocalSize 才是组件实际尺寸（4x2 / 4x4）。
     * 默认的 [SizeMode.Single] 只会给出 providerInfo 里的最小高度（110dp），
     * 会导致 LocalSize 永远 < 200dp、完整模式永远显示不出来。
     */
    override val sizeMode: SizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val appContext = context.applicationContext
        val cache = withContext(Dispatchers.IO) { CacheStore(appContext).load() }
        val manual = withContext(Dispatchers.IO) {
            ManualCourseStore(appContext).load().map { it.toSlot() }
        }
        val week = withContext(Dispatchers.IO) { currentWeek(appContext) }
        val night = (appContext.resources.configuration.uiMode and
            Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val openApp: Action = actionStartActivity(Intent(appContext, MainActivity::class.java))
        provideContent {
            WidgetContent(appContext, cache, manual, week, night, openApp)
        }
    }

    private fun currentWeek(context: Context): Int {
        val prefs = Prefs(context)
        if (prefs.week > 0) return prefs.week
        val term = prefs.term.ifBlank { WeekUtil.guessTerm() }
        val start = prefs.semesterStart.ifBlank {
            com.university.pcl.data.TermCalendar.startOf(term) ?: ""
        }
        val computed = WeekUtil.weekFromStart(start)
        return if (computed > 0) computed else 1
    }
}

private val widgetPalette = listOf(
    Color(0xFF6FBF4A), Color(0xFF1FA463), Color(0xFF3E8EF7), Color(0xFFD06BD6),
    Color(0xFFC07A16), Color(0xFFF07A79), Color(0xFF8B5CF6), Color(0xFF0EA5A4)
)

private fun courseColor(name: String): Color =
    widgetPalette[kotlin.math.abs(name.hashCode()) % widgetPalette.size]

private val GlassLight = Color(0xF2FFFFFF)
private val GlassDark = Color(0xE6242424)
private val TextLight = Color(0xFF111111)
private val TextDark = Color(0xFFF3F3F3)

private val AccentBlue = Color(0xFF3482FF)
private val AccentBlueNight = Color(0xFF9FC3FF)
private val OverdueColor = Color(0xFFF07A79)

private fun bgColor(night: Boolean): Color = if (night) GlassDark else GlassLight
private fun mainColor(night: Boolean): Color = if (night) TextDark else TextLight
private fun subColor(night: Boolean): Color = if (night) Color(0x66FFFFFF) else Color(0x66000000)
private fun emptyPillColor(night: Boolean): Color =
    if (night) Color(0x1AFFFFFF) else Color(0x0F000000)

private fun todaySlots(
    cache: ScheduleCache?,
    manual: List<CourseSlot>,
    week: Int
): List<CourseSlot> {
    val today = LocalDate.now().dayOfWeek.value
    return (cache?.items.orEmpty() + manual).filter { it.day == today && it.activeIn(week) }
}

/** 今天有课的节次（按大节排序，每个大节取第一门），最多 [limit] 行。 */
private fun coursesForToday(slots: List<CourseSlot>, limit: Int): List<CourseSlot> {
    if (limit <= 0) return emptyList()
    val ordered = (1..BigSections.COUNT).mapNotNull { section ->
        slots.firstOrNull { it.bigSection == section }
    }
    return ordered.take(limit)
}

/** 组件自己记录的手动刷新时间（毫秒，0 = 还没手动刷过）。 */
private fun readLastRefresh(context: Context): Long =
    context.getSharedPreferences(PlanWidgetKeys.PREFS_NAME, Context.MODE_PRIVATE)
        .getLong(PlanWidgetKeys.KEY_LAST_REFRESH, 0L)

/** 头部第二行的「更新 HH:mm」后缀；没手动刷过就为空。 */
private fun refreshSuffix(lastRefresh: Long): String {
    if (lastRefresh <= 0L) return ""
    return try {
        " · 更新 " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(lastRefresh))
    } catch (e: Exception) {
        ""
    }
}

/**
 * 组件内容。计划列表和刷新时间在组合期读取：Glance 的 update() 在会话还活着时
 * 不会重新执行 provideGlance，如果只在 provideGlance 里读，勾选/计数/刷新之后
 * 组件会一直显示旧数据。
 */
@Composable
private fun WidgetContent(
    appContext: Context,
    cache: ScheduleCache?,
    manual: List<CourseSlot>,
    week: Int,
    night: Boolean,
    openApp: Action
) {
    val plans = PlanStore(appContext).load()
    val lastRefresh = readLastRefresh(appContext)
    val height = LocalSize.current.height
    if (height < 200.dp) {
        CompactContent(appContext, cache, manual, week, plans, lastRefresh, night, openApp)
    } else {
        FullContent(appContext, cache, manual, week, plans, lastRefresh, night, openApp)
    }
}

/** 4x2 紧凑模式：头部 + 今天课程最多 2 行 + 计划统计（高度够时 1 条计划）。 */
@Composable
private fun CompactContent(
    appContext: Context,
    cache: ScheduleCache?,
    manual: List<CourseSlot>,
    week: Int,
    plans: List<PlanItem>,
    lastRefresh: Long,
    night: Boolean,
    openApp: Action
) {
    val today = LocalDate.now()
    val todayStr = PlanText.todayString()
    val slots = todaySlots(cache, manual, week)
    val dayName = Weekdays.long.getOrNull(today.dayOfWeek.value - 1) ?: ""
    val height = LocalSize.current.height.value

    val courses = coursesForToday(slots, if (height >= 128f) 2 else 1)
    // 高度预算（dp）：上下 padding 16 + 头部 36 + 两段间距 10 + 课程区（20/行，
    // 今天没课时占位 20）+ 统计行 18；剩下的够一行计划（30）才显示
    val courseArea = if (courses.isEmpty()) 20f else 20f * courses.size
    val left = height - 16f - 36f - 10f - courseArea - 18f
    val planLimit = if (left >= 32f) 1 else 0
    val addAction: Action = actionStartActivity(planEditIntent(appContext, null))

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ColorProvider(bgColor(night)))
            .cornerRadius(21.dp)
            .padding(horizontal = 10.dp, vertical = 8.dp)
            .clickable(openApp),
        verticalAlignment = Alignment.Top
    ) {
        WidgetHeader(
            title = "${today.monthValue}月${today.dayOfMonth}日 $dayName",
            sub = "第 $week 周" +
                (if (cache == null) " · 未同步" else refreshSuffix(lastRefresh)),
            night = night,
            addAction = addAction
        )
        Spacer(modifier = GlanceModifier.height(6.dp))
        CourseSection(courses, night, compact = true)
        Spacer(modifier = GlanceModifier.height(4.dp))
        PlanSection(plans, planLimit, todayStr, night, appContext, addAction)
    }
}

/** 4x4 完整模式：头部 + 今天课程最多 4 行 + 计划统计 + 动态 2~5 条计划。 */
@Composable
private fun FullContent(
    appContext: Context,
    cache: ScheduleCache?,
    manual: List<CourseSlot>,
    week: Int,
    plans: List<PlanItem>,
    lastRefresh: Long,
    night: Boolean,
    openApp: Action
) {
    val today = LocalDate.now()
    val todayStr = PlanText.todayString()
    val slots = todaySlots(cache, manual, week)
    val dayName = Weekdays.long.getOrNull(today.dayOfWeek.value - 1) ?: ""
    val height = LocalSize.current.height.value

    // 先保证至少能放 2 条计划（2 * 30dp），剩下的高度才给课程行，避免 4x4 贴边时被裁掉
    // 高度预算（dp）：上下 padding 20 + 头部 36 + 两段间距 10 + 统计行 18
    val maxCourseRows = ((height - 144f) / 22f).toInt().coerceIn(0, 4)
    val courses = coursesForToday(slots, maxCourseRows)
    // 课程区 22/行（今天没课时占位 22）；再按 30dp 一行算计划行数，至少 2 行、最多 5 行
    val courseArea = if (courses.isEmpty()) 22f else 22f * courses.size
    val left = height - 20f - 36f - 10f - courseArea - 18f
    val planLimit = (left / 30f).toInt().coerceIn(2, 5)
    val addAction: Action = actionStartActivity(planEditIntent(appContext, null))

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ColorProvider(bgColor(night)))
            .cornerRadius(21.dp)
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .clickable(openApp),
        verticalAlignment = Alignment.Top
    ) {
        WidgetHeader(
            title = "${today.monthValue}月${today.dayOfMonth}日 $dayName",
            sub = "第 $week 周" +
                (if (cache == null) " · 未同步" else refreshSuffix(lastRefresh)),
            night = night,
            addAction = addAction
        )
        Spacer(modifier = GlanceModifier.height(6.dp))
        CourseSection(courses, night, compact = false)
        Spacer(modifier = GlanceModifier.height(4.dp))
        PlanSection(plans, planLimit, todayStr, night, appContext, addAction)
    }
}

/**
 * 头部一行：左边日期 + 「第 N 周 · 更新 HH:mm」，右边「↻」刷新和「＋」新建。
 * 头部空白处点击会落到最外层 Column 的 clickable（打开 MainActivity）。
 */
@Composable
private fun WidgetHeader(
    title: String,
    sub: String,
    night: Boolean,
    addAction: Action
) {
    Row(
        modifier = GlanceModifier.fillMaxWidth().height(36.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = GlanceModifier.defaultWeight()) {
            Text(
                text = title,
                style = TextStyle(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = ColorProvider(mainColor(night))
                ),
                maxLines = 1
            )
            Text(
                text = sub,
                style = TextStyle(fontSize = 9.sp, color = ColorProvider(subColor(night))),
                maxLines = 1
            )
        }
        WidgetIconButton("↻", actionRunCallback<WidgetRefreshAction>(), night)
        Spacer(modifier = GlanceModifier.width(6.dp))
        WidgetIconButton("＋", addAction, night)
    }
}

/** 头部的小方形图标按钮（刷新 / 新建）。 */
@Composable
private fun WidgetIconButton(label: String, action: Action, night: Boolean) {
    Box(
        modifier = GlanceModifier
            .size(26.dp)
            .background(ColorProvider(emptyPillColor(night)))
            .cornerRadius(13.dp)
            .clickable(action),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = TextStyle(
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = ColorProvider(mainColor(night))
            ),
            maxLines = 1
        )
    }
}

/**
 * 课表区：只显示今天有课的节次（不再显示无课占位行），按大节排序。
 * 单独包一层 Column，避免根 Column 子元素超过 RemoteViews 的 10 个上限。
 */
@Composable
private fun CourseSection(courses: List<CourseSlot>, night: Boolean, compact: Boolean) {
    Column(modifier = GlanceModifier.fillMaxWidth()) {
        if (courses.isEmpty()) {
            Box(
                modifier = GlanceModifier
                    .fillMaxWidth()
                    .height(if (compact) 20.dp else 22.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text(
                    text = "今天没课",
                    style = TextStyle(
                        fontSize = if (compact) 10.sp else 11.sp,
                        color = ColorProvider(subColor(night))
                    ),
                    maxLines = 1
                )
            }
        } else {
            for (item in courses) {
                CourseRow(item, night, compact)
            }
        }
    }
}

/** 一门课：节次标签 + 彩色课程块（课程名 + 地点小字）。 */
@Composable
private fun CourseRow(item: CourseSlot, night: Boolean, compact: Boolean) {
    val rowHeight = if (compact) 20.dp else 22.dp
    Row(
        modifier = GlanceModifier.fillMaxWidth().height(rowHeight),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = BigSections.shortLabels.getOrNull(item.bigSection - 1) ?: "",
            style = TextStyle(
                fontSize = if (compact) 8.sp else 9.sp,
                color = ColorProvider(subColor(night))
            ),
            modifier = GlanceModifier.width(if (compact) 24.dp else 28.dp),
            maxLines = 1
        )
        Box(
            modifier = GlanceModifier
                .defaultWeight()
                .height(if (compact) 18.dp else 20.dp)
                .background(ColorProvider(courseColor(item.name)))
                .cornerRadius(if (compact) 6.dp else 8.dp)
                .padding(horizontal = 7.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = item.name,
                    style = TextStyle(
                        fontSize = if (compact) 10.sp else 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = ColorProvider(Color.White)
                    ),
                    modifier = GlanceModifier.defaultWeight(),
                    maxLines = 1
                )
                if (item.room.isNotBlank()) {
                    Text(
                        text = " @" + item.room,
                        style = TextStyle(
                            fontSize = if (compact) 8.sp else 9.sp,
                            color = ColorProvider(Color(0xD9FFFFFF))
                        ),
                        maxLines = 1
                    )
                }
            }
        }
    }
}

/**
 * 计划区：一行统计「计划 3/8 · 38%」+ 计划列表（待办用 CheckBox，计数用「＋1」按钮）。
 * 行数由外部按剩余高度算好传入；空计划时显示「暂无计划，点 ＋ 添加」。
 */
@Composable
private fun PlanSection(
    plans: List<PlanItem>,
    limit: Int,
    today: String,
    night: Boolean,
    appContext: Context,
    addAction: Action
) {
    val summary = PlanStats.summarize(plans, today)
    val rows = if (limit > 0) PlanSort.forWidget(plans, today, limit) else emptyList()

    Column(modifier = GlanceModifier.fillMaxWidth()) {
        Row(
            modifier = GlanceModifier.fillMaxWidth().height(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "计划 ${summary.completed}/${summary.total} · ${summary.percent}%",
                style = TextStyle(
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    color = ColorProvider(subColor(night))
                ),
                modifier = GlanceModifier.defaultWeight(),
                maxLines = 1
            )
            if (summary.overdue > 0) {
                Text(
                    text = "${summary.overdue} 项过期",
                    style = TextStyle(fontSize = 9.sp, color = ColorProvider(OverdueColor)),
                    maxLines = 1
                )
            }
        }
        if (plans.isEmpty()) {
            Box(
                modifier = GlanceModifier.fillMaxWidth().height(22.dp).clickable(addAction),
                contentAlignment = Alignment.CenterStart
            ) {
                Text(
                    text = "暂无计划，点 ＋ 添加",
                    style = TextStyle(fontSize = 10.sp, color = ColorProvider(subColor(night))),
                    maxLines = 1
                )
            }
        } else {
            for (item in rows) {
                PlanRow(item, night, appContext)
            }
        }
    }
}

/**
 * 一条计划：
 * - 待办：CheckBox（勾选 = 完成）+ 行尾「›」（点开编辑/删除弹窗）；
 * - 计数：「＋1」按钮 + 标题与「3/10」进度（点标题区域打开编辑）+ 行尾「›」。
 */
@Composable
private fun PlanRow(item: PlanItem, night: Boolean, appContext: Context) {
    val params = actionParametersOf(PlanWidgetKeys.planIdKey to item.id)
    val editAction: Action = actionStartActivity(planEditIntent(appContext, item.id))

    Row(
        modifier = GlanceModifier.fillMaxWidth().height(30.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (item.isCount) {
            Box(
                modifier = GlanceModifier
                    .width(26.dp)
                    .height(18.dp)
                    .background(
                        ColorProvider(if (night) Color(0x332F6FCF) else Color(0x1A3482FF))
                    )
                    .cornerRadius(9.dp)
                    .clickable(actionRunCallback<PlanIncrementAction>(params)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "＋1",
                    style = TextStyle(
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = ColorProvider(if (night) AccentBlueNight else AccentBlue)
                    ),
                    maxLines = 1
                )
            }
            Spacer(modifier = GlanceModifier.width(6.dp))
            Column(
                modifier = GlanceModifier.defaultWeight().clickable(editAction),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = item.title,
                        style = TextStyle(
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = ColorProvider(mainColor(night))
                        ),
                        modifier = GlanceModifier.defaultWeight(),
                        maxLines = 1
                    )
                    Text(
                        text = PlanText.progressLabel(item),
                        style = TextStyle(
                            fontSize = 9.sp,
                            color = ColorProvider(subColor(night))
                        ),
                        modifier = GlanceModifier.padding(start = 4.dp),
                        maxLines = 1
                    )
                }
            }
        } else {
            CheckBox(
                checked = item.done,
                onCheckedChange = actionRunCallback<TodoToggleAction>(params),
                modifier = GlanceModifier.defaultWeight(),
                text = item.title,
                style = TextStyle(
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = ColorProvider(mainColor(night))
                ),
                colors = CheckboxDefaults.colors(
                    checkedColor = AccentBlue,
                    uncheckedColor = subColor(night)
                ),
                maxLines = 1
            )
        }
        EditChevron(editAction, night)
    }
}

/** 计划行尾的「›」：点开编辑 / 删除弹窗。 */
@Composable
private fun EditChevron(action: Action, night: Boolean) {
    Box(
        modifier = GlanceModifier.size(20.dp).clickable(action),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "›",
            style = TextStyle(fontSize = 14.sp, color = ColorProvider(subColor(night))),
            maxLines = 1
        )
    }
}

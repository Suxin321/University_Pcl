package com.university.pcl.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.university.pcl.data.BigSections
import com.university.pcl.data.DutyScheduler
import com.university.pcl.data.DutyShift
import com.university.pcl.data.FreeTimetable
import com.university.pcl.data.Weekdays
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

private val bigSectionTimes = listOf(
    "8:00 - 9:50",
    "10:10 - 12:00",
    "14:00 - 15:50",
    "16:10 - 18:00",
    "19:00 - 20:50"
)

@Composable
fun RosterContent(
    free: FreeTimetable?,
    roster: List<DutyShift>,
    week: Int,
    autoWeek: Int,
    perSlot: Int,
    avoidSameDay: Boolean,
    message: String?,
    loading: Boolean,
    onImport: () -> Unit,
    onWeekChange: (Int) -> Unit,
    onWeekReset: () -> Unit,
    onGenerate: (start: Int, end: Int, perSlot: Int, avoidSameDay: Boolean) -> Unit,
    onEditSlot: (day: Int, bigSection: Int, names: List<String>) -> Unit,
    onClearWeek: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentWeek = week.coerceAtLeast(1)
    val today = LocalDate.now()
    val todayMonday = today.minusDays((today.dayOfWeek.value - 1).toLong())
    val weekMonday = todayMonday.plusWeeks((currentWeek - autoWeek).toLong())
    val df = DateTimeFormatter.ofPattern("MM-dd")

    val weekShifts = DutyScheduler.weekShifts(roster, currentWeek)
    val shiftMap = weekShifts.associateBy { it.day to it.bigSection }
    val assignCount = weekShifts.sumOf { it.names.size }
    val personCounts = DutyScheduler.countByPerson(weekShifts)

    var showGenerate by remember { mutableStateOf(false) }
    var editTarget by remember { mutableStateOf<Pair<Int, Int>?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 12.dp)
    ) {
        Spacer(Modifier.height(10.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = "第 $currentWeek 周",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "${weekMonday.format(df)} ~ ${weekMonday.plusDays(6).format(df)}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            TextButton(onClick = { onWeekChange(currentWeek - 1) }) { Text("‹") }
            TextButton(onClick = { onWeekReset() }) {
                Text(if (week != autoWeek) "返回本周" else "本周")
            }
            TextButton(onClick = { onWeekChange(currentWeek + 1) }) { Text("›") }
        }

        if (message != null) {
            Text(
                text = message,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        if (free == null || !free.loaded) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(18.dp))
                    .padding(18.dp)
            ) {
                Text(
                    text = "还没有空课表",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "导入社团的「空课表」（.xlsx / .xls）：表头星期一到星期日，" +
                        "每行一个大节，单元格里写「姓名 + 没课的周次」，如 刘如航16-20、王妍1-6 8-11 19；" +
                        "姓名后面没有数字表示这个人所有周都没课。",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = onImport, enabled = !loading) {
                    Text(if (loading) "正在导入…" else "导入空课表")
                }
            }
            Spacer(Modifier.height(20.dp))
            return@Column
        }

        // 空课表状态
        Column(
            Modifier
                .fillMaxWidth()
                .padding(top = 10.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            Text(
                text = "空课表 · ${free.members.size} 人",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = buildString {
                    append("${free.days.size} 天 × ${BigSections.COUNT} 大节")
                    if (free.maxWeek > 0) append(" · 表内最晚第 ${free.maxWeek} 周")
                    append(" · ${formatWhen(free.importedAt)} 导入")
                },
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onImport, enabled = !loading) {
                    Text(if (loading) "导入中…" else "更新空课表", fontSize = 12.sp)
                }
                Button(onClick = { showGenerate = true }) {
                    Text("自动排班", fontSize = 12.sp)
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "本周排班",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = if (assignCount == 0) "还没有排" else "$assignCount 班 · ${personCounts.size} 人",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f)
            )
            if (assignCount > 0) {
                TextButton(onClick = onClearWeek) { Text("清空本周", fontSize = 12.sp) }
            }
        }

        if (assignCount == 0) {
            Text(
                text = "点上面的「自动排班」按空课表排；排完点任意时段可以手动换人。",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 6.dp)
            )
        }

        for (day in free.days) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f), RoundedCornerShape(16.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                val date = weekMonday.plusDays((day - 1).toLong())
                val isToday = date == today
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "周${Weekdays.short[day - 1]}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isToday) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = date.format(df),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(2.dp))
                for (big in 1..BigSections.COUNT) {
                    val names = shiftMap[day to big]?.names.orEmpty()
                    val available = free.freeNames(day, big, currentWeek)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { editTarget = day to big }
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.width(66.dp)) {
                            Text(
                                text = "${BigSections.shortLabels[big - 1]} 节",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = bigSectionTimes[big - 1],
                                fontSize = 8.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (names.isEmpty()) {
                            Text(
                                text = if (available.isEmpty()) "空课表里没人有空" else "未排 · 可排 ${available.size} 人",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                                modifier = Modifier.weight(1f)
                            )
                        } else {
                            Row(
                                modifier = Modifier
                                    .weight(1f)
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                names.forEach { name -> PersonChip(name) }
                            }
                        }
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = "${available.size} 人空",
                            fontSize = 9.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        if (personCounts.isNotEmpty()) {
            Text(
                text = "本周每人班次",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(top = 10.dp)
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                personCounts.forEach { (name, count) ->
                    Text(
                        text = "$name ×$count",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier
                            .background(courseColor(name).copy(alpha = 0.18f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Text(
            text = "点任意时段可手动调整；空课表更新后建议点「自动排班」重新排。",
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 10.dp, bottom = 20.dp)
        )
    }

    if (showGenerate && free != null) {
        GenerateDialog(
            free = free,
            week = currentWeek,
            initialPerSlot = perSlot,
            initialAvoidSameDay = avoidSameDay,
            onDismiss = { showGenerate = false },
            onConfirm = { start, end, need, avoid ->
                showGenerate = false
                onGenerate(start, end, need, avoid)
            }
        )
    }

    val target = editTarget
    if (target != null && free != null) {
        val (day, big) = target
        SlotEditDialog(
            title = "周${Weekdays.short[day - 1]} · ${BigSections.shortLabels[big - 1]} 节 · 第 $currentWeek 周",
            eligible = free.freeNames(day, big, currentWeek),
            current = shiftMap[day to big]?.names.orEmpty(),
            onDismiss = { editTarget = null },
            onSave = { names ->
                editTarget = null
                onEditSlot(day, big, names)
            }
        )
    }
}

@Composable
private fun PersonChip(name: String) {
    Text(
        text = name,
        fontSize = 11.sp,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier
            .background(courseColor(name).copy(alpha = 0.22f), RoundedCornerShape(8.dp))
            .padding(horizontal = 7.dp, vertical = 3.dp)
    )
}

@Composable
private fun SlotEditDialog(
    title: String,
    eligible: List<String>,
    current: List<String>,
    onDismiss: () -> Unit,
    onSave: (List<String>) -> Unit
) {
    val selected = remember(current) { mutableStateOf(current.toSet()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontSize = 16.sp) },
        confirmButton = {
            TextButton(onClick = { onSave(selected.value.toList()) }) { Text("保存") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { onSave(emptyList()) }) { Text("清空") }
                TextButton(onClick = onDismiss) { Text("取消") }
            }
        },
        text = {
            Column(
                Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                if (eligible.isEmpty()) {
                    Text(
                        text = "这一时段在空课表里没人有空，可以先更新空课表。",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Text(
                        text = "可排 ${eligible.size} 人 · 已选 ${selected.value.size} 人",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(4.dp))
                    eligible.forEach { name ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selected.value = if (selected.value.contains(name)) {
                                        selected.value - name
                                    } else {
                                        selected.value + name
                                    }
                                }
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = selected.value.contains(name),
                                onCheckedChange = null
                            )
                            Text(name, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    )
}

@Composable
private fun GenerateDialog(
    free: FreeTimetable,
    week: Int,
    initialPerSlot: Int,
    initialAvoidSameDay: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (start: Int, end: Int, perSlot: Int, avoidSameDay: Boolean) -> Unit
) {
    val defaultStart = week.coerceAtLeast(1)
    val defaultEnd = if (free.maxWeek > 0) {
        free.maxWeek.coerceAtLeast(defaultStart)
    } else {
        maxOf(defaultStart, FreeTimetable.DEFAULT_MAX_WEEK)
    }
    var startText by remember { mutableStateOf(defaultStart.toString()) }
    var endText by remember { mutableStateOf(defaultEnd.toString()) }
    var need by remember { mutableStateOf(initialPerSlot.coerceIn(1, 6)) }
    var avoid by remember { mutableStateOf(initialAvoidSameDay) }

    val start = startText.toIntOrNull()?.coerceIn(1, 30) ?: defaultStart
    val end = endText.toIntOrNull()?.coerceIn(1, 30) ?: defaultEnd
    val valid = start <= end
    val slotCount = if (valid) (end - start + 1) * free.days.size * BigSections.COUNT else 0
    val peopleNeeded = slotCount * need

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("自动排班", fontSize = 17.sp) },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(start, end, need, avoid) },
                enabled = valid
            ) { Text("生成") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("取消") }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = startText,
                        onValueChange = { v -> startText = v.filter { it.isDigit() }.take(2) },
                        label = { Text("起始周") },
                        singleLine = true,
                        modifier = Modifier.width(96.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text("至", fontSize = 13.sp)
                    Spacer(Modifier.width(10.dp))
                    OutlinedTextField(
                        value = endText,
                        onValueChange = { v -> endText = v.filter { it.isDigit() }.take(2) },
                        label = { Text("结束周") },
                        singleLine = true,
                        modifier = Modifier.width(96.dp)
                    )
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("每个时段", fontSize = 13.sp)
                    TextButton(onClick = { need = (need - 1).coerceAtLeast(1) }) { Text("−") }
                    Text("$need 人", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    TextButton(onClick = { need = (need + 1).coerceAtMost(6) }) { Text("+") }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("同一天不排同一人", fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Switch(checked = avoid, onCheckedChange = { avoid = it })
                }
                Spacer(Modifier.height(4.dp))
                if (valid) {
                    Text(
                        text = "第 $start–$end 周 · ${free.days.size} 天 × ${BigSections.COUNT} 大节 = " +
                            "$slotCount 个时段，每时段 $need 人，共约 $peopleNeeded 人次。",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "空课表 ${free.members.size} 人；需要 $peopleNeeded 人次时会尽量平均分配。",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "会覆盖第 $start–$end 周已有的排班。",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                } else {
                    Text(
                        text = "起始周不能大于结束周。",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    )
}

private fun formatWhen(millis: Long): String {
    if (millis <= 0L) return "未知时间"
    return SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(millis))
}

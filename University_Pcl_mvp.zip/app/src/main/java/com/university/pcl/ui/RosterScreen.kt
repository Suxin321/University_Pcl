package com.university.pcl.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.university.pcl.data.BigSections
import com.university.pcl.data.DutyScheduler
import com.university.pcl.data.DutyShift
import com.university.pcl.data.FreeTimetable
import com.university.pcl.data.RosterExporter
import com.university.pcl.data.Weekdays
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

@Composable
fun RosterContent(
    free: FreeTimetable?,
    roster: List<DutyShift>,
    week: Int,
    autoWeek: Int,
    perSlot: Int,
    avoidSameDay: Boolean,
    avoidSameWeek: Boolean,
    sections: List<Int>,
    slotTimes: List<String>,
    message: String?,
    onWeekChange: (Int) -> Unit,
    onWeekReset: () -> Unit,
    onGenerate: (
        start: Int,
        end: Int,
        perSlot: Int,
        avoidSameDay: Boolean,
        avoidSameWeek: Boolean,
        sections: List<Int>
    ) -> Unit,
    onEditSlot: (day: Int, bigSection: Int, names: List<String>) -> Unit,
    onClearWeek: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentWeek = week.coerceAtLeast(1)
    val today = LocalDate.now()
    val todayMonday = today.minusDays((today.dayOfWeek.value - 1).toLong())
    val weekMonday = todayMonday.plusWeeks((currentWeek - autoWeek).toLong())
    val df = DateTimeFormatter.ofPattern("MM-dd")
    val activeSections = sections.filter { it in 1..BigSections.COUNT }.distinct().sorted()
        .ifEmpty { (1..BigSections.COUNT).toList() }

    val weekShifts = DutyScheduler.weekShifts(roster, currentWeek)
    val shiftMap = weekShifts.associateBy { it.day to it.bigSection }
    val assignCount = weekShifts.sumOf { it.names.size }
    val personCount = weekShifts.flatMap { it.names }.distinct().size

    var showGenerate by remember { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }
    var editTarget by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var showStats by remember { mutableStateOf(true) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 12.dp)
    ) {
        Spacer(Modifier.height(10.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = "第 $currentWeek 周",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "${weekMonday.format(df)} ~ ${weekMonday.plusDays(6).format(df)}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            TextButton(onClick = { onWeekChange(currentWeek - 1) }) { Text("‹") }
            TextButton(onClick = { onWeekReset() }) {
                Text(if (week != autoWeek) "返回本周" else "本周")
            }
            TextButton(onClick = { onWeekChange(currentWeek + 1) }) { Text("›") }
        }

        if (message != null) {
            Text(
                text = message,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        if (free == null || !free.loaded) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(18.dp))
                    .padding(18.dp)
            ) {
                Text(
                    text = "还没有空课表",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "空课表在「设置 → 排班 · 空课表」里导入（.xlsx / .xls）。" +
                        "格式：表头星期一到星期日，每行一个大节，单元格写「姓名 + 没课的周次」；" +
                        "姓名后面没有数字表示这个人所有周都没课。",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = onOpenSettings) { Text("去设置导入") }
            }
            Spacer(Modifier.height(20.dp))
            return@Column
        }

        // 空课表状态 + 操作
        Column(
            Modifier
                .fillMaxWidth()
                .padding(top = 10.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "空课表 · ${free.members.size} 人",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = onOpenSettings) { Text("去设置", fontSize = 12.sp) }
            }
            Text(
                text = buildString {
                    append("${free.days.size} 天 × ${BigSections.COUNT} 大节")
                    if (free.maxWeek > 0) append(" · 最晚第 ${free.maxWeek} 周")
                    append(" · ${formatWhen(free.importedAt)}")
                },
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = "排班时段：${activeSections.joinToString("、") { "${BigSections.shortLabels[it - 1]}节" }}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 2.dp)
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { showGenerate = true }) { Text("自动排班", fontSize = 12.sp) }
                OutlinedButton(onClick = { showExport = true }, enabled = roster.isNotEmpty()) {
                    Text("导出排班表", fontSize = 12.sp)
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // 周排班表头
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "第 $currentWeek 周值班表",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = if (assignCount == 0) "还没有排" else "$assignCount 班 · $personCount 人",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.weight(1f)
            )
            if (assignCount > 0) {
                TextButton(onClick = onClearWeek) { Text("清空本周", fontSize = 12.sp) }
            }
        }

        if (assignCount == 0) {
            Text(
                text = "点「自动排班」按空课表生成；排完点任意格子可以手动换人。",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 6.dp)
            )
        }

        Spacer(Modifier.height(6.dp))

        // 课表样式的 星期 × 大节 网格
        Row(Modifier.fillMaxWidth()) {
            Spacer(Modifier.width(44.dp))
            for (day in free.days) {
                val date = weekMonday.plusDays((day - 1).toLong())
                val isToday = date == today
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .padding(vertical = 4.dp)
                ) {
                    Text(
                        text = "周${Weekdays.short[day - 1]}",
                        fontSize = 12.sp,
                        fontWeight = if (isToday) FontWeight.Bold else FontWeight.Medium,
                        color = if (isToday) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = date.format(df),
                        fontSize = 9.sp,
                        color = if (isToday) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        for (big in activeSections) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(66.dp)
                    .padding(vertical = 1.dp)
            ) {
                Column(
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .width(44.dp)
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "${BigSections.shortLabels[big - 1]}节",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.width(40.dp)
                    )
                    Text(
                        text = slotTimes.getOrElse(big - 1) { "" },
                        fontSize = 6.5.sp,
                        maxLines = 1,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                        modifier = Modifier.width(44.dp)
                    )
                }
                for (day in free.days) {
                    val date = weekMonday.plusDays((day - 1).toLong())
                    val names = shiftMap[day to big]?.names.orEmpty()
                    RosterCell(
                        names = names,
                        isToday = date == today,
                        onClick = { editTarget = day to big },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .padding(horizontal = 1.dp)
                    )
                }
            }
        }

        val noOneFree = free.days.sumOf { d ->
            activeSections.count { b -> free.freeNames(d, b, currentWeek).isEmpty() }
        }
        Text(
            text = "点任意格子可手动换人" +
                (if (noOneFree > 0) "；本周有 $noOneFree 个时段空课表里没人有空" else ""),
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp)
        )

        // 值班次数表
        Spacer(Modifier.height(18.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp)
                .clickable { showStats = !showStats }
        ) {
            Text(
                text = "值班次数表",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = if (showStats) "收起" else "展开",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(vertical = 6.dp)
            )
        }

        if (showStats) {
            val nameList = (free.members + roster.flatMap { it.names }).distinct()
            val weekCounts = weekShifts.flatMap { it.names }.groupingBy { it }.eachCount()
            val totalCounts = roster.flatMap { it.names }.groupingBy { it }.eachCount()
            val sorted = nameList.sortedWith(
                compareByDescending<String> { totalCounts[it] ?: 0 }
                    .thenByDescending { weekCounts[it] ?: 0 }
                    .thenBy { it }
            )
            val totalShifts = totalCounts.values.sum()
            val weekRows = roster.map { it.week }.distinct().size

            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 2.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "共 ${sorted.size} 人",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.weight(1f))
                    Text(
                        text = "本周 $assignCount 班 · 已排 $totalShifts 班 / $weekRows 周",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "姓名",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "本周",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.width(44.dp),
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = "合计",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.width(44.dp),
                        textAlign = TextAlign.Center
                    )
                }
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .height(1.dp)
                        .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                )
                sorted.forEach { name ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .background(courseColor(name), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = name.takeLast(1),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = name,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        CountPill(weekCounts[name] ?: 0, highlight = (weekCounts[name] ?: 0) > 0)
                        Spacer(Modifier.width(6.dp))
                        CountPill(totalCounts[name] ?: 0, highlight = false)
                    }
                }
            }
            Text(
                text = "「本周」只统计第 $currentWeek 周；「合计」统计所有已生成的周。",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 5.dp, start = 4.dp)
            )
        }

        Text(
            text = "空课表更新后到「设置」重新导入；排哪几节、每节起止时间也在设置和「自动排班」里调。",
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 10.dp, bottom = 20.dp)
        )
    }

    if (showGenerate && free != null) {
        GenerateDialog(
            free = free,
            week = currentWeek,
            initialPerSlot = perSlot,
            initialAvoidSameDay = avoidSameDay,
            initialAvoidSameWeek = avoidSameWeek,
            initialSections = activeSections,
            onDismiss = { showGenerate = false },
            onConfirm = { start, end, need, avoidDay, avoidWeek, chosenSections ->
                showGenerate = false
                onGenerate(start, end, need, avoidDay, avoidWeek, chosenSections)
            }
        )
    }

    if (showExport && free != null) {
        ExportDialog(
            free = free,
            roster = roster,
            currentWeek = currentWeek,
            sections = activeSections,
            slotTimes = slotTimes,
            onDismiss = { showExport = false }
        )
    }

    val target = editTarget
    if (target != null && free != null) {
        val (day, big) = target
        SlotEditDialog(
            title = "周${Weekdays.short[day - 1]} · ${BigSections.shortLabels[big - 1]} 节 · 第 $currentWeek 周",
            eligible = free.freeNames(day, big, currentWeek),
            current = shiftMap[day to big]?.names.orEmpty(),
            onDismiss = { editTarget = null },
            onSave = { names ->
                editTarget = null
                onEditSlot(day, big, names)
            }
        )
    }
}

@Composable
private fun RosterCell(
    names: List<String>,
    isToday: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val base = if (isToday) {
        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
    } else {
        Color.Transparent
    }
    Box(
        modifier = modifier
            .background(base, RoundedCornerShape(6.dp))
            .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(2.dp)
    ) {
        Column(Modifier.fillMaxSize()) {
            names.take(2).forEach { name ->
                Text(
                    text = name,
                    fontSize = 9.sp,
                    lineHeight = 11.sp,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 1.dp)
                        .background(courseColor(name), RoundedCornerShape(5.dp))
                        .padding(horizontal = 3.dp, vertical = 1.dp)
                )
            }
            if (names.size > 2) {
                Text(
                    text = "+${names.size - 2} 人",
                    fontSize = 8.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 2.dp)
                )
            }
        }
    }
}

@Composable
private fun CountPill(value: Int, highlight: Boolean) {
    Box(
        modifier = Modifier
            .width(44.dp)
            .background(
                color = if (highlight) {
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)
                } else {
                    MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)
                },
                shape = RoundedCornerShape(8.dp)
            )
            .padding(vertical = 3.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "$value",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (highlight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SlotEditDialog(
    title: String,
    eligible: List<String>,
    current: List<String>,
    onDismiss: () -> Unit,
    onSave: (List<String>) -> Unit
) {
    val selected = remember(current) { mutableStateOf(current.toSet()) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontSize = 16.sp) },
        confirmButton = {
            TextButton(onClick = { onSave(selected.value.toList()) }) { Text("保存") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { onSave(emptyList()) }) { Text("清空") }
                TextButton(onClick = onDismiss) { Text("取消") }
            }
        },
        text = {
            Column(
                Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                if (eligible.isEmpty()) {
                    Text(
                        text = "这一时段在空课表里没人有空，可以先更新空课表。",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    Text(
                        text = "可排 ${eligible.size} 人 · 已选 ${selected.value.size} 人",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(4.dp))
                    eligible.forEach { name ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selected.value = if (selected.value.contains(name)) {
                                        selected.value - name
                                    } else {
                                        selected.value + name
                                    }
                                }
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = selected.value.contains(name),
                                onCheckedChange = null
                            )
                            Text(name, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    )
}

@Composable
private fun GenerateDialog(
    free: FreeTimetable,
    week: Int,
    initialPerSlot: Int,
    initialAvoidSameDay: Boolean,
    initialAvoidSameWeek: Boolean,
    initialSections: List<Int>,
    onDismiss: () -> Unit,
    onConfirm: (
        start: Int,
        end: Int,
        perSlot: Int,
        avoidSameDay: Boolean,
        avoidSameWeek: Boolean,
        sections: List<Int>
    ) -> Unit
) {
    val defaultStart = week.coerceAtLeast(1)
    val defaultEnd = if (free.maxWeek > 0) {
        free.maxWeek.coerceAtLeast(defaultStart)
    } else {
        maxOf(defaultStart, FreeTimetable.DEFAULT_MAX_WEEK)
    }
    var startText by remember { mutableStateOf(defaultStart.toString()) }
    var endText by remember { mutableStateOf(defaultEnd.toString()) }
    var need by remember { mutableStateOf(initialPerSlot.coerceIn(1, 6)) }
    var avoidDay by remember { mutableStateOf(initialAvoidSameDay) }
    var avoidWeek by remember { mutableStateOf(initialAvoidSameWeek) }
    var chosen by remember {
        mutableStateOf(
            initialSections.filter { it in 1..BigSections.COUNT }.distinct().sorted()
                .ifEmpty { (1..BigSections.COUNT).toList() }
                .toSet()
        )
    }

    val start = startText.toIntOrNull()?.coerceIn(1, 30) ?: defaultStart
    val end = endText.toIntOrNull()?.coerceIn(1, 30) ?: defaultEnd
    val valid = start <= end
    val sectionList = chosen.sorted()
    val slotCount = if (valid) (end - start + 1) * free.days.size * sectionList.size else 0
    val peopleNeeded = slotCount * need

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("自动排班", fontSize = 17.sp) },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(start, end, need, avoidDay, avoidWeek, sectionList) },
                enabled = valid && sectionList.isNotEmpty()
            ) { Text("生成") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("取消") }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = startText,
                        onValueChange = { v -> startText = v.filter { it.isDigit() }.take(2) },
                        label = { Text("起始周") },
                        singleLine = true,
                        modifier = Modifier.width(96.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text("至", fontSize = 13.sp)
                    Spacer(Modifier.width(10.dp))
                    OutlinedTextField(
                        value = endText,
                        onValueChange = { v -> endText = v.filter { it.isDigit() }.take(2) },
                        label = { Text("结束周") },
                        singleLine = true,
                        modifier = Modifier.width(96.dp)
                    )
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("每个时段", fontSize = 13.sp)
                    TextButton(onClick = { need = (need - 1).coerceAtLeast(1) }) { Text("−") }
                    Text("$need 人", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    TextButton(onClick = { need = (need + 1).coerceAtMost(6) }) { Text("+") }
                }
                Text("排班大节", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (b in 1..BigSections.COUNT) {
                        SectionChip(
                            label = "${BigSections.shortLabels[b - 1]}节",
                            selected = chosen.contains(b),
                            onClick = {
                                chosen = if (chosen.contains(b)) {
                                    // 至少留一节
                                    if (chosen.size > 1) chosen - b else chosen
                                } else {
                                    chosen + b
                                }
                            }
                        )
                    }
                }
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("同一天不排同一人", fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Switch(checked = avoidDay, onCheckedChange = { avoidDay = it })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("同一周不排同一人", fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Switch(checked = avoidWeek, onCheckedChange = { avoidWeek = it })
                }
                if (avoidWeek && !avoidDay) {
                    Text(
                        text = "「同一周不重复」比「同一天不重复」更严格，人少时会自动通融避免留空。",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.height(4.dp))
                if (valid) {
                    Text(
                        text = "第 $start–$end 周 · ${free.days.size} 天 × ${sectionList.size} 节 = " +
                            "$slotCount 个时段，每时段 $need 人，共约 $peopleNeeded 人次。",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "空课表 ${free.members.size} 人；需要 $peopleNeeded 人次时会尽量平均分配。",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "会覆盖第 $start–$end 周已有的排班。",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                } else {
                    Text(
                        text = "起始周不能大于结束周。",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    )
}

@Composable
private fun SectionChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(10.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun ExportDialog(
    free: FreeTimetable,
    roster: List<DutyShift>,
    currentWeek: Int,
    sections: List<Int>,
    slotTimes: List<String>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val defaultStart = roster.minOfOrNull { it.week } ?: currentWeek
    val defaultEnd = roster.maxOfOrNull { it.week } ?: currentWeek
    var startText by remember { mutableStateOf(defaultStart.toString()) }
    var endText by remember { mutableStateOf(defaultEnd.toString()) }

    val start = startText.toIntOrNull()?.coerceIn(1, 30) ?: defaultStart
    val end = endText.toIntOrNull()?.coerceIn(1, 30) ?: defaultEnd
    val valid = start <= end
    val text = if (valid) {
        RosterExporter.text(roster, start, end, free.days, sections, slotTimes)
    } else {
        "起始周不能大于结束周"
    }
    val shiftCount = roster.count { it.week in start..end && it.names.isNotEmpty() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("导出排班表", fontSize = 17.sp) },
        confirmButton = {
            TextButton(
                onClick = {
                    shareText(context, text)
                    onDismiss()
                },
                enabled = valid && shiftCount > 0
            ) { Text("分享") }
        },
        dismissButton = {
            Row {
                TextButton(
                    onClick = {
                        copyText(context, text)
                        Toast.makeText(context, "排班表已复制", Toast.LENGTH_SHORT).show()
                        onDismiss()
                    },
                    enabled = valid && shiftCount > 0
                ) { Text("复制") }
                TextButton(onClick = onDismiss) { Text("取消") }
            }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = startText,
                        onValueChange = { v -> startText = v.filter { it.isDigit() }.take(2) },
                        label = { Text("起始周") },
                        singleLine = true,
                        modifier = Modifier.width(96.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text("至", fontSize = 13.sp)
                    Spacer(Modifier.width(10.dp))
                    OutlinedTextField(
                        value = endText,
                        onValueChange = { v -> endText = v.filter { it.isDigit() }.take(2) },
                        label = { Text("结束周") },
                        singleLine = true,
                        modifier = Modifier.width(96.dp)
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    text = if (valid) "第 $start–$end 周 · 共 $shiftCount 个已排时段" else "起始周不能大于结束周",
                    fontSize = 12.sp,
                    color = if (valid) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error
                )
                Spacer(Modifier.height(8.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .heightIn(max = 260.dp)
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
                        .padding(10.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = text,
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "「复制」后可粘贴到群里；「分享」可发到微信 / QQ。",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    )
}

private fun copyText(context: Context, text: String) {
    val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
    manager.setPrimaryClip(ClipData.newPlainText("排班表", text))
}

private fun shareText(context: Context, text: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
        putExtra(Intent.EXTRA_SUBJECT, "排班表")
    }
    context.startActivity(
        Intent.createChooser(intent, "分享排班表").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

private fun formatWhen(millis: Long): String {
    if (millis <= 0L) return "导入时间未知"
    return SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(millis)) + " 导入"
}

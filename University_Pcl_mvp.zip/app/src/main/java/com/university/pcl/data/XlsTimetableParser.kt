package com.university.pcl.data

import jxl.Workbook
import java.io.File
import java.io.InputStream

/**
 * 解析教务系统「导出」的 .xls 课表（Excel 97-2003，强智导出格式）。
 *
 * 格式：第 1 行标题、第 2 行元信息（含学年学期）、第 3 行是星期表头、
 * 之后 5 行分别是第一~第五大节，每行第 2~8 列是周一到周日。
 * 单元格内每门课固定 4 行：[课程名, 老师;周次;节次, 学时类型, 地点]，多门课连续排列。
 */
object XlsTimetableParser {

    data class Result(val term: String?, val slots: List<CourseSlot>)

    private val bigSectionLabels = listOf(
        "第一大节" to 1,
        "第二大节" to 2,
        "第三大节" to 3,
        "第四大节" to 4,
        "第五大节" to 5
    )
    private val termRegex = Regex("""学年学期[：:]\s*(\d{4}-\d{4}-[12])""")
    private val sectionRegex = Regex("""(\d+)\s*(?:[-~～]\s*(\d+))?\s*节""")

    fun parse(file: File): Result = file.inputStream().use { parse(it) }

    fun parse(input: InputStream): Result {
        val workbook = Workbook.getWorkbook(input)
        try {
            val sheet = workbook.getSheet(0)
            var term: String? = null
            val slots = ArrayList<CourseSlot>()

            for (row in 0 until sheet.rows) {
                val label = sheet.getCell(0, row).contents.trim()
                if (label.isNotEmpty()) {
                    termRegex.find(label)?.groupValues?.get(1)?.let { term = it }
                }
                val fallbackBig = bigSectionLabels
                    .firstOrNull { label.startsWith(it.first) }
                    ?.second ?: continue

                for (day in 1 until sheet.columns) {
                    val text = sheet.getCell(day, row).contents
                    if (text.isBlank()) continue
                    parseCell(text, day, fallbackBig, slots)
                }
            }
            return Result(term, slots)
        } finally {
            workbook.close()
        }
    }

    private fun parseCell(text: String, day: Int, fallbackBig: Int, out: MutableList<CourseSlot>) {
        val lines = text.replace('\r', '\n').split('\n')
            .map { it.trim() }
            .filter { it.isNotEmpty() }

        var index = 0
        while (index < lines.size) {
            val info = lines[index]
            if (!info.contains(';')) {
                index++
                continue
            }
            val name = if (index > 0 && !lines[index - 1].contains(';')) lines[index - 1] else ""
            val parts = info.split(';').map { it.trim() }
            val teacher = parts.getOrElse(0) { "" }
            val weekText = parts.getOrElse(1) { "" }
            val sectionText = parts.drop(2).joinToString(";")
            val (weeks, parity) = QiangzhiParser.parseWeekText(weekText)
            val bigSection = sectionRegex.find(sectionText)
                ?.groupValues?.get(1)?.toIntOrNull()
                ?.let { ((it - 1) / 2 + 1).coerceIn(1, BigSections.COUNT) }
                ?: fallbackBig

            var next = index + 1
            if (next < lines.size && lines[next].endsWith("学时")) next++
            val room = if (next < lines.size && !lines[next].contains(';') && !lines[next].endsWith("学时")) {
                lines[next].also { next++ }
            } else {
                ""
            }

            if (name.isNotBlank()) {
                out += CourseSlot(
                    day = day,
                    bigSection = bigSection,
                    name = name,
                    room = RoomText.compact(room),
                    teacher = teacher,
                    weekText = weekText,
                    weeks = weeks,
                    parity = parity
                )
            }
            index = next
        }
    }
}

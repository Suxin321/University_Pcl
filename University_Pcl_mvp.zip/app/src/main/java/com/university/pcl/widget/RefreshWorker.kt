package com.university.pcl.widget

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/** 定时刷新桌面组件（离线：只重绘组件，不联网）。 */
class RefreshWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        return try {
            WidgetUpdater.update(applicationContext)
            Result.success()
        } finally {
            WidgetRefreshScheduler.scheduleDaily(applicationContext)
        }
    }
}

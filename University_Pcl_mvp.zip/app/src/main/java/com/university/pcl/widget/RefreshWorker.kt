package com.university.pcl.widget

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.university.pcl.data.Prefs
import com.university.pcl.data.ScheduleRepository

/** 后台刷新课表并更新桌面组件。 */
class RefreshWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        return try {
            val prefs = Prefs(applicationContext)
            if (!prefs.isLoggedIn) {
                Result.success()
            } else {
                val repo = ScheduleRepository(applicationContext)
                val result = if (prefs.exportUrl.isNotBlank()) {
                    val auto = repo.autoDownload()
                    if (auto.isSuccess) auto else repo.refresh()
                } else {
                    repo.refresh()
                }
                when {
                    result.isSuccess -> Result.success()
                    runAttemptCount < 2 -> Result.retry()
                    else -> Result.success()
                }
            }
        } finally {
            // 先排下一天 00:05（非 suspend，取消也打断不了），避免跨天刷新链断掉
            WidgetRefreshScheduler.scheduleDaily(applicationContext)
            // 组件刷新是尽力而为；协程被取消时 WidgetUpdater 会重抛 CancellationException
            WidgetUpdater.update(applicationContext)
        }
    }
}

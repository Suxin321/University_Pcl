package com.university.pcl.widget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * 解锁 / 开机时立刻刷新组件数据（课表、计划、周次），让点亮屏幕后看到的是最新内容。
 *
 * - `ACTION_USER_PRESENT`（解锁）由系统在解锁后发出；部分国产系统未必下发静态注册，
 *   所以搭配 [MinuteTickReceiver] 的每分钟闹钟兜底（Doze 下延后、解锁后补发）。
 * - `ACTION_BOOT_COMPLETED` 用来开机后重新挂上各种刷新调度（WorkManager + 分钟闹钟）。
 */
class ScreenStateReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_USER_PRESENT &&
            action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            return
        }

        val appContext = context.applicationContext
        WidgetRefreshScheduler.ensureScheduled(appContext)

        val result = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                WidgetUpdater.update(appContext)
            } finally {
                result.finish()
            }
        }
    }
}

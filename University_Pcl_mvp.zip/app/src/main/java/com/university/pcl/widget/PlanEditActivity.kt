package com.university.pcl.widget

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.university.pcl.data.PlanEditor
import com.university.pcl.data.PlanItem
import com.university.pcl.data.PlanStore
import com.university.pcl.data.PlanText
import com.university.pcl.data.PlanType
import com.university.pcl.ui.UniversityPclTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * 桌面组件拉起的小弹窗：新建 / 编辑 / 删除一条计划。
 *
 * 用普通 Activity + 自绘半透明遮罩卡片的实现（不用 Compose AlertDialog）：
 * Activity 主题本身是 dialog 风格（Theme.PlanDialog），再套一层 Dialog 容易出问题。
 *
 * Intent extras：
 * - [EXTRA_MODE] = [MODE_ADD] / [MODE_EDIT]
 * - [EXTRA_PLAN_ID] = 编辑时的计划 id
 */
class PlanEditActivity : ComponentActivity() {

    companion object {
        const val EXTRA_MODE = "plan_edit_mode"
        const val EXTRA_PLAN_ID = "plan_edit_plan_id"
        const val MODE_ADD = "add"
        const val MODE_EDIT = "edit"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val mode = intent?.getStringExtra(EXTRA_MODE) ?: MODE_ADD
        val planId = intent?.getStringExtra(EXTRA_PLAN_ID).orEmpty()
        val store = PlanStore(applicationContext)
        // 计划数据很小，直接同步读一次（MainActivity 里也是这么用的）。
        val existing: PlanItem? =
            if (mode == MODE_EDIT && planId.isNotBlank()) {
                store.load().firstOrNull { it.id == planId }
            } else {
                null
            }
        // 编辑模式下找不到这条计划（组件显示的是旧数据 / 已在 App 里删掉）：
        // 不要静默变成「新建」，否则保存会多出一条。
        if (mode == MODE_EDIT && existing == null) {
            android.widget.Toast.makeText(
                this,
                "这条计划已经不存在了",
                android.widget.Toast.LENGTH_SHORT
            ).show()
            finish()
            return
        }
        val onDelete: (() -> Unit)? = if (existing != null) {
            { deletePlan(store, existing.id) }
        } else {
            null
        }

        setContent {
            UniversityPclTheme {
                PlanEditDialog(
                    existing = existing,
                    onCancel = { finish() },
                    onDelete = onDelete,
                    onSave = { title, type, date, target ->
                        savePlan(store, existing, title, type, date, target)
                    }
                )
            }
        }
    }

    private fun savePlan(
        store: PlanStore,
        existing: PlanItem?,
        title: String,
        type: String,
        date: String,
        target: Int
    ) {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                if (existing != null) {
                    val now = System.currentTimeMillis()
                    store.mutate { items ->
                        val current = items.firstOrNull { it.id == existing.id }
                            ?: return@mutate items
                        PlanEditor.upsert(
                            items,
                            current.copy(
                                title = title,
                                type = type,
                                date = date,
                                target = target,
                                updatedAt = now
                            )
                        )
                    }
                } else {
                    val item = PlanEditor.create(
                        title = title,
                        type = type,
                        date = date,
                        target = target
                    )
                    store.mutate { items -> PlanEditor.upsert(items, item) }
                }
            }
            WidgetUpdater.update(applicationContext)
            finish()
        }
    }

    private fun deletePlan(store: PlanStore, planId: String) {
        lifecycleScope.launch {
            withContext(Dispatchers.IO) {
                store.mutate { items -> PlanEditor.remove(items, planId) }
            }
            WidgetUpdater.update(applicationContext)
            finish()
        }
    }
}

/**
 * 半透明遮罩 + 居中圆角卡片。点遮罩或返回键直接关闭；卡片自己吞掉点击。
 */
@Composable
private fun PlanEditDialog(
    existing: PlanItem?,
    onCancel: () -> Unit,
    onDelete: (() -> Unit)?,
    onSave: (title: String, type: String, date: String, target: Int) -> Unit
) {
    var title by remember { mutableStateOf(existing?.title.orEmpty()) }
    var type by remember { mutableStateOf(existing?.type ?: PlanType.TODO) }
    var targetText by remember {
        mutableStateOf(
            if (existing != null && existing.isCount) existing.targetSafe.toString() else "10"
        )
    }
    var dateText by remember { mutableStateOf(existing?.date.orEmpty()) }
    var errorText by remember { mutableStateOf("") }
    var confirmDelete by remember { mutableStateOf(false) }
    val isCount = type == PlanType.COUNT
    val today = PlanText.todayString()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0x66000000))
            // targetSdk 35 在 Android 15 上是 edge-to-edge，键盘弹出时用 imePadding 把卡片顶上去
            .imePadding()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onCancel
            ),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(vertical = 24.dp)
                // 吃掉卡片上的点击，避免落到遮罩层直接关闭
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = {}
                ),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            shadowElevation = 12.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 18.dp)
            ) {
                Text(
                    text = if (existing == null) "新建计划" else "编辑计划",
                    style = MaterialTheme.typography.titleLarge
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = {
                        title = it
                        errorText = ""
                    },
                    label = { Text("标题") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TypeChip("待办", selected = !isCount) {
                        type = PlanType.TODO
                        errorText = ""
                    }
                    TypeChip("计数", selected = isCount) {
                        type = PlanType.COUNT
                        errorText = ""
                    }
                }

                if (isCount) {
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = targetText,
                        onValueChange = { input ->
                            targetText = input.filter { it.isDigit() }.take(3)
                            errorText = ""
                        },
                        label = { Text("目标次数（如 10）") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = dateText,
                    onValueChange = {
                        dateText = it
                        errorText = ""
                    },
                    label = { Text("日期（yyyy-MM-dd，可留空）") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DateQuickButton("今天") {
                        dateText = today
                        errorText = ""
                    }
                    DateQuickButton("明天") {
                        dateText = PlanText.shift(today, 1)
                        errorText = ""
                    }
                    DateQuickButton("清除") {
                        dateText = ""
                        errorText = ""
                    }
                }

                if (errorText.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorText,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onCancel) { Text("取消") }
                    Spacer(modifier = Modifier.weight(1f))
                    Button(
                        onClick = {
                            val cleanTitle = title.trim()
                            val normalizedDate = PlanText.normalizeDate(dateText)
                            val target = if (isCount) PlanText.parseTarget(targetText) else 1
                            when {
                                cleanTitle.isEmpty() ->
                                    errorText = "标题不能为空"

                                dateText.isNotBlank() && normalizedDate.isBlank() ->
                                    errorText = "日期格式应为 yyyy-MM-dd"

                                isCount && target == null ->
                                    errorText = "计数目标要填正整数"

                                else ->
                                    onSave(cleanTitle, type, normalizedDate, target ?: 1)
                            }
                        },
                        modifier = Modifier.height(44.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("保存")
                    }
                }

                if (onDelete != null) {
                    Spacer(modifier = Modifier.height(6.dp))
                    TextButton(
                        onClick = {
                            if (confirmDelete) {
                                onDelete()
                            } else {
                                confirmDelete = true
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (confirmDelete) {
                                "删除后无法恢复，再点一次确认"
                            } else {
                                "删除计划"
                            },
                            color = MaterialTheme.colorScheme.error,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

/** 类型选择按钮（待办 / 计数），用基础 layout 自绘，避免依赖实验性 Chip。 */
@Composable
private fun TypeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val background = if (selected) {
        MaterialTheme.colorScheme.primary
    } else {
        MaterialTheme.colorScheme.surfaceVariant
    }
    val foreground = if (selected) {
        MaterialTheme.colorScheme.onPrimary
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(background)
            .clickable { onClick() }
            .padding(horizontal = 18.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text = label, color = foreground, fontSize = 14.sp)
    }
}

/** 日期快捷按钮（今天 / 明天 / 清除）。 */
@Composable
private fun DateQuickButton(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.primaryContainer)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            fontSize = 12.sp
        )
    }
}

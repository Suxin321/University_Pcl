package com.university.pcl.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.university.pcl.data.PlanEditor
import com.university.pcl.data.PlanItem
import com.university.pcl.data.PlanSort
import com.university.pcl.data.PlanStats
import com.university.pcl.data.PlanSummary
import com.university.pcl.data.PlanText
import com.university.pcl.data.PlanType
import com.university.pcl.data.isOverdue

/** 计划列表的筛选条件。 */
private enum class PlanFilter(val label: String) {
    ALL("全部"),
    PENDING("未完成"),
    TODAY("今天"),
    OVERDUE("已过期"),
    DONE("已完成")
}

/** 编辑对话框的表单状态（只在 PlanContent 内部用 remember 管理）。 */
private data class PlanForm(
    val title: String = "",
    val type: String = PlanType.TODO,
    val date: String = "",
    val target: String = "1"
)

/**
 * 「计划统计表」页面：待办（勾选完成）/ 计数（点一次 +1）两种计划，
 * 顶部统计表 + 筛选 + 计划列表 + 新建/编辑/删除。
 *
 * 数据读写全部交给上层：新增/更新走 onSave（按 id 判断是新增还是更新），
 * 删除走 onDelete，打卡走 onToggle / onDecrement。
 */
@Composable
fun PlanContent(
    plans: List<PlanItem>,
    message: String?,
    onSave: (PlanItem) -> Unit,
    onDelete: (String) -> Unit,
    onToggle: (String) -> Unit,
    onDecrement: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val today = PlanText.todayString()
    val summary = PlanStats.summarize(plans, today)
    val sortedPlans = PlanSort.forApp(plans, today)

    // 所有界面状态都放在这里，不往上层抛。
    var filter by remember { mutableStateOf(PlanFilter.ALL) }
    var editorVisible by remember { mutableStateOf(false) }
    var editingPlan by remember { mutableStateOf<PlanItem?>(null) }
    var form by remember { mutableStateOf(PlanForm()) }
    var deleteTarget by remember { mutableStateOf<PlanItem?>(null) }

    fun openCreate() {
        editingPlan = null
        form = PlanForm()
        editorVisible = true
    }

    fun openEdit(item: PlanItem) {
        editingPlan = item
        form = PlanForm(
            title = item.title,
            type = if (item.isCount) PlanType.COUNT else PlanType.TODO,
            date = item.date,
            target = item.targetSafe.toString()
        )
        editorVisible = true
    }

    val visiblePlans = sortedPlans.filter { item ->
        when (filter) {
            PlanFilter.ALL -> true
            PlanFilter.PENDING -> !item.isCompleted()
            PlanFilter.TODAY -> item.date == today
            PlanFilter.OVERDUE -> item.isOverdue(today)
            PlanFilter.DONE -> item.isCompleted()
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp)
        ) {
            Spacer(Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = "计划",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "待办勾选 / 计数目标 · 统计表实时更新",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                TextButton(onClick = { openCreate() }) {
                    Text("＋ 新建", fontSize = 13.sp)
                }
            }

            if (message != null) {
                Text(
                    text = message,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            Spacer(Modifier.height(10.dp))

            PlanStatsBlock(summary = summary)

            Spacer(Modifier.height(10.dp))

            // 筛选 chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PlanFilter.entries.forEach { option ->
                    FilterChip(
                        selected = filter == option,
                        onClick = { filter = option },
                        label = { Text(option.label, fontSize = 11.sp) }
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(top = 8.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (visiblePlans.isEmpty()) {
                    item {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .padding(top = 34.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = if (plans.isEmpty()) {
                                    "还没有计划，点右下角＋添加"
                                } else {
                                    "当前筛选下没有计划"
                                },
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (plans.isEmpty()) {
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = "待办：点一下勾选完成。计数：每点一次 +1，累计到目标次数。",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    items(visiblePlans) { item ->
                        PlanCard(
                            item = item,
                            today = today,
                            onToggle = { onToggle(item.id) },
                            onDecrement = { onDecrement(item.id) },
                            onEdit = { openEdit(item) },
                            onDeleteRequest = { deleteTarget = item }
                        )
                    }
                    item {
                        Text(
                            text = "点计划卡片可以编辑；完成率 = 已完成计划 / 总计划。",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 2.dp, start = 2.dp)
                        )
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { openCreate() },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
        ) {
            Text("＋", fontSize = 26.sp)
        }
    }

    if (editorVisible) {
        PlanEditDialog(
            editing = editingPlan,
            form = form,
            onFormChange = { form = it },
            onDismiss = { editorVisible = false },
            onDeleteRequest = {
                val target = editingPlan
                editorVisible = false
                if (target != null) {
                    deleteTarget = target
                }
            },
            onConfirm = {
                val target = if (form.type == PlanType.COUNT) {
                    PlanText.parseTarget(form.target) ?: 1
                } else {
                    1
                }
                val existing = editingPlan
                val item = if (existing == null) {
                    PlanEditor.create(
                        title = form.title,
                        type = form.type,
                        date = form.date,
                        target = target
                    )
                } else {
                    existing.copy(
                        title = form.title.trim(),
                        type = form.type,
                        date = PlanText.normalizeDate(form.date),
                        target = target,
                        updatedAt = System.currentTimeMillis()
                    )
                }
                editorVisible = false
                onSave(item)
            }
        )
    }

    val pendingDelete = deleteTarget
    if (pendingDelete != null) {
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("删除计划", fontSize = 17.sp) },
            text = {
                Text(
                    text = "确定删除「${pendingDelete.title}」吗？删除后无法恢复。",
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        deleteTarget = null
                        onDelete(pendingDelete.id)
                    }
                ) {
                    Text("删除", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text("取消") }
            }
        )
    }
}

/** 顶部「计划统计表」：概览数字 + 待办/计数进度条。 */
@Composable
private fun PlanStatsBlock(summary: PlanSummary) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(16.dp))
            .padding(horizontal = 12.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "计划统计表",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "完成率 ${summary.percent}%",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            StatCell(label = "总计划", value = "${summary.total}", modifier = Modifier.weight(1f))
            StatCell(
                label = "已完成",
                value = "${summary.completed}",
                modifier = Modifier.weight(1f),
                accent = true
            )
            StatCell(label = "进行中", value = "${summary.pending}", modifier = Modifier.weight(1f))
            StatCell(
                label = "已过期",
                value = "${summary.overdue}",
                modifier = Modifier.weight(1f),
                warn = summary.overdue > 0
            )
        }
        Spacer(Modifier.height(10.dp))
        StatProgressRow(
            label = "待办",
            valueText = "${summary.todoDone}/${summary.todoTotal} 完成",
            fraction = (summary.todoPercent / 100f).coerceIn(0f, 1f),
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(4.dp))
        StatProgressRow(
            label = "计数",
            valueText = "累计 ${summary.countDone}/${summary.countTotal}",
            fraction = (summary.countPercent / 100f).coerceIn(0f, 1f),
            color = MaterialTheme.colorScheme.tertiary
        )
    }
}

@Composable
private fun StatCell(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    accent: Boolean = false,
    warn: Boolean = false
) {
    val background = when {
        accent -> MaterialTheme.colorScheme.primaryContainer
        warn -> MaterialTheme.colorScheme.errorContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    val valueColor = when {
        accent -> MaterialTheme.colorScheme.primary
        warn -> MaterialTheme.colorScheme.error
        else -> MaterialTheme.colorScheme.onSurface
    }
    Column(
        modifier = modifier
            .background(background, RoundedCornerShape(10.dp))
            .padding(horizontal = 8.dp, vertical = 7.dp)
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1
        )
        Text(
            text = value,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = valueColor,
            maxLines = 1
        )
    }
}

@Composable
private fun StatProgressRow(
    label: String,
    valueText: String,
    fraction: Float,
    color: Color
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(30.dp)
        )
        LinearProgressIndicator(
            progress = { fraction.coerceIn(0f, 1f) },
            modifier = Modifier
                .weight(1f)
                .height(6.dp),
            color = color,
            trackColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = valueText,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1
        )
    }
}

/** 一条计划卡片：点主体编辑，勾选/±1 打卡，右侧删除（带二次确认）。 */
@Composable
private fun PlanCard(
    item: PlanItem,
    today: String,
    onToggle: () -> Unit,
    onDecrement: () -> Unit,
    onEdit: () -> Unit,
    onDeleteRequest: () -> Unit
) {
    val completed = item.isCompleted()
    val overdue = item.isOverdue(today)
    val titleColor = when {
        overdue -> MaterialTheme.colorScheme.error
        completed -> MaterialTheme.colorScheme.onSurfaceVariant
        else -> MaterialTheme.colorScheme.onSurface
    }
    val statusColor = when {
        overdue -> MaterialTheme.colorScheme.error
        completed -> MaterialTheme.colorScheme.onSurfaceVariant
        else -> MaterialTheme.colorScheme.primary
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(16.dp))
            .clickable { onEdit() }
            .padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (item.isCount) {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "计",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
                Spacer(Modifier.width(8.dp))
            } else {
                Checkbox(checked = item.done, onCheckedChange = { onToggle() })
                Spacer(Modifier.width(2.dp))
            }

            Column(Modifier.weight(1f)) {
                Text(
                    text = item.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = titleColor,
                    textDecoration = if (completed) TextDecoration.LineThrough else null,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(3.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PlanTag(
                        text = if (item.isCount) "计数" else "待办",
                        highlight = item.isCount
                    )
                    PlanTag(text = PlanText.dateLabel(item, today))
                    Text(
                        text = PlanText.statusLabel(item, today),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        color = statusColor,
                        maxLines = 1
                    )
                }
            }

            TextButton(onClick = onDeleteRequest) {
                Text(
                    text = "删除",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }

        if (item.isCount) {
            Spacer(Modifier.height(2.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(start = 4.dp, end = 8.dp)
            ) {
                LinearProgressIndicator(
                    progress = { item.currentSafe.toFloat() / item.targetSafe.toFloat() },
                    modifier = Modifier
                        .weight(1f)
                        .height(8.dp),
                    color = if (completed) {
                        MaterialTheme.colorScheme.tertiary
                    } else {
                        MaterialTheme.colorScheme.primary
                    },
                    trackColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.9f)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    text = PlanText.progressLabel(item),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (completed) {
                        MaterialTheme.colorScheme.tertiary
                    } else {
                        MaterialTheme.colorScheme.primary
                    },
                    maxLines = 1,
                    modifier = Modifier.width(42.dp)
                )
                StepButton(text = "-1", enabled = item.currentSafe > 0) { onDecrement() }
                Spacer(Modifier.width(4.dp))
                StepButton(text = "+1", primary = true, enabled = !completed) { onToggle() }
            }
        }
    }
}

/** 小标签（类型 / 日期）。 */
@Composable
private fun PlanTag(text: String, highlight: Boolean = false) {
    Text(
        text = text,
        fontSize = 10.sp,
        color = if (highlight) {
            MaterialTheme.colorScheme.onPrimary
        } else {
            MaterialTheme.colorScheme.onSurfaceVariant
        },
        modifier = Modifier
            .background(
                if (highlight) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.surfaceVariant
                },
                RoundedCornerShape(6.dp)
            )
            .padding(horizontal = 6.dp, vertical = 2.dp),
        maxLines = 1
    )
}

/** 类型选择按钮 / 日期快捷按钮共用的圆角小按钮。 */
@Composable
private fun PlanChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text = label,
        fontSize = 11.sp,
        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
        color = if (selected) {
            MaterialTheme.colorScheme.onPrimary
        } else {
            MaterialTheme.colorScheme.onSurfaceVariant
        },
        modifier = Modifier
            .background(
                if (selected) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.surface
                },
                RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 5.dp),
        maxLines = 1
    )
}

/** 计数计划的 -1 / +1 小按钮。 */
@Composable
private fun StepButton(
    text: String,
    primary: Boolean = false,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val background = when {
        !enabled -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        primary -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    val foreground = when {
        !enabled -> MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
        primary -> MaterialTheme.colorScheme.onPrimary
        else -> MaterialTheme.colorScheme.onSurface
    }
    Text(
        text = text,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        color = foreground,
        modifier = Modifier
            .background(background, RoundedCornerShape(8.dp))
            .clickable(enabled = enabled) { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp),
        maxLines = 1
    )
}

/** 新建 / 编辑计划对话框（无状态，表单内容由 PlanContent 持有）。 */
@Composable
private fun PlanEditDialog(
    editing: PlanItem?,
    form: PlanForm,
    onFormChange: (PlanForm) -> Unit,
    onDismiss: () -> Unit,
    onDeleteRequest: () -> Unit,
    onConfirm: () -> Unit
) {
    val countType = form.type == PlanType.COUNT
    val titleValid = form.title.isNotBlank()
    val targetValid = !countType || PlanText.parseTarget(form.target) != null
    val canSave = titleValid && targetValid
    val normalizedDate = PlanText.normalizeDate(form.date)
    val dateInvalid = form.date.isNotBlank() && normalizedDate.isBlank()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (editing == null) "新建计划" else "编辑计划",
                fontSize = 17.sp
            )
        },
        confirmButton = {
            TextButton(onClick = onConfirm, enabled = canSave) { Text("保存") }
        },
        dismissButton = {
            Row {
                if (editing != null) {
                    TextButton(onClick = onDeleteRequest) {
                        Text("删除", color = MaterialTheme.colorScheme.error)
                    }
                }
                TextButton(onClick = onDismiss) { Text("取消") }
            }
        },
        text = {
            Column(
                Modifier
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = form.title,
                    onValueChange = { value -> onFormChange(form.copy(title = value.take(60))) },
                    label = { Text("标题") },
                    placeholder = { Text("例如：交实验报告 / 跑步 30 次") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    text = "类型",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(4.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PlanChip(
                        label = "待办",
                        selected = !countType,
                        onClick = { onFormChange(form.copy(type = PlanType.TODO)) }
                    )
                    PlanChip(
                        label = "计数",
                        selected = countType,
                        onClick = { onFormChange(form.copy(type = PlanType.COUNT)) }
                    )
                    Text(
                        text = if (countType) "每点一次 +1" else "勾选完成",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (countType) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = form.target,
                        onValueChange = { value ->
                            onFormChange(form.copy(target = value.filter { it.isDigit() }.take(3)))
                        },
                        label = { Text("目标次数") },
                        placeholder = { Text("10") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (!targetValid) {
                        Text(
                            text = "目标次数要填大于 0 的数字（最多 999）。",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = form.date,
                    onValueChange = { value -> onFormChange(form.copy(date = value.trim().take(10))) },
                    label = { Text("日期（yyyy-MM-dd，可空）") },
                    placeholder = { Text("留空 = 无日期") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PlanChip(
                        label = "今天",
                        selected = false,
                        onClick = { onFormChange(form.copy(date = PlanText.todayString())) }
                    )
                    PlanChip(
                        label = "明天",
                        selected = false,
                        onClick = {
                            onFormChange(
                                form.copy(date = PlanText.shift(PlanText.todayString(), 1))
                            )
                        }
                    )
                    PlanChip(
                        label = "清除",
                        selected = false,
                        onClick = { onFormChange(form.copy(date = "")) }
                    )
                }
                if (dateInvalid) {
                    Text(
                        text = "日期格式无法识别，保存时会当作「无日期」。",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                if (!titleValid) {
                    Text(
                        text = "先填标题才能保存。",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        }
    )
}

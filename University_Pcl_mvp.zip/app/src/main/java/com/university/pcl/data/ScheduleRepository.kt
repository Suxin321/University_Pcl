package com.university.pcl.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

/** 教务系统课表拉取 + 缓存。 */
class ScheduleRepository(context: Context) {

    private val appContext = context.applicationContext
    private val prefs = Prefs(appContext)
    private val cacheStore = CacheStore(appContext)
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    fun prefs(): Prefs = prefs

    fun cached(): ScheduleCache? = cacheStore.load()

    fun currentWeek(): Int {
        val fromDate = WeekUtil.weekFromStart(prefs.semesterStart)
        return if (fromDate > 0) fromDate else prefs.week.coerceAtLeast(1)
    }

    suspend fun refresh(): Result<ScheduleCache> = withContext(Dispatchers.IO) {
        runCatching {
            if (!prefs.isLoggedIn) throw IOException("请先登录教务系统")
            val week = currentWeek()
            val term = prefs.term.ifBlank { WeekUtil.guessTerm() }
            val base = prefs.baseUrl
            val url = "$base/jsxsd/xskb/xskb_list.do".toHttpUrlOrNull()
                ?: throw IOException("教务系统地址无效：$base")
            val full = url.newBuilder()
                .addQueryParameter("week", week.toString())
                .addQueryParameter("term", term)
                .build()
            val request = Request.Builder()
                .url(full)
                .header("User-Agent", UA)
                .header("Accept", "text/html,application/xhtml+xml")
                .header("Cookie", prefs.cookies)
                .header("Referer", "$base/jsxsd/framework/xsMainV.htmlx")
                .build()
            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (response.code != 200 || body.isBlank()) {
                    throw IOException("请求课表失败（HTTP ${response.code}）")
                }
                if (body.contains("id=\"userAccount\"") || body.contains("欢迎登录教务系统")) {
                    prefs.clearSession()
                    throw IOException("登录已过期，请重新登录")
                }
                // 空课表是合法结果（假期/空周），照常写缓存，不当作失败
                val items = QiangzhiParser.parse(body)
                val cache = ScheduleCache(System.currentTimeMillis(), term, week, items)
                cacheStore.save(cache)
                prefs.term = term
                prefs.lastSync = cache.fetchedAt
                cache
            }
        }
    }

    companion object {
        private const val UA =
            "Mozilla/5.0 (Linux; Android 15; 24117RK2FC) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36"
    }
}

package com.university.pcl.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import org.jsoup.Jsoup
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * 教务系统课表拉取 + 缓存。
 *
 * 不同学校/版本的强智课表参数不同，这里按「多策略」依次尝试，取第一个能解析出课程的响应：
 * 1. GET  ?week=&term=              （同校开源实现用的参数）
 * 2. GET  ?xnxq01id=&zc=            （强智老版参数）
 * 3. GET  课表页 -> 自动提交页面上的表单（最稳：直接用教务页面自己的学期/周次选项）
 * 4. POST ?Ves632DSdyV=NEW_XSD_XKB  + xnxq01id/zc
 * 同时把每次请求的原始 HTML 写到 getExternalFilesDir/debug/ 便于排查。
 */
class ScheduleRepository(context: Context) {

    private val appContext = context.applicationContext
    private val prefs = Prefs(appContext)
    private val cacheStore = CacheStore(appContext)
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    private data class FetchResult(
        val label: String,
        val code: Int,
        val body: String,
        val error: String? = null
    )

    fun prefs(): Prefs = prefs

    fun cached(): ScheduleCache? = cacheStore.load()

    fun currentWeek(): Int {
        val fromDate = WeekUtil.weekFromStart(prefs.semesterStart)
        return if (fromDate > 0) fromDate else prefs.week.coerceAtLeast(1)
    }

    /** 把用户选中的 .xls 课表复制到应用数据目录并解析。 */
    suspend fun importXls(uri: Uri): Result<ScheduleCache> = withContext(Dispatchers.IO) {
        runCatching {
            val target = File(appContext.filesDir, "imported_timetable.xls")
            appContext.contentResolver.openInputStream(uri)?.use { input ->
                target.outputStream().use { output -> input.copyTo(output) }
            } ?: throw IOException("无法读取所选文件")

            val parsed = XlsTimetableParser.parse(target)
            if (parsed.slots.isEmpty()) throw IOException("文件里没有解析到课程，确认是教务系统导出的课表 .xls")

            val term = parsed.term ?: prefs.term.ifBlank { WeekUtil.guessTerm() }
            val cache = ScheduleCache(System.currentTimeMillis(), term, currentWeek(), parsed.slots)
            cacheStore.save(cache)
            prefs.term = term
            prefs.lastSync = cache.fetchedAt
            cache
        }
    }

    fun importedFile(): File = File(appContext.filesDir, "imported_timetable.xls")

    suspend fun refresh(): Result<ScheduleCache> = withContext(Dispatchers.IO) {
        runCatching {
            if (!prefs.isLoggedIn) throw IOException("请先登录教务系统")
            val base = prefs.baseUrl
            val term = prefs.term.ifBlank { WeekUtil.guessTerm() }
            val week = currentWeek()
            val listUrl = "$base/jsxsd/xskb/xskb_list.do".toHttpUrlOrNull()
                ?: throw IOException("教务系统地址无效：$base")

            val results = ArrayList<FetchResult>()
            results += fetch(listUrl.newBuilder().addQueryParameter("week", week.toString())
                .addQueryParameter("term", term).build(), null)
            results += fetch(listUrl.newBuilder().addQueryParameter("xnxq01id", term)
                .addQueryParameter("zc", week.toString()).build(), null)

            val plainPage = fetch(listUrl.newBuilder().addQueryParameter("Ves632DSdyV", "NEW_XSD_XKB").build(), null)
            results += plainPage
            if (plainPage.error == null && plainPage.body.isNotBlank()) {
                submitPageForm(base, plainPage.body)?.let { results += it }
            }
            results += fetch(listUrl.newBuilder().addQueryParameter("Ves632DSdyV", "NEW_XSD_XKB").build(),
                FormBody.Builder().add("xnxq01id", term).add("zc", week.toString()).build())

            var items: List<CourseSlot> = emptyList()
            var usedHtml = ""
            for (r in results) {
                if (r.error != null || r.body.isBlank() || isLoginPage(r.body)) continue
                val parsed = QiangzhiParser.parse(r.body)
                if (parsed.isNotEmpty()) {
                    items = parsed
                    usedHtml = r.body
                    break
                }
            }

            dumpDebug(term, week, results, usedHtml)

            if (items.isEmpty()) {
                val diag = results.joinToString("；") { r ->
                    val state = r.error ?: "HTTP ${r.code}, 课程格=${countCourseCells(r.body)}"
                    "${r.label}: $state"
                }
                throw IOException("课表为空（学期=$term，周次=$week）。$diag")
            }

            val actualWeek = detectSelectedWeek(usedHtml) ?: week
            val cache = ScheduleCache(System.currentTimeMillis(), term, actualWeek, items)
            cacheStore.save(cache)
            prefs.term = term
            prefs.lastSync = cache.fetchedAt
            cache
        }
    }

    private fun fetch(url: HttpUrl, form: FormBody?): FetchResult {
        val label = if (form == null) "GET ${url.encodedQuery.orEmpty()}" else "POST ${url.encodedQuery.orEmpty()}"
        val builder = Request.Builder()
            .url(url)
            .header("User-Agent", UA)
            .header("Accept", "text/html,application/xhtml+xml")
            .header("Cookie", prefs.cookies)
            .header("Referer", "${prefs.baseUrl}/jsxsd/framework/xsMainV.htmlx")
        if (form != null) builder.post(form) else builder.get()
        return try {
            client.newCall(builder.build()).execute().use { response ->
                FetchResult(label, response.code, response.body?.string().orEmpty())
            }
        } catch (e: Exception) {
            FetchResult(label, 0, "", e.message ?: e.javaClass.simpleName)
        }
    }

    /** 用课表页面自己的表单（学期/周次下拉的当前选中项）原样提交一次。 */
    private fun submitPageForm(base: String, html: String): FetchResult? {
        return runCatching {
            val doc = Jsoup.parse(html)
            val form = doc.selectFirst("form") ?: return null
            val action = form.attr("action").ifBlank { "/jsxsd/xskb/xskb_list.do" }
            val actionUrl = "$base/jsxsd/".toHttpUrlOrNull()?.resolve(action) ?: return null
            val body = FormBody.Builder()
            form.select("input[name]").forEach { input ->
                val type = input.attr("type").lowercase()
                if (type != "button" && type != "submit" && type != "reset") {
                    body.add(input.attr("name"), input.attr("value"))
                }
            }
            form.select("select[name]").forEach { select ->
                val option = select.select("option[selected]").firstOrNull()
                    ?: select.select("option").firstOrNull()
                if (option != null) body.add(select.attr("name"), option.attr("value"))
            }
            fetch(actionUrl, body.build())
        }.getOrNull()
    }

    private fun isLoginPage(html: String): Boolean =
        html.contains("id=\"userAccount\"") || html.contains("欢迎登录教务系统")

    private fun countCourseCells(html: String): Int =
        runCatching { Jsoup.parse(html).select("div.kbcontent").size }.getOrDefault(0)

    private fun detectSelectedWeek(html: String): Int? = runCatching {
        val doc = Jsoup.parse(html)
        doc.select("select[name=zc] option[selected]").firstOrNull()?.attr("value")?.toIntOrNull()
    }.getOrNull()

    private fun dumpDebug(term: String, week: Int, results: List<FetchResult>, usedHtml: String) {
        runCatching {
            val dir = File(appContext.getExternalFilesDir(null) ?: appContext.filesDir, "debug")
            dir.mkdirs()
            File(dir, "info.txt").writeText(
                buildString {
                    appendLine("term=$term requestedWeek=$week")
                    results.forEachIndexed { i, r ->
                        appendLine("[$i] ${r.label} code=${r.code} len=${r.body.length} err=${r.error}")
                        File(dir, "attempt_$i.html").writeText(r.body)
                    }
                }
            )
            File(dir, "schedule_used.html").writeText(usedHtml)
        }
    }

    companion object {
        private const val UA =
            "Mozilla/5.0 (Linux; Android 15; 24117RK2FC) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36"
    }
}

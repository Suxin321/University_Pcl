package com.university.pcl.data

import java.net.URLEncoder

/**
 * 浏览器地址栏的 URL / 搜索词处理（纯 Kotlin，不依赖 Android，方便单测）。
 * - 「像网址」的输入直接打开，其余内容交给搜索引擎；
 * - 所有方法都对空串 / 非法输入兜底，不抛异常。
 */
object BrowserUrls {
    const val ENGINE_YANDEX = "Yandex"
    const val ENGINE_UC = "UC"
    const val ENGINE_QUARK = "夸克"

    const val ENGINE_BAIDU = "百度"
    const val ENGINE_BING = "Bing"
    const val ENGINE_GOOGLE = "Google"
    const val ENGINE_DUCKDUCKGO = "DuckDuckGo"

    /** 默认搜索引擎（设置里可随时改）。 */
    const val DEFAULT_ENGINE = ENGINE_YANDEX

    /** 设置页可选的搜索引擎顺序（默认的排前面）。 */
    val engines: List<String> = listOf(
        ENGINE_YANDEX,
        ENGINE_UC,
        ENGINE_QUARK,
        ENGINE_BAIDU,
        ENGINE_BING,
        ENGINE_GOOGLE,
        ENGINE_DUCKDUCKGO
    )

    /** 「像网址」的判定：可带 http(s)://，域名至少有一个点，路径里不能有空白。 */
    private val URL_LIKE = Regex("""^(https?://)?[A-Za-z0-9\-]+(\.[A-Za-z0-9\-]+)+(/\S*)?$""")

    /** 是否像网址：trim 后非空、不含空白且匹配 URL 形态。 */
    fun isUrlLike(input: String): Boolean {
        val text = input.trim()
        if (text.isEmpty() || text.any { it.isWhitespace() }) return false
        return URL_LIKE.matches(text)
    }

    /** 地址栏输入归一化：空串 → ""；已带 http(s):// 原样返回；像网址补 https://；否则搜索。 */
    fun normalizeInput(input: String, engine: String = ENGINE_BAIDU): String {
        val text = input.trim()
        if (text.isEmpty()) return ""
        if (text.startsWith("http://", ignoreCase = true) || text.startsWith("https://", ignoreCase = true)) {
            return text
        }
        return if (isUrlLike(text)) "https://$text" else searchUrl(engine, text)
    }

    /** 按搜索引擎拼搜索 URL；query 用 UTF-8 编码，未知引擎回退百度。 */
    fun searchUrl(engine: String, query: String): String {
        val encoded = runCatching { URLEncoder.encode(query, "UTF-8") }.getOrDefault(query)
        val base = when (engine.trim()) {
            ENGINE_YANDEX -> "https://yandex.com/search/?text="
            ENGINE_UC -> "https://m.sm.cn/s?q="
            ENGINE_QUARK -> "https://quark.sm.cn/s?q="
            ENGINE_BING -> "https://www.bing.com/search?q="
            ENGINE_GOOGLE -> "https://www.google.com/search?q="
            ENGINE_DUCKDUCKGO -> "https://duckduckgo.com/?q="
            else -> "https://www.baidu.com/s?wd="
        }
        return base + encoded
    }

    /** 界面上显示的简短地址：去掉 http(s):// 与末尾 /；结果为空则返回原串。 */
    fun displayUrl(url: String): String {
        val stripped = stripScheme(url.trim()).trimEnd('/')
        return stripped.ifEmpty { url }
    }

    /** 取主机名：去 scheme → 去 / ? # 之后 → 去端口 → 小写；空返回 ""。 */
    fun hostOf(url: String): String {
        val text = stripScheme(url.trim())
        if (text.isEmpty()) return ""
        val cut = text.indexOfFirst { it == '/' || it == '?' || it == '#' }
        var host = if (cut >= 0) text.substring(0, cut) else text
        // 端口：仅当最后一个冒号后全是数字时截掉（避免误伤 IPv6 等写法）
        val colon = host.lastIndexOf(':')
        if (colon > 0) {
            val port = host.substring(colon + 1)
            if (port.isNotEmpty() && port.all { it.isDigit() }) host = host.substring(0, colon)
        }
        return host.lowercase()
    }

    /** 标签页 / 书签图标用的首字母：去掉 www. 后取首字符大写，空返回「·」。 */
    fun labelOf(url: String): String {
        val host = hostOf(url).removePrefix("www.")
        if (host.isEmpty()) return "·"
        return host.first().uppercase()
    }

    /** 去掉开头的 http:// 或 https://（大小写不敏感）。 */
    private fun stripScheme(text: String): String = when {
        text.startsWith("http://", ignoreCase = true) -> text.substring(7)
        text.startsWith("https://", ignoreCase = true) -> text.substring(8)
        else -> text
    }
}

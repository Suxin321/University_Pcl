package com.university.pcl.data

import android.content.Context
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import java.io.File

/** 手动加课的本地存储（JSON，与导入/在线课表分开保存）。 */
class ManualCourseStore(context: Context) {

    private val file = File(context.applicationContext.filesDir, "manual_courses.json")
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val serializer = ListSerializer(ManualCourse.serializer())

    fun load(): List<ManualCourse> = runCatching {
        if (!file.exists()) return emptyList()
        json.decodeFromString(serializer, file.readText())
    }.getOrDefault(emptyList())

    fun save(courses: List<ManualCourse>) {
        runCatching { file.writeText(json.encodeToString(serializer, courses)) }
    }
}

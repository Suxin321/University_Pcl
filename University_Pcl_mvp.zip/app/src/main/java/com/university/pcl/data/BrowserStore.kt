package com.university.pcl.data

import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

/** 书签文件的 JSON 结构（私有包装便于以后加字段，私有声明只在当前文件可见，所以和 Store 放同一文件）。 */
@Serializable
private data class BrowserBookmarkFile(val items: List<BrowserBookmark> = emptyList())

/** 历史文件的 JSON 结构。 */
@Serializable
private data class BrowserHistoryFile(val items: List<BrowserHistoryEntry> = emptyList())

/** 下载记录的 JSON 结构。 */
@Serializable
private data class BrowserDownloadFile(val items: List<BrowserDownloadEntry> = emptyList())

/**
 * 「浏览器」的本地存储（JSON 文件，纯离线，不联网）。
 * 书签 / 历史 / 下载 / 设置各一个文件；所有读写都用 runCatching 兜底，坏文件按空处理。
 * 主构造器接收目录（单测用临时目录），次构造器按 App 的 filesDir 创建。
 */
class BrowserStore(private val dir: File) {

    constructor(context: Context) : this(File(context.filesDir, "browser"))

    private val bookmarksFile = File(dir, "bookmarks.json")
    private val historyFile = File(dir, "history.json")
    private val downloadsFile = File(dir, "downloads.json")
    private val settingsFile = File(dir, "settings.json")
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun loadBookmarks(): List<BrowserBookmark> {
        if (!bookmarksFile.exists()) return emptyList()
        return runCatching {
            json.decodeFromString(BrowserBookmarkFile.serializer(), bookmarksFile.readText()).items
                .filter { it.url.isNotBlank() }
        }.getOrDefault(emptyList())
    }

    fun saveBookmarks(items: List<BrowserBookmark>) {
        runCatching {
            dir.mkdirs()
            val cleaned = items.filter { it.url.isNotBlank() }
            bookmarksFile.writeText(
                json.encodeToString(BrowserBookmarkFile.serializer(), BrowserBookmarkFile(cleaned))
            )
        }
    }

    /** 浏览历史，最新在前（存储顺序就是显示顺序）。 */
    fun loadHistory(): List<BrowserHistoryEntry> {
        if (!historyFile.exists()) return emptyList()
        return runCatching {
            json.decodeFromString(BrowserHistoryFile.serializer(), historyFile.readText()).items
                .filter { it.url.isNotBlank() }
        }.getOrDefault(emptyList())
    }

    /** 新增一条历史：同 url 先去重，插到队首，最多保留 [MAX_HISTORY] 条。 */
    fun addHistory(entry: BrowserHistoryEntry) {
        val updated = (listOf(entry) + loadHistory().filterNot { it.url == entry.url }).take(MAX_HISTORY)
        saveHistory(updated)
    }

    fun clearHistory() {
        saveHistory(emptyList())
    }

    fun loadDownloads(): List<BrowserDownloadEntry> {
        if (!downloadsFile.exists()) return emptyList()
        return runCatching {
            json.decodeFromString(BrowserDownloadFile.serializer(), downloadsFile.readText()).items
        }.getOrDefault(emptyList())
    }

    /** 新增一条下载记录：插到队首，最多保留 [MAX_DOWNLOADS] 条。 */
    fun addDownload(entry: BrowserDownloadEntry) {
        val updated = (listOf(entry) + loadDownloads()).take(MAX_DOWNLOADS)
        saveDownloads(updated)
    }

    fun clearDownloads() {
        saveDownloads(emptyList())
    }

    /** 读取设置；文件不存在或解析失败返回默认设置。 */
    fun loadSettings(): BrowserSettings {
        if (!settingsFile.exists()) return BrowserSettings()
        return runCatching {
            json.decodeFromString(BrowserSettings.serializer(), settingsFile.readText())
        }.getOrDefault(BrowserSettings())
    }

    fun saveSettings(settings: BrowserSettings) {
        runCatching {
            dir.mkdirs()
            settingsFile.writeText(json.encodeToString(BrowserSettings.serializer(), settings))
        }
    }

    /** 清空浏览器数据：删除书签 / 历史 / 下载 / 设置 4 个文件。 */
    fun clearAll() {
        runCatching {
            bookmarksFile.delete()
            historyFile.delete()
            downloadsFile.delete()
            settingsFile.delete()
        }
    }

    private fun saveHistory(items: List<BrowserHistoryEntry>) {
        runCatching {
            dir.mkdirs()
            val cleaned = items.filter { it.url.isNotBlank() }.take(MAX_HISTORY)
            historyFile.writeText(
                json.encodeToString(BrowserHistoryFile.serializer(), BrowserHistoryFile(cleaned))
            )
        }
    }

    private fun saveDownloads(items: List<BrowserDownloadEntry>) {
        runCatching {
            dir.mkdirs()
            downloadsFile.writeText(
                json.encodeToString(BrowserDownloadFile.serializer(), BrowserDownloadFile(items.take(MAX_DOWNLOADS)))
            )
        }
    }

    companion object {
        /** 历史最多保留的条数。 */
        const val MAX_HISTORY = 500

        /** 下载记录最多保留的条数。 */
        const val MAX_DOWNLOADS = 100

        /** 新建书签 / 下载记录用的唯一 id。 */
        fun newId(): String = UUID.randomUUID().toString()
    }
}

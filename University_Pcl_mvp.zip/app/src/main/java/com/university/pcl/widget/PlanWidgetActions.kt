package com.university.pcl.widget

import android.content.Context
import android.content.Intent
import androidx.glance.GlanceId
import androidx.glance.action.ActionParameters
import androidx.glance.appwidget.action.ActionCallback
import com.university.pcl.data.PlanEditor
import com.university.pcl.data.PlanStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * 桌面组件动作共用的参数 key、SharedPreferences 名称与「打开编辑弹窗」的 Intent 构造。
 *
 * 注意：ActionCallback 由 Glance 用反射 newInstance 创建，所以每个回调类都必须是
 * public class 且有无参公开构造函数（不能是 object / internal / 带参构造）。
 */
object PlanWidgetKeys {

    /** 组件上被操作的那条计划的 id。 */
    val planIdKey: ActionParameters.Key<String> = ActionParameters.Key("plan_id")

    /** 手动刷新时间存放的 SharedPreferences 文件与 key。 */
    const val PREFS_NAME = "university_pcl_widget"
    const val KEY_LAST_REFRESH = "last_refresh"
}

/** 待办：勾选 / 取消完成。 */
class TodoToggleAction : ActionCallback {
    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: ActionParameters
    ) {
        val planId = parameters[PlanWidgetKeys.planIdKey] ?: return
        withContext(Dispatchers.IO) {
            PlanStore(context).mutate { items -> PlanEditor.toggleTodo(items, planId) }
        }
        refreshWidget(context, glanceId)
    }
}

/** 计数：+1（到目标后不再增加）。 */
class PlanIncrementAction : ActionCallback {
    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: ActionParameters
    ) {
        val planId = parameters[PlanWidgetKeys.planIdKey] ?: return
        withContext(Dispatchers.IO) {
            PlanStore(context).mutate { items -> PlanEditor.increment(items, planId) }
        }
        refreshWidget(context, glanceId)
    }
}

/** 手动刷新：记下刷新时间（组件头部显示「更新 HH:mm」）后重绘组件。 */
class WidgetRefreshAction : ActionCallback {
    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: ActionParameters
    ) {
        withContext(Dispatchers.IO) {
            context.applicationContext
                .getSharedPreferences(PlanWidgetKeys.PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putLong(PlanWidgetKeys.KEY_LAST_REFRESH, System.currentTimeMillis())
                .apply()
        }
        refreshWidget(context, glanceId)
    }
}

/**
 * 只重绘「点了按钮的这一个」组件实例：比 updateAll 快，点 ↻ / 勾选 / +1 后立刻能看到变化。
 * 失败（比如组件刚被删）再回退到全量刷新。
 */
private suspend fun refreshWidget(context: Context, glanceId: GlanceId) {
    try {
        ScheduleWidget().update(context.applicationContext, glanceId)
    } catch (e: Exception) {
        WidgetUpdater.update(context)
    }
}

/**
 * 组件拉起计划编辑弹窗的 Intent。
 *
 * @param planId 为空表示新建（add），非空表示编辑（edit）。
 * 组件里是用 PendingIntent 启动 Activity，所以带上 FLAG_ACTIVITY_NEW_TASK。
 */
fun planEditIntent(context: Context, planId: String?): Intent {
    val editing = !planId.isNullOrBlank()
    return Intent(context, PlanEditActivity::class.java)
        .putExtra(
            PlanEditActivity.EXTRA_MODE,
            if (editing) PlanEditActivity.MODE_EDIT else PlanEditActivity.MODE_ADD
        )
        .putExtra(PlanEditActivity.EXTRA_PLAN_ID, planId.orEmpty())
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}

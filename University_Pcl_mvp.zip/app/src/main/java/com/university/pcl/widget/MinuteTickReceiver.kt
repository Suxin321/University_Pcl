package com.university.pcl.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * 每分钟的自动刷新（AlarmManager，inexact 闹钟）：
 * - 屏幕亮着时约每分钟刷一次，数据基本“实时”；
 * - 息屏/Doze 时系统会把闹钟延后（不耗电），解锁后补发 → 也起到「亮屏就刷新」的效果。
 * 没有组件实例时自动停掉闹钟，避免白耗电。
 */
class MinuteTickReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val appContext = context.applicationContext
        val manager = AppWidgetManager.getInstance(appContext)
        val ids = runCatching {
            manager.getAppWidgetIds(
                ComponentName(appContext, ScheduleWidgetReceiver::class.java)
            )
        }.getOrDefault(IntArray(0))

        if (ids.isEmpty()) {
            // 桌面上已经没有这个组件了，停止闹钟
            WidgetRefreshScheduler.cancelMinuteTick(appContext)
            return
        }

        val result = goAsync()
        CoroutineScope(Dispatchers.Default).launch {
            try {
                WidgetUpdater.update(appContext)
            } finally {
                result.finish()
            }
        }
    }
}

/** 给 [WidgetRefreshScheduler] 用的闹钟工具（放在这里避免调度类依赖 Receiver）。 */
internal object MinuteTickAlarm {

    const val ACTION = "com.university.pcl.widget.MINUTE_TICK"
    private const val REQUEST_CODE = 4101

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, MinuteTickReceiver::class.java).setAction(ACTION)
        return PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(context: Context) {
        val appContext = context.applicationContext
        val alarmManager = appContext.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
            ?: return
        runCatching {
            alarmManager.setInexactRepeating(
                AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + 60_000L,
                60_000L,
                pendingIntent(appContext)
            )
        }
    }

    fun cancel(context: Context) {
        val appContext = context.applicationContext
        val alarmManager = appContext.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
            ?: return
        runCatching { alarmManager.cancel(pendingIntent(appContext)) }
    }
}

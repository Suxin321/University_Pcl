package com.university.pcl.data

/**
 * 手动增删/修改空课表里的成员及其空课时段。
 * 每个「星期 × 大节」的没课周次可以各不相同，和真实空课表一致。
 */
object FreeTableEditor {

    /** 某个时段的没课情况：allWeeks = 所有周都没课；否则是 weeks 这些周没课。 */
    data class SlotWeeks(val allWeeks: Boolean, val weeks: List<Int>)

    /** 设置成员的各个时段（不在 slots 里的时段会被移除；成员不存在则新增）。 */
    fun setMemberSlots(
        table: FreeTimetable,
        name: String,
        slots: Map<Pair<Int, Int>, SlotWeeks>
    ): FreeTimetable {
        val clean = name.trim()
        if (clean.isEmpty()) return table
        val existingKeys = table.cells.map { it.day to it.bigSection }.toSet()
        val working = table.cells.toMutableList()
        // 空课表里没有的「星期 × 大节」（比如周六日）按需补一个空单元格
        slots.keys.filter { it !in existingKeys }.forEach { key ->
            working.add(FreeCell(day = key.first, bigSection = key.second, members = emptyList()))
        }
        val cells = working.map { cell ->
            val key = cell.day to cell.bigSection
            val others = cell.members.filter { it.name != clean }
            val slot = slots[key]
            if (slot != null) {
                cell.copy(
                    members = others + MemberFree(
                        name = clean,
                        allWeeks = slot.allWeeks,
                        weeks = slot.weeks.distinct().sorted()
                    )
                )
            } else {
                cell.copy(members = others)
            }
        }
        val members = if (table.members.contains(clean)) table.members else table.members + clean
        val days = (table.days + slots.keys.map { it.first }).distinct().sorted()
        return table.copy(cells = cells, members = members, days = days)
    }

    /** 删除成员（所有时段的记录一起删）。 */
    fun removeMember(table: FreeTimetable, name: String): FreeTimetable {
        val clean = name.trim()
        val cells = table.cells.map { cell ->
            if (cell.members.any { it.name == clean }) {
                cell.copy(members = cell.members.filter { it.name != clean })
            } else {
                cell
            }
        }
        return table.copy(cells = cells, members = table.members.filter { it != clean })
    }

    /** 某个成员目前有空的时段（星期 to 大节）。 */
    fun slotsOf(table: FreeTimetable, name: String): Set<Pair<Int, Int>> =
        table.cells.filter { cell -> cell.members.any { it.name == name } }
            .map { it.day to it.bigSection }
            .toSet()

    /** 某个成员在某个时段的没课周次文本（所有周返回空串）。 */
    fun weeksTextOfSlot(table: FreeTimetable, name: String, day: Int, bigSection: Int): String {
        val member = table.cells
            .firstOrNull { it.day == day && it.bigSection == bigSection }
            ?.members
            ?.firstOrNull { it.name == name }
            ?: return ""
        if (member.allWeeks) return ""
        return weeksText(member.weeks)
    }

    /** 把周次列表压成「1-8 13-20」样式。 */
    fun weeksText(weeks: List<Int>): String {
        val sorted = weeks.distinct().sorted()
        if (sorted.isEmpty()) return ""
        val parts = ArrayList<String>()
        var start = sorted.first()
        var prev = start
        for (week in sorted.drop(1)) {
            if (week == prev + 1) {
                prev = week
                continue
            }
            parts.add(if (start == prev) "$start" else "$start-$prev")
            start = week
            prev = week
        }
        parts.add(if (start == prev) "$start" else "$start-$prev")
        return parts.joinToString(" ")
    }
}

package com.university.pcl.data

/**
 * 手动增删/修改空课表里的成员及其空课时段。
 * 空课表按「星期 × 大节」存每个成员没课的周次；这里做的就是把某个人的这些记录改掉。
 */
object FreeTableEditor {

    /** 新增成员：只在 slots（星期 to 大节）里按 weeks 算作有空。 */
    fun addMember(
        table: FreeTimetable,
        name: String,
        allWeeks: Boolean,
        weeks: List<Int>,
        slots: Set<Pair<Int, Int>>
    ): FreeTimetable {
        val clean = name.trim()
        if (clean.isEmpty()) return table
        val member = MemberFree(name = clean, allWeeks = allWeeks, weeks = weeks.distinct().sorted())
        val cells = table.cells.map { cell ->
            val key = cell.day to cell.bigSection
            val others = cell.members.filter { it.name != clean }
            if (key in slots) cell.copy(members = others + member) else cell.copy(members = others)
        }
        val members = if (table.members.contains(clean)) table.members else table.members + clean
        return table.copy(cells = cells, members = members)
    }

    /** 修改已有成员的周次与空课时段。 */
    fun updateMember(
        table: FreeTimetable,
        name: String,
        allWeeks: Boolean,
        weeks: List<Int>,
        slots: Set<Pair<Int, Int>>
    ): FreeTimetable {
        if (name.trim().isEmpty()) return table
        return addMember(table, name, allWeeks, weeks, slots)
    }

    /** 删除成员（所有时段的记录一起删）。 */
    fun removeMember(table: FreeTimetable, name: String): FreeTimetable {
        val clean = name.trim()
        val cells = table.cells.map { cell ->
            if (cell.members.any { it.name == clean }) {
                cell.copy(members = cell.members.filter { it.name != clean })
            } else {
                cell
            }
        }
        return table.copy(cells = cells, members = table.members.filter { it != clean })
    }

    /** 某个成员目前有空的时段（星期 to 大节）。 */
    fun slotsOf(table: FreeTimetable, name: String): Set<Pair<Int, Int>> =
        table.cells.filter { cell -> cell.members.any { it.name == name } }
            .map { it.day to it.bigSection }
            .toSet()

    /** 某个成员目前的周次文本（用于编辑框回填，如 "1-8 13-20"；所有周返回空串）。 */
    fun weeksTextOf(table: FreeTimetable, name: String): String {
        val weeks = sortedSetOf<Int>()
        var allWeeks = false
        table.cells.forEach { cell ->
            cell.members.firstOrNull { it.name == name }?.let { member ->
                if (member.allWeeks) allWeeks = true
                weeks.addAll(member.weeks)
            }
        }
        if (allWeeks || weeks.isEmpty()) return ""
        val parts = ArrayList<String>()
        var start = weeks.first()
        var prev = start
        for (week in weeks.drop(1)) {
            if (week == prev + 1) {
                prev = week
                continue
            }
            parts.add(if (start == prev) "$start" else "$start-$prev")
            start = week
            prev = week
        }
        parts.add(if (start == prev) "$start" else "$start-$prev")
        return parts.joinToString(" ")
    }
}

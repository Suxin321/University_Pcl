package com.university.pcl.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsContent(
    initialUrl: String,
    initialTerm: String,
    initialWeek: Int,
    initialStart: String,
    initialTheoryUrl: String,
    loggedIn: Boolean,
    onSave: (url: String, term: String, week: Int, semesterStart: String, theoryUrl: String) -> Unit,
    onLogin: () -> Unit,
    onImport: () -> Unit,
    onAutoExport: () -> Unit,
    onLogout: () -> Unit,
    modifier: Modifier = Modifier
) {
    var url by remember(initialUrl) { mutableStateOf(initialUrl) }
    var term by remember(initialTerm) { mutableStateOf(initialTerm) }
    var weekText by remember(initialWeek) {
        mutableStateOf(if (initialWeek > 0) initialWeek.toString() else "")
    }
    var start by remember(initialStart) { mutableStateOf(initialStart) }
    var theoryUrl by remember(initialTheoryUrl) { mutableStateOf(initialTheoryUrl) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text(
            text = "设置",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            label = { Text("教务系统地址") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(12.dp))

        Row(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = term,
                onValueChange = { term = it },
                label = { Text("学期") },
                placeholder = { Text("2026-2027-1") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(12.dp))
            OutlinedTextField(
                value = weekText,
                onValueChange = { input -> weekText = input.filter { it.isDigit() }.take(2) },
                label = { Text("周次") },
                placeholder = { Text("留空自动") },
                singleLine = true,
                modifier = Modifier.width(110.dp)
            )
        }
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = start,
            onValueChange = { start = it },
            label = { Text("第 1 周周一日期（可选）") },
            placeholder = { Text("2026-09-07") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = "填了开学日期就按它自动算；不填时按内置校历近似（如 2026-2027-1 从 2026-08-31 起）。周次手动填了则优先用手动值。",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = theoryUrl,
            onValueChange = { theoryUrl = it },
            label = { Text("学期理论课表页面地址（可选）") },
            placeholder = { Text("从浏览器地址栏复制") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(18.dp))
        Text(
            text = "课表来源",
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onImport) {
            Text("导入课表文件（.xls）")
        }
        Text(
            text = "在教务系统课表页右上角点「导出」，把下载的 .xls 文件选进来即可（离线、最稳，推荐）。",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 6.dp)
        )

        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onAutoExport) {
            Text("自动获取课表（先登录 + 点一次导出）")
        }
        Text(
            text = "打开课表页后 App 会自动点「导出」并解析；成功后「刷新」就能直接自动下载，不用再打开网页。",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 6.dp)
        )

        Spacer(Modifier.height(18.dp))
        Row {
            Button(onClick = {
                onSave(url, term, weekText.toIntOrNull() ?: 0, start, theoryUrl)
            }) { Text("保存") }
            Spacer(Modifier.width(12.dp))
            OutlinedButton(onClick = onLogin) {
                Text(if (loggedIn) "重新登录" else "登录教务系统")
            }
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onLogout, enabled = loggedIn) {
            Text("清除登录状态")
        }

        Spacer(Modifier.height(24.dp))
        Text(
            text = "关于",
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "University_Pcl 1.0.0 · MVP\n" +
                "仅在本机读取山东科技大学强智教务系统课表，登录信息只保存在本机，不会上传。\n" +
                "桌面组件在「添加小部件 → 搜索 安卓小部件」里可找到。\n" +
                "字体说明：界面使用系统字体；后续如引入 MiSans，将在此处按官方要求署名。",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

package com.university.pcl.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.university.pcl.data.BigSections
import com.university.pcl.data.FreeTimetable
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SettingsContent(
    initialTerm: String,
    initialWeek: Int,
    initialStart: String,
    freeTimetable: FreeTimetable?,
    rosterLoading: Boolean,
    slotTimes: List<String>,
    onSave: (term: String, week: Int, semesterStart: String) -> Unit,
    onImport: () -> Unit,
    onImportRoster: () -> Unit,
    onSaveSlotTimes: (List<String>) -> Unit,
    modifier: Modifier = Modifier
) {
    var term by remember(initialTerm) { mutableStateOf(initialTerm) }
    var weekText by remember(initialWeek) {
        mutableStateOf(if (initialWeek > 0) initialWeek.toString() else "")
    }
    var start by remember(initialStart) { mutableStateOf(initialStart) }
    var startTimes by remember(slotTimes) {
        mutableStateOf(slotTimes.map { it.substringBefore("-") })
    }
    var endTimes by remember(slotTimes) {
        mutableStateOf(slotTimes.map { it.substringAfter("-", "") })
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text(
            text = "设置",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(16.dp))

        Row(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = term,
                onValueChange = { term = it },
                label = { Text("学期") },
                placeholder = { Text("2026-2027-1") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(12.dp))
            OutlinedTextField(
                value = weekText,
                onValueChange = { input -> weekText = input.filter { it.isDigit() }.take(2) },
                label = { Text("周次") },
                placeholder = { Text("自动") },
                singleLine = true,
                modifier = Modifier.width(110.dp)
            )
        }
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = start,
            onValueChange = { start = it },
            label = { Text("第 1 周周一日期（可选）") },
            placeholder = { Text("2026-08-31") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = "不填开学日期时按内置校历近似推算（2026-2027-1 从 2026-08-31 起）；手动填了周次则优先用手动值。",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(18.dp))
        Text(
            text = "课表来源",
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onImport) {
            Text("导入课表文件（.xls）")
        }
        Text(
            text = "教务系统 → 课表页 → 右上角「导出」下载 .xls，然后在这里选进来。完全离线，不需要登录。",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 6.dp)
        )

        Spacer(Modifier.height(22.dp))
        Text(
            text = "排班 · 空课表",
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onImportRoster, enabled = !rosterLoading) {
            Text(
                when {
                    rosterLoading -> "正在导入…"
                    freeTimetable == null -> "导入空课表（.xlsx / .xls）"
                    else -> "更新空课表"
                }
            )
        }
        val table = freeTimetable
        if (table != null) {
            Text(
                text = "已导入：${table.members.size} 人 · ${table.days.size} 天 × ${BigSections.COUNT} 大节" +
                    (if (table.maxWeek > 0) " · 最晚第 ${table.maxWeek} 周" else "") +
                    " · ${rosterTime(table.importedAt)}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 6.dp)
            )
        }
        Text(
            text = "空课表格式：表头星期一到星期日、每行一个大节，单元格写「姓名 + 没课的周次」" +
                "（如 刘如航16-20、王妍1-6 8-11 19）；姓名后面没有数字表示所有周都没课。导入后到「排班」页自动排班。",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 6.dp)
        )

        Spacer(Modifier.height(22.dp))
        Text(
            text = "排班 · 值班时段",
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = "每个大节的起止时间，会显示在排班页左侧和导出的值班表里。格式 HH:mm（如 08:00）。",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        for (index in 0 until BigSections.COUNT) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${BigSections.shortLabels[index]}节",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.width(60.dp)
                )
                OutlinedTextField(
                    value = startTimes.getOrElse(index) { "" },
                    onValueChange = { input ->
                        startTimes = startTimes.toMutableList().also {
                            it[index] = input.filter { ch -> ch.isDigit() || ch == ':' }.take(5)
                        }
                    },
                    label = { Text("开始", fontSize = 9.sp) },
                    singleLine = true,
                    modifier = Modifier.width(96.dp)
                )
                Text(" - ", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedTextField(
                    value = endTimes.getOrElse(index) { "" },
                    onValueChange = { input ->
                        endTimes = endTimes.toMutableList().also {
                            it[index] = input.filter { ch -> ch.isDigit() || ch == ':' }.take(5)
                        }
                    },
                    label = { Text("结束", fontSize = 9.sp) },
                    singleLine = true,
                    modifier = Modifier.width(96.dp)
                )
            }
            Spacer(Modifier.height(6.dp))
        }
        OutlinedButton(
            onClick = {
                val combined = (0 until BigSections.COUNT).map { index ->
                    "${startTimes.getOrElse(index) { "" }.trim()}-${endTimes.getOrElse(index) { "" }.trim()}"
                }
                onSaveSlotTimes(combined)
            }
        ) { Text("保存值班时段") }

        Spacer(Modifier.height(22.dp))
        Button(onClick = { onSave(term, weekText.toIntOrNull() ?: 0, start) }) {
            Text("保存")
        }

        Spacer(Modifier.height(24.dp))
        Text(
            text = "关于",
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "University_Pcl 1.0.18 · 仅在本机解析你自己导出的课表文件，不上传任何数据。\n" +
                "在设置里导入社团空课表后，到「排班」页按空闲周次自动排值班。\n" +
                "桌面组件在「添加小部件 → 搜索 安卓小部件」里可找到。",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun rosterTime(millis: Long): String {
    if (millis <= 0L) return "导入时间未知"
    return SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(millis)) + " 导入"
}

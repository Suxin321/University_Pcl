package com.university.pcl.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsContent(
    initialTerm: String,
    initialWeek: Int,
    initialStart: String,
    onSave: (term: String, week: Int, semesterStart: String) -> Unit,
    onImport: () -> Unit,
    modifier: Modifier = Modifier
) {
    var term by remember(initialTerm) { mutableStateOf(initialTerm) }
    var weekText by remember(initialWeek) {
        mutableStateOf(if (initialWeek > 0) initialWeek.toString() else "")
    }
    var start by remember(initialStart) { mutableStateOf(initialStart) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text(
            text = "设置",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(16.dp))

        Row(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = term,
                onValueChange = { term = it },
                label = { Text("学期") },
                placeholder = { Text("2026-2027-1") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(12.dp))
            OutlinedTextField(
                value = weekText,
                onValueChange = { input -> weekText = input.filter { it.isDigit() }.take(2) },
                label = { Text("周次") },
                placeholder = { Text("自动") },
                singleLine = true,
                modifier = Modifier.width(110.dp)
            )
        }
        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = start,
            onValueChange = { start = it },
            label = { Text("第 1 周周一日期（可选）") },
            placeholder = { Text("2026-08-31") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = "不填开学日期时按内置校历近似推算（2026-2027-1 从 2026-08-31 起）；手动填了周次则优先用手动值。",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(18.dp))
        Text(
            text = "课表来源",
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onImport) {
            Text("导入课表文件（.xls）")
        }
        Text(
            text = "教务系统 → 课表页 → 右上角「导出」下载 .xls，然后在这里选进来。完全离线，不需要登录。",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 6.dp)
        )

        Spacer(Modifier.height(18.dp))
        Button(onClick = { onSave(term, weekText.toIntOrNull() ?: 0, start) }) {
            Text("保存")
        }

        Spacer(Modifier.height(24.dp))
        Text(
            text = "关于",
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = "University_Pcl 1.0.9 · 仅在本机解析你自己导出的课表文件，不上传任何数据。\n" +
                "桌面组件在「添加小部件 → 搜索 安卓小部件」里可找到。",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

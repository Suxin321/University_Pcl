package com.university.pcl.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.university.pcl.data.BigSections
import com.university.pcl.data.FreeTableEditor
import com.university.pcl.data.FreeTimetable
import com.university.pcl.data.Weekdays
import java.text.Collator
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class SettingsPage { MAIN, TERM, TIMETABLE, FREE_TABLE, SLOT_TIMES, ABOUT }

private val pageTitles = mapOf(
    SettingsPage.TERM to "学期与周次",
    SettingsPage.TIMETABLE to "课表来源",
    SettingsPage.FREE_TABLE to "空课表",
    SettingsPage.SLOT_TIMES to "值班时段",
    SettingsPage.ABOUT to "关于"
)

@Composable
fun SettingsContent(
    initialTerm: String,
    initialWeek: Int,
    initialStart: String,
    freeTimetable: FreeTimetable?,
    rosterLoading: Boolean,
    slotTimes: List<String>,
    courseCount: Int,
    lastSync: Long,
    isActive: Boolean,
    onSave: (term: String, week: Int, semesterStart: String) -> Unit,
    onImport: () -> Unit,
    onImportRoster: () -> Unit,
    onSaveMember: (name: String, slotWeeksText: Map<Pair<Int, Int>, String>) -> Unit,
    onDeleteMember: (String) -> Unit,
    onSaveSlotTimes: (List<String>) -> Unit,
    modifier: Modifier = Modifier
) {
    var term by remember(initialTerm) { mutableStateOf(initialTerm) }
    var weekText by remember(initialWeek) {
        mutableStateOf(if (initialWeek > 0) initialWeek.toString() else "")
    }
    var start by remember(initialStart) { mutableStateOf(initialStart) }
    var startTimes by remember(slotTimes) {
        mutableStateOf(slotTimes.map { it.substringBefore("-") })
    }
    var endTimes by remember(slotTimes) {
        mutableStateOf(slotTimes.map { it.substringAfter("-", "") })
    }
    var page by remember { mutableStateOf(SettingsPage.MAIN) }

    // 系统返回键：在二级页面时先回到设置首页，而不是退出 App
    BackHandler(enabled = isActive && page != SettingsPage.MAIN) {
        page = SettingsPage.MAIN
    }
    // 切到别的标签页再回来时，回到设置首页
    LaunchedEffect(isActive) {
        if (!isActive) page = SettingsPage.MAIN
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(10.dp))

        if (page == SettingsPage.MAIN) {
            Text(
                text = "设置",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(18.dp))

            GroupLabel("课表")
            SettingsRow(
                title = "学期与周次",
                summary = termSummary(term, weekText),
                onClick = { page = SettingsPage.TERM }
            )
            SettingsRow(
                title = "课表来源",
                summary = if (courseCount > 0) {
                    "已导入 $courseCount 条课程 · ${formatTime(lastSync)}"
                } else {
                    "未导入课表文件"
                },
                onClick = { page = SettingsPage.TIMETABLE }
            )

            Spacer(Modifier.height(16.dp))
            GroupLabel("排班")
            SettingsRow(
                title = "空课表",
                summary = freeSummary(freeTimetable),
                onClick = { page = SettingsPage.FREE_TABLE }
            )
            SettingsRow(
                title = "值班时段",
                summary = slotSummary(slotTimes),
                onClick = { page = SettingsPage.SLOT_TIMES }
            )

            Spacer(Modifier.height(16.dp))
            GroupLabel("其他")
            SettingsRow(
                title = "关于",
                summary = "University_Pcl 1.0.30",
                onClick = { page = SettingsPage.ABOUT }
            )
            Spacer(Modifier.height(20.dp))
        } else {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { page = SettingsPage.MAIN }
                    .padding(vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "‹ 设置",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            Text(
                text = pageTitles[page] ?: "设置",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(14.dp))

            when (page) {
                SettingsPage.TERM -> TermPage(
                    term = term,
                    onTermChange = { term = it },
                    weekText = weekText,
                    onWeekChange = { input -> weekText = input.filter { it.isDigit() }.take(2) },
                    start = start,
                    onStartChange = { start = it },
                    onSave = { onSave(term, weekText.toIntOrNull() ?: 0, start) }
                )

                SettingsPage.TIMETABLE -> TimetablePage(
                    courseCount = courseCount,
                    lastSync = lastSync,
                    onImport = onImport
                )

                SettingsPage.FREE_TABLE -> FreeTablePage(
                    freeTimetable = freeTimetable,
                    rosterLoading = rosterLoading,
                    onImportRoster = onImportRoster,
                    onSaveMember = onSaveMember,
                    onDeleteMember = onDeleteMember
                )

                SettingsPage.SLOT_TIMES -> SlotTimesPage(
                    startTimes = startTimes,
                    onStartChange = { index, value ->
                        startTimes = startTimes.toMutableList().also { it[index] = value }
                    },
                    endTimes = endTimes,
                    onEndChange = { index, value ->
                        endTimes = endTimes.toMutableList().also { it[index] = value }
                    },
                    onSave = {
                        val combined = (0 until BigSections.COUNT).map { index ->
                            "${startTimes.getOrElse(index) { "" }.trim()}-${endTimes.getOrElse(index) { "" }.trim()}"
                        }
                        onSaveSlotTimes(combined)
                    }
                )

                SettingsPage.ABOUT -> AboutPage()

                SettingsPage.MAIN -> Unit
            }
        }
    }
}

@Composable
private fun GroupLabel(text: String) {
    Text(
        text = text,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 2.dp, bottom = 4.dp)
    )
}

@Composable
private fun SettingsRow(title: String, summary: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            if (summary.isNotBlank()) {
                Text(
                    text = summary,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Text(
            text = "›",
            fontSize = 18.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
    Box(
        Modifier
            .fillMaxWidth()
            .height(0.5.dp)
            .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
    )
}

@Composable
private fun TermPage(
    term: String,
    onTermChange: (String) -> Unit,
    weekText: String,
    onWeekChange: (String) -> Unit,
    start: String,
    onStartChange: (String) -> Unit,
    onSave: () -> Unit
) {
    Row(Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = term,
            onValueChange = onTermChange,
            label = { Text("学期") },
            placeholder = { Text("2026-2027-1") },
            singleLine = true,
            modifier = Modifier.weight(1f)
        )
        Spacer(Modifier.width(12.dp))
        OutlinedTextField(
            value = weekText,
            onValueChange = onWeekChange,
            label = { Text("周次") },
            placeholder = { Text("自动") },
            singleLine = true,
            modifier = Modifier.width(110.dp)
        )
    }
    Spacer(Modifier.height(12.dp))
    OutlinedTextField(
        value = start,
        onValueChange = onStartChange,
        label = { Text("第 1 周周一日期（可选）") },
        placeholder = { Text("2026-08-31") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
    Spacer(Modifier.height(6.dp))
    Text(
        text = "不填开学日期时按内置校历近似推算（2026-2027-1 从 2026-08-31 起）；手动填了周次则优先用手动值。",
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(Modifier.height(16.dp))
    Button(onClick = onSave) { Text("保存") }
}

@Composable
private fun TimetablePage(courseCount: Int, lastSync: Long, onImport: () -> Unit) {
    OutlinedButton(onClick = onImport) {
        Text("导入课表文件（.xls）")
    }
    Spacer(Modifier.height(8.dp))
    Text(
        text = if (courseCount > 0) {
            "已导入 $courseCount 条课程 · 上次数据 ${formatTime(lastSync)}"
        } else {
            "还没有导入课表"
        },
        fontSize = 12.sp,
        color = if (courseCount > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(Modifier.height(8.dp))
    Text(
        text = "教务系统 → 课表页 → 右上角「导出」下载 .xls，然后在这里选进来。完全离线，不需要登录。",
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun FreeTablePage(
    freeTimetable: FreeTimetable?,
    rosterLoading: Boolean,
    onImportRoster: () -> Unit,
    onSaveMember: (name: String, slotWeeksText: Map<Pair<Int, Int>, String>) -> Unit,
    onDeleteMember: (String) -> Unit
) {
    var editTarget by remember { mutableStateOf<MemberEditTarget?>(null) }
    var pendingDelete by remember { mutableStateOf<String?>(null) }
    OutlinedButton(onClick = onImportRoster, enabled = !rosterLoading) {
        Text(
            when {
                rosterLoading -> "正在导入…"
                freeTimetable == null -> "导入空课表（.xlsx / .xls）"
                else -> "更新空课表"
            }
        )
    }
    Spacer(Modifier.height(8.dp))
    val table = freeTimetable
    if (table != null) {
        Text(
            text = "已导入：${table.members.size} 人 · ${table.days.size} 天 × ${BigSections.COUNT} 大节" +
                (if (table.maxWeek > 0) " · 最晚第 ${table.maxWeek} 周" else "") +
                " · ${formatTime(table.importedAt)}",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(8.dp))
    }
    Text(
        text = "空课表格式：表头星期一到星期日、每行一个大节，单元格写「姓名 + 没课的周次」" +
            "（如 刘如航16-20、王妍1-6 8-11 19）；姓名后面没有数字表示所有周都没课。导入后到「排班」页自动排班。",
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )

    if (table != null) {
        Spacer(Modifier.height(18.dp))
        Text(
            text = "成员管理 · ${table.members.size} 人",
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = "可以手动增删成员，并单独调整每个人有空的时段和周次。",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = {
            editTarget = MemberEditTarget(name = "", slotWeeks = emptyMap(), isNew = true)
        }) { Text("＋ 添加成员") }
        Spacer(Modifier.height(10.dp))
        val collator = remember { Collator.getInstance(Locale.CHINA) }
        val sorted = table.members.sortedWith { a, b -> collator.compare(a, b) }
        Column(
            Modifier
                .fillMaxWidth()
                .heightIn(max = 420.dp)
                .verticalScroll(rememberScrollState())
        ) {
            sorted.forEach { name ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = name,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = {
                        val slotWeeks = LinkedHashMap<Pair<Int, Int>, String>()
                        FreeTableEditor.slotsOf(table, name).sortedWith(
                            compareBy({ it.first }, { it.second })
                        ).forEach { key ->
                            slotWeeks[key] = FreeTableEditor.weeksTextOfSlot(table, name, key.first, key.second)
                        }
                        editTarget = MemberEditTarget(name = name, slotWeeks = slotWeeks, isNew = false)
                    }) { Text("编辑", fontSize = 12.sp) }
                    TextButton(onClick = { pendingDelete = name }) {
                        Text("删除", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }

    val deleting = pendingDelete
    if (deleting != null) {
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("删除成员", fontSize = 16.sp) },
            confirmButton = {
                TextButton(onClick = {
                    onDeleteMember(deleting)
                    pendingDelete = null
                }) { Text("确定删除", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { pendingDelete = null }) { Text("取消") }
            },
            text = {
                Text(
                    text = "确定删除「$deleting」吗？已排好的班次会保留，重新导入空课表可以恢复。",
                    fontSize = 13.sp
                )
            }
        )
    }

    val target = editTarget
    if (target != null && table != null) {
        MemberEditorDialog(
            target = target,
            days = (1..7).toList(),
            onDismiss = { editTarget = null },
            onSave = { name, slotWeeks ->
                onSaveMember(name, slotWeeks)
                editTarget = null
            }
        )
    }
}

private data class MemberEditTarget(
    val name: String,
    val slotWeeks: Map<Pair<Int, Int>, String>,
    val isNew: Boolean
)

@Composable
private fun MemberEditorDialog(
    target: MemberEditTarget,
    days: List<Int>,
    onDismiss: () -> Unit,
    onSave: (name: String, slotWeeksText: Map<Pair<Int, Int>, String>) -> Unit
) {
    var name by remember(target) { mutableStateOf(target.name) }
    var slotWeeks by remember(target) { mutableStateOf(target.slotWeeks) }
    var bulkText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (target.isNew) "添加成员" else "编辑成员 · ${target.name}", fontSize = 16.sp) },
        confirmButton = {
            TextButton(
                onClick = { onSave(name.trim(), slotWeeks) },
                enabled = name.trim().isNotEmpty() && slotWeeks.isNotEmpty()
            ) { Text("保存") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } },
        text = {
            Column(
                Modifier
                    .heightIn(max = 520.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("姓名") },
                    singleLine = true,
                    enabled = target.isNew,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "勾选这个人有空的时段，每个时段可以单独填没课的周次：",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(4.dp))
                for (day in days) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "周${Weekdays.short[day - 1]}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.width(38.dp)
                        )
                        for (big in 1..BigSections.COUNT) {
                            val key = day to big
                            SlotChip(
                                label = BigSections.shortLabels[big - 1],
                                selected = slotWeeks.containsKey(key),
                                onClick = {
                                    slotWeeks = if (slotWeeks.containsKey(key)) {
                                        slotWeeks - key
                                    } else {
                                        slotWeeks + (key to "")
                                    }
                                }
                            )
                            Spacer(Modifier.width(4.dp))
                        }
                    }
                }
                if (slotWeeks.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "每个时段的没课周次（留空 = 所有周）：",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(4.dp))
                    val keys = slotWeeks.keys.sortedWith(compareBy({ it.first }, { it.second }))
                    keys.forEach { key ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "周${Weekdays.short[key.first - 1]} ${BigSections.shortLabels[key.second - 1]}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.width(90.dp)
                            )
                            OutlinedTextField(
                                value = slotWeeks[key].orEmpty(),
                                onValueChange = { input ->
                                    slotWeeks = slotWeeks.toMutableMap().also { it[key] = input }
                                },
                                placeholder = { Text("所有周", fontSize = 11.sp) },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = bulkText,
                            onValueChange = { bulkText = it },
                            label = { Text("统一填周次") },
                            placeholder = { Text("如 1-20", fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(6.dp))
                        TextButton(
                            onClick = {
                                if (bulkText.trim().isNotEmpty()) {
                                    slotWeeks = slotWeeks.mapValues { bulkText.trim() }
                                }
                            }
                        ) { Text("应用到已选", fontSize = 12.sp) }
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "保存后按每个时段分别计算这位同学有没有空。",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    )
}

@Composable
private fun SlotChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(8.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SlotTimesPage(
    startTimes: List<String>,
    onStartChange: (index: Int, value: String) -> Unit,
    endTimes: List<String>,
    onEndChange: (index: Int, value: String) -> Unit,
    onSave: () -> Unit
) {
    Text(
        text = "每个大节的起止时间，会显示在排班页左侧和导出的值班表里。格式 HH:mm（如 08:00）。",
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(Modifier.height(10.dp))
    for (index in 0 until BigSections.COUNT) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "${BigSections.shortLabels[index]}节",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.width(60.dp)
            )
            OutlinedTextField(
                value = startTimes.getOrElse(index) { "" },
                onValueChange = { input ->
                    onStartChange(index, input.filter { ch -> ch.isDigit() || ch == ':' }.take(5))
                },
                label = { Text("开始", fontSize = 9.sp) },
                singleLine = true,
                modifier = Modifier.width(96.dp)
            )
            Text(" - ", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(
                value = endTimes.getOrElse(index) { "" },
                onValueChange = { input ->
                    onEndChange(index, input.filter { ch -> ch.isDigit() || ch == ':' }.take(5))
                },
                label = { Text("结束", fontSize = 9.sp) },
                singleLine = true,
                modifier = Modifier.width(96.dp)
            )
        }
        Spacer(Modifier.height(6.dp))
    }
    Spacer(Modifier.height(4.dp))
    OutlinedButton(onClick = onSave) { Text("保存值班时段") }
}

@Composable
private fun AboutPage() {
    Column(
        Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        Text(
            text = "University_Pcl 1.0.30",
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = "仅在本机解析你自己导出的课表文件，不上传任何数据。",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(6.dp))
        Text(
            text = "桌面组件在「添加小部件 → 搜索 安卓小部件」里可找到；排班暂未接入组件。",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun termSummary(term: String, weekText: String): String {
    val termPart = term.ifBlank { "学期自动" }
    val weekPart = if (weekText.isBlank()) "第几周自动" else "手动第 $weekText 周"
    return "$termPart · $weekPart"
}

private fun freeSummary(free: FreeTimetable?): String {
    if (free == null) return "未导入"
    return "${free.members.size} 人 · ${free.days.size} 天 × ${BigSections.COUNT} 大节 · ${formatTime(free.importedAt)}"
}

private fun slotSummary(slotTimes: List<String>): String {
    if (slotTimes.isEmpty()) return "未设置"
    return "${BigSections.shortLabels[0]} ${slotTimes.getOrElse(0) { "" }} 等 ${slotTimes.size} 个时段"
}

private fun formatTime(millis: Long): String {
    if (millis <= 0L) return "导入时间未知"
    return SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(millis)) + " 导入"
}

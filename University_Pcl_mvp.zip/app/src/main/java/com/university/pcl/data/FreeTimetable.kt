package com.university.pcl.data

import jxl.Workbook
import kotlinx.serialization.Serializable
import org.w3c.dom.Element
import java.io.File
import java.io.IOException
import javax.xml.parsers.DocumentBuilderFactory
import java.util.zip.ZipFile

/**
 * 空课表：社团成员「哪些周、哪些大节没课」的表。
 *
 * 格式（就协新媒体中心导出的 Excel 常见样式）：
 * - 表头一行写着 星期一 … 星期五（也支持周一/礼拜一/带星期几的单元格）；
 * - 表头下一行一个「第 X 大节」，行里每格列出该时段的成员；
 * - 每行一个成员，写法是「姓名 + 空闲周次」，如 `刘如航16-20`、`王妍1-6 8-11 19`；
 *   姓名后面没有数字 = 这个人所有周都没课。
 *
 * 空课表不是固定的：用户可以随时重新导入一份替换旧的。
 */
@Serializable
data class MemberFree(
    val name: String = "",
    val allWeeks: Boolean = false,
    val weeks: List<Int> = emptyList()
) {
    fun freeIn(week: Int): Boolean = allWeeks || (week > 0 && weeks.contains(week))
}

@Serializable
data class FreeCell(
    val day: Int = 1,
    val bigSection: Int = 1,
    val members: List<MemberFree> = emptyList()
)

@Serializable
data class FreeTimetable(
    val importedAt: Long = 0L,
    val sourceName: String = "",
    /** 表里出现的星期，升序，1=周一。 */
    val days: List<Int> = emptyList(),
    val cells: List<FreeCell> = emptyList(),
    /** 所有成员（按首次出现顺序）。 */
    val members: List<String> = emptyList(),
    /** 表里出现过的最大周次（没人写数字时为 0）。 */
    val maxWeek: Int = 0
) {
    fun cell(day: Int, bigSection: Int): FreeCell? =
        cells.firstOrNull { it.day == day && it.bigSection == bigSection }

    /** 某周某时段有空的人（顺序同表里出现顺序）。 */
    fun freeNames(day: Int, bigSection: Int, week: Int): List<String> =
        cell(day, bigSection)?.members?.filter { it.freeIn(week) }?.map { it.name }.orEmpty()

    val loaded: Boolean get() = members.isNotEmpty() && days.isNotEmpty()

    companion object {
        const val DEFAULT_MAX_WEEK = 20
    }
}

/** 解析空课表文件（.xlsx / .xls）以及其中的「姓名+周次」文本。 */
object FreeTimetableParser {

    private val weekdayRegex = Regex("""^(?:星期|周|礼拜)?([一二三四五六日天])$""")
    private val weekdayMap = mapOf(
        '一' to 1, '二' to 2, '三' to 3, '四' to 4,
        '五' to 5, '六' to 6, '日' to 7, '天' to 7
    )
    private val bigRegex = Regex("""第\s*([一二三四五六七八九十\d]+)\s*大节""")
    private val rangeRegex = Regex("""(\d{1,2})\s*[-~—–－至到]\s*(\d{1,2})""")
    private val singleRegex = Regex("""\d{1,2}""")

    /** 按文件头判断 xlsx（zip）/ xls（OLE），两种都能读。 */
    fun parse(file: File): FreeTimetable {
        val head = ByteArray(4)
        val read = file.inputStream().use { it.read(head) }
        if (read < 2) throw IOException("文件是空的")
        val isZip = head[0] == 0x50.toByte() && head[1] == 0x4B.toByte()
        val isOle = head[0] == 0xD0.toByte() && head[1] == 0xCF.toByte()
        return when {
            isZip -> parseXlsx(file)
            isOle -> parseXls(file)
            else -> throw IOException("只支持 .xlsx / .xls 格式的空课表")
        }
    }

    // ---------- 文件读取 ----------

    private fun parseXlsx(file: File): FreeTimetable {
        ZipFile(file).use { zip ->
            val shared = zip.getEntry("xl/sharedStrings.xml")?.let { entry ->
                parseSharedStrings(zip.getInputStream(entry).readBytes().toString(Charsets.UTF_8))
            }.orEmpty()

            var sheetEntry = zip.getEntry("xl/worksheets/sheet1.xml")
            if (sheetEntry == null) {
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    if (entry.name.startsWith("xl/worksheets/") && entry.name.endsWith(".xml")) {
                        sheetEntry = entry
                        break
                    }
                }
            }
            if (sheetEntry == null) throw IOException("xlsx 里没有工作表")
            val xml = zip.getInputStream(sheetEntry).readBytes().toString(Charsets.UTF_8)
            return parseGrid(parseSheetXml(xml, shared))
        }
    }

    private fun parseXls(file: File): FreeTimetable {
        val workbook = Workbook.getWorkbook(file)
        try {
            if (workbook.numberOfSheets == 0) throw IOException("xls 里没有工作表")
            val sheet = workbook.getSheet(0)
            val rows = ArrayList<List<String>>(sheet.rows)
            for (r in 0 until sheet.rows) {
                val row = ArrayList<String>(sheet.columns)
                for (c in 0 until sheet.columns) {
                    row.add(runCatching { sheet.getCell(c, r).contents }.getOrDefault(""))
                }
                rows.add(row)
            }
            return parseGrid(rows)
        } finally {
            workbook.close()
        }
    }

    // ---------- xlsx 的 XML ----------

    /** 解析 sharedStrings.xml，按顺序返回全部字符串。 */
    fun parseSharedStrings(xml: String): List<String> {
        val doc = newBuilder().parse(xml.byteInputStream(Charsets.UTF_8))
        val nodes = doc.getElementsByTagName("si")
        val out = ArrayList<String>(nodes.length)
        for (i in 0 until nodes.length) {
            val si = nodes.item(i) as? Element ?: continue
            val texts = si.getElementsByTagName("t")
            out.add(buildString { for (k in 0 until texts.length) append(texts.item(k).textContent) })
        }
        return out
    }

    /** 解析 sheet XML 为「行 → 单元格文本」的二维表（空单元格用空串补齐）。 */
    fun parseSheetXml(xml: String, shared: List<String>): List<List<String>> {
        val doc = newBuilder().parse(xml.byteInputStream(Charsets.UTF_8))
        val out = ArrayList<List<String>>()
        val rowNodes = doc.getElementsByTagName("row")
        for (i in 0 until rowNodes.length) {
            val rowEl = rowNodes.item(i) as? Element ?: continue
            val cells = sortedMapOf<Int, String>()
            val cellNodes = rowEl.getElementsByTagName("c")
            var nextCol = 0
            for (j in 0 until cellNodes.length) {
                val cellEl = cellNodes.item(j) as? Element ?: continue
                val col = columnIndexOf(cellEl.getAttribute("r")) ?: nextCol
                nextCol = col + 1
                cells[col] = cellText(cellEl, shared)
            }
            val maxCol = cells.keys.maxOrNull() ?: -1
            val row = ArrayList<String>(maxCol + 1)
            for (k in 0..maxCol) row.add(cells[k] ?: "")
            out.add(row)
        }
        return out
    }

    private fun newBuilder() =
        DocumentBuilderFactory.newInstance().apply { isNamespaceAware = false }.newDocumentBuilder()

    private fun cellText(cell: Element, shared: List<String>): String {
        val type = cell.getAttribute("t")
        return when (type) {
            "s" -> {
                val vs = cell.getElementsByTagName("v")
                val raw = if (vs.length > 0) vs.item(0).textContent.trim() else ""
                raw.toIntOrNull()?.let { shared.getOrNull(it) }.orEmpty()
            }
            "inlineStr" -> {
                val texts = cell.getElementsByTagName("t")
                buildString { for (k in 0 until texts.length) append(texts.item(k).textContent) }
            }
            else -> {
                val vs = cell.getElementsByTagName("v")
                if (vs.length > 0) vs.item(0).textContent else ""
            }
        }
    }

    /** "B3" → 1（A=0）。 */
    private fun columnIndexOf(ref: String): Int? {
        if (ref.isEmpty()) return null
        var value = 0
        var letters = 0
        for (ch in ref) {
            if (ch in 'A'..'Z') {
                value = value * 26 + (ch - 'A' + 1)
                letters++
            } else if (ch in 'a'..'z') {
                value = value * 26 + (ch - 'a' + 1)
                letters++
            } else {
                break
            }
        }
        return if (letters == 0) null else value - 1
    }

    // ---------- 二维表 → 空课表 ----------

    fun parseGrid(rows: List<List<String>>): FreeTimetable {
        if (rows.isEmpty()) throw IOException("表格是空的")

        var headerRow = -1
        var dayCols: Map<Int, Int> = emptyMap()
        for ((ri, row) in rows.withIndex()) {
            val found = LinkedHashMap<Int, Int>()
            row.forEachIndexed { ci, raw -> weekdayOf(raw)?.let { found[ci] = it } }
            if (found.size >= 2) {
                headerRow = ri
                dayCols = found
                break
            }
        }
        if (headerRow < 0) throw IOException("没找到「星期一 … 星期日」表头，确认这份文件是空课表")

        val bigRows = ArrayList<Pair<Int, Int>>()
        for (ri in headerRow + 1 until rows.size) {
            val label = rows[ri].firstOrNull()?.trim().orEmpty()
            bigSectionOf(label)?.let { bigRows.add(ri to it) }
        }
        if (bigRows.isEmpty()) throw IOException("没找到「第 X 大节」的行")

        val days = dayCols.values.toSortedSet().toList()
        val cells = ArrayList<FreeCell>()
        val memberOrder = LinkedHashMap<String, MemberFree>()

        for (big in 1..BigSections.COUNT) {
            val rowIndex = bigRows.firstOrNull { it.second == big }?.first
            for (day in days) {
                val col = dayCols.entries.firstOrNull { it.value == day }?.key ?: continue
                val text = if (rowIndex != null) rows.getOrNull(rowIndex)?.getOrNull(col).orEmpty() else ""
                val members = parseCellMembers(text)
                cells.add(FreeCell(day = day, bigSection = big, members = members))
                members.forEach { m ->
                    val prev = memberOrder[m.name]
                    memberOrder[m.name] = if (prev == null) m else mergeMembers(prev, m)
                }
            }
        }
        if (memberOrder.isEmpty()) throw IOException("没解析到成员名字，确认单元格里是「姓名 + 周次」的写法")

        return FreeTimetable(
            importedAt = System.currentTimeMillis(),
            days = days,
            cells = cells,
            members = memberOrder.keys.toList(),
            maxWeek = memberOrder.values.flatMap { it.weeks }.maxOrNull() ?: 0
        )
    }

    private fun mergeMembers(a: MemberFree, b: MemberFree): MemberFree = MemberFree(
        name = a.name,
        allWeeks = a.allWeeks || b.allWeeks,
        weeks = (a.weeks + b.weeks).distinct().sorted()
    )

    /** 一个单元格 → 若干成员（每个成员一行）。 */
    fun parseCellMembers(text: String): List<MemberFree> {
        if (text.isBlank()) return emptyList()
        val out = LinkedHashMap<String, MemberFree>()
        text.replace("\r", "\n").split('\n').forEach { line ->
            parseMemberLine(line)?.let { m ->
                val prev = out[m.name]
                out[m.name] = if (prev == null) m else mergeMembers(prev, m)
            }
        }
        return out.values.toList()
    }

    /** 「刘如航16-20」→ MemberFree("刘如航", false, [16..20])；「孙继泽」→ allWeeks。 */
    fun parseMemberLine(line: String): MemberFree? {
        val text = normalizeDigits(line.trim())
        if (text.isEmpty()) return null
        val digitIndex = text.indexOfFirst { it.isDigit() }
        if (digitIndex < 0) {
            val name = cleanName(text)
            return if (name.isEmpty()) null else MemberFree(name = name, allWeeks = true)
        }
        val name = cleanName(text.substring(0, digitIndex))
        if (name.isEmpty()) return null
        val (_, weeks) = parseWeekSpec(text.substring(digitIndex))
        return MemberFree(name = name, allWeeks = false, weeks = weeks)
    }

    /**
     * 周次写法 → (是否所有周, 周次列表)。
     * `16-20`、`1-8 13-20`、`1-11 13 15-20`、`19` 都支持；空文本表示所有周。
     */
    fun parseWeekSpec(raw: String): Pair<Boolean, List<Int>> {
        val text = normalizeDigits(raw.trim())
        if (text.isEmpty()) return true to emptyList()
        if (text.none { it.isDigit() }) return true to emptyList()

        val weeks = sortedSetOf<Int>()
        rangeRegex.findAll(text).forEach { m ->
            val a = m.groupValues[1].toIntOrNull() ?: return@forEach
            val b = m.groupValues[2].toIntOrNull() ?: return@forEach
            for (w in minOf(a, b)..maxOf(a, b)) if (w in 1..30) weeks.add(w)
        }
        val rest = rangeRegex.replace(text, " ")
        singleRegex.findAll(rest).forEach { m ->
            val w = m.value.toIntOrNull() ?: return@forEach
            if (w in 1..30) weeks.add(w)
        }
        val list = weeks.toList()
        // 写了数字却一个有效周次都没有（比如误写成 45）：按所有周处理，避免把人静默排除出排班。
        return if (list.isEmpty()) true to emptyList() else false to list
    }

    /** "星期一" / "周一" / "礼拜一" → 1..7；不是星期表头返回 null。 */
    fun weekdayOf(raw: String): Int? {
        val text = raw.trim().replace(" ", "").replace("\u3000", "")
        val m = weekdayRegex.find(text) ?: return null
        return weekdayMap[m.groupValues[1][0]]
    }

    /** "第一大节" / "第1大节" → 1。 */
    fun bigSectionOf(label: String): Int? {
        val m = bigRegex.find(label.trim()) ?: return null
        val raw = m.groupValues[1]
        return raw.toIntOrNull() ?: chineseNumber(raw)
    }

    private fun chineseNumber(raw: String): Int? {
        if (raw.isEmpty()) return null
        val map = mapOf(
            '一' to 1, '二' to 2, '三' to 3, '四' to 4, '五' to 5,
            '六' to 6, '七' to 7, '八' to 8, '九' to 9
        )
        if (raw == "十") return 10
        if (raw.length == 2 && raw[1] == '十') return (map[raw[0]] ?: return null) * 10
        if (raw.length == 3 && raw[1] == '十') return (map[raw[0]] ?: return null) * 10 + (map[raw[2]] ?: return null)
        if (raw[0] == '十') return 10 + (raw.getOrNull(1)?.let { map[it] } ?: return null)
        return map[raw[0]]
    }

    private fun cleanName(raw: String): String {
        var name = raw.trim().trim(' ', '\u3000', '\u00a0', '、', '，', ',', ';', '；', ':', '：')
        if (name.startsWith("姓名")) name = name.removePrefix("姓名").trim(' ', '\u3000', ':', '：')
        return name
    }

    private fun normalizeDigits(raw: String): String {
        if (raw.isEmpty()) return raw
        val sb = StringBuilder(raw.length)
        for (ch in raw) {
            sb.append(
                when (ch) {
                    in '０'..'９' -> '0' + (ch - '０')
                    '．' -> '.'
                    '－', '—', '–', '~', '～' -> '-'
                    else -> ch
                }
            )
        }
        return sb.toString()
    }
}

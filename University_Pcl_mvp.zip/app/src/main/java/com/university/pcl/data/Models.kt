package com.university.pcl.data

import kotlinx.serialization.Serializable

/** 归一化后的一节课。day: 1=周一..7=周日；bigSection: 1..5 大节。 */
@Serializable
data class CourseSlot(
    val day: Int = 0,
    val bigSection: Int = 0,
    val name: String = "",
    val room: String = "",
    val teacher: String = "",
    val weekText: String = "",
    val weeks: List<Int> = emptyList(),
    val parity: Int = 0 // 0=每周 1=单周 2=双周
) {
    fun activeIn(week: Int): Boolean {
        if (week <= 0) return true
        val inRange = weeks.isEmpty() || weeks.contains(week)
        val parityOk = when (parity) {
            1 -> week % 2 == 1
            2 -> week % 2 == 0
            else -> true
        }
        return inRange && parityOk
    }
}

@Serializable
data class ScheduleCache(
    val fetchedAt: Long = 0L,
    val term: String = "",
    val week: Int = 0,
    val items: List<CourseSlot> = emptyList()
)

object BigSections {
    const val COUNT = 5
    val labels = listOf("1-2 节", "3-4 节", "5-6 节", "7-8 节", "9-10 节")
    val shortLabels = listOf("1-2", "3-4", "5-6", "7-8", "9-10")
}

object Weekdays {
    val long = listOf("周一", "周二", "周三", "周四", "周五", "周六", "周日")
    val short = listOf("一", "二", "三", "四", "五", "六", "日")
}

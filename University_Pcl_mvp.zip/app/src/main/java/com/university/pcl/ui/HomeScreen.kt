package com.university.pcl.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.university.pcl.data.BigSections
import com.university.pcl.data.CourseSlot
import com.university.pcl.data.ScheduleCache
import com.university.pcl.data.Weekdays
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeContent(
    cache: ScheduleCache?,
    loggedIn: Boolean,
    week: Int,
    baseUrl: String,
    selectedDay: Int,
    todayDay: Int,
    loading: Boolean,
    message: String?,
    lastSync: Long,
    onSelectDay: (Int) -> Unit,
    onLogin: () -> Unit,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeWeek = if (week > 0) week else (cache?.week ?: 0)
    val daySlots = cache?.items
        ?.filter { it.day == selectedDay && it.activeIn(activeWeek) }
        .orEmpty()
    val dayName = Weekdays.long.getOrNull(selectedDay - 1) ?: ""

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
    ) {
        Spacer(Modifier.height(16.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = "课程表",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "第 $activeWeek 周 · ${hostOf(baseUrl)}",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            TextButton(onClick = onRefresh, enabled = !loading) {
                Text(if (loading) "刷新中…" else "刷新")
            }
        }

        if (message != null) {
            Text(
                text = message,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 6.dp)
            )
        }

        Spacer(Modifier.height(12.dp))

        if (!loggedIn) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(18.dp))
                    .padding(18.dp)
            ) {
                Text(
                    text = "还没有登录教务系统",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "登录一次即可。账号密码只在手机本地使用，不会上传到任何服务器。",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = onLogin) { Text("去登录") }
            }
            Spacer(Modifier.height(16.dp))
        }

        WeekChips(
            selectedDay = selectedDay,
            todayDay = todayDay,
            onSelectDay = onSelectDay
        )

        Spacer(Modifier.height(16.dp))

        Text(
            text = "$dayName 的课",
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(8.dp))

        Column(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(18.dp))
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            for (index in 1..BigSections.COUNT) {
                val items = daySlots.filter { it.bigSection == index }
                SectionRow(
                    label = BigSections.shortLabels[index - 1],
                    items = items
                )
                if (index < BigSections.COUNT) {
                    HorizontalDivider(
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.outlineVariant
                    )
                }
            }
        }

        if (cache == null) {
            Text(
                text = if (loggedIn) "还没有课表数据，点右上角「刷新」拉取。" else "登录后会自动拉取课表。",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(top = 12.dp)
            )
        }

        Text(
            text = "上次同步：${formatTime(lastSync)} · 桌面组件显示「今天」的 5 大节",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 12.dp, bottom = 24.dp)
        )
    }
}

@Composable
private fun WeekChips(
    selectedDay: Int,
    todayDay: Int,
    onSelectDay: (Int) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        for (day in 1..7) {
            val selected = day == selectedDay
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .width(44.dp)
                    .background(
                        color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(14.dp)
                    )
                    .clickable { onSelectDay(day) }
                    .padding(vertical = 8.dp)
            ) {
                Text(
                    text = Weekdays.short[day - 1],
                    fontSize = 12.sp,
                    color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = if (day == todayDay) "今" else "",
                    fontSize = 10.sp,
                    color = if (selected) Color.White.copy(alpha = 0.85f) else MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun SectionRow(label: String, items: List<CourseSlot>) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp)) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(48.dp)
        )
        Column(Modifier.weight(1f)) {
            if (items.isEmpty()) {
                Text(
                    text = "无课",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f)
                )
            } else {
                items.forEach { course ->
                    Text(
                        text = course.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    val meta = listOfNotNull(
                        course.room.takeIf { it.isNotBlank() },
                        course.teacher.takeIf { it.isNotBlank() }
                    ).joinToString(" · ")
                    if (meta.isNotBlank()) {
                        Text(
                            text = meta,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 2.dp, bottom = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun hostOf(baseUrl: String): String =
    baseUrl.removePrefix("https://").removePrefix("http://").trimEnd('/')

private fun formatTime(millis: Long): String {
    if (millis <= 0L) return "尚未同步"
    return SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(millis))
}

package com.university.pcl.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.university.pcl.data.BigSections
import com.university.pcl.data.CourseSlot
import com.university.pcl.data.ManualCourse
import com.university.pcl.data.ScheduleCache
import com.university.pcl.data.Weekdays
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale
import kotlin.math.absoluteValue

private val coursePalette = listOf(
    Color(0xFF6FBF4A),
    Color(0xFF1FA463),
    Color(0xFF3E8EF7),
    Color(0xFFD06BD6),
    Color(0xFFC07A16),
    Color(0xFFF07A79),
    Color(0xFF8B5CF6),
    Color(0xFF0EA5A4)
)

private val periodStart = listOf("8:00", "9:00", "10:10", "11:10", "14:00", "15:00", "16:10", "17:10", "19:00", "20:00")
private val periodEnd = listOf("8:50", "9:50", "11:00", "12:00", "14:50", "15:50", "17:00", "18:00", "19:50", "20:50")

fun courseColor(name: String): Color =
    coursePalette[name.hashCode().absoluteValue % coursePalette.size]

@Composable
fun HomeContent(
    cache: ScheduleCache?,
    manualCourses: List<ManualCourse>,
    week: Int,
    weekIsManual: Boolean,
    baseUrl: String,
    loading: Boolean,
    message: String?,
    lastSync: Long,
    onRefresh: () -> Unit,
    onWeekChange: (Int) -> Unit,
    onWeekReset: () -> Unit,
    onAddManual: (name: String, room: String, teacher: String, day: Int, bigSection: Int) -> Unit,
    onDeleteManual: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val today = LocalDate.now()
    var addTarget by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    val currentWeek = week.coerceAtLeast(1)
    val displayedWeek = currentWeek
    val allSlots = cache?.items.orEmpty() + manualCourses.map { it.toSlot() }

    val todayMonday = today.minusDays((today.dayOfWeek.value - 1).toLong())
    val weekMonday = todayMonday.plusWeeks((displayedWeek - currentWeek).toLong())
    val df = DateTimeFormatter.ofPattern("MM-dd")

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 12.dp)
    ) {
        Spacer(Modifier.height(10.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = "第 $displayedWeek 周",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "${weekMonday.format(df)} ~ ${weekMonday.plusDays(6).format(df)} · ${hostOf(baseUrl)}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            TextButton(onClick = { onWeekChange(displayedWeek - 1) }) { Text("‹") }
            TextButton(onClick = { onWeekReset() }) {
                Text(if (weekIsManual) "返回本周" else "本周")
            }
            TextButton(onClick = { onWeekChange(displayedWeek + 1) }) { Text("›") }
            TextButton(onClick = onRefresh, enabled = !loading) {
                Text(if (loading) "…" else "刷新")
            }
        }

        if (message != null) {
            Text(
                text = message,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        if (cache == null && manualCourses.isEmpty()) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(18.dp))
                    .padding(18.dp)
            ) {
                Text(
                    text = "还没有课表",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "到「设置 → 导入课表文件（.xls）」导入教务系统导出的课表即可（完全离线）。",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
        }

        Spacer(Modifier.height(10.dp))

        // 表头：星期 + 日期
        Row(Modifier.fillMaxWidth()) {
            Spacer(Modifier.width(44.dp))
            for (day in 1..7) {
                val date = weekMonday.plusDays((day - 1).toLong())
                val isToday = date == today
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .weight(1f)
                        .padding(vertical = 4.dp)
                ) {
                    Text(
                        text = Weekdays.short[day - 1],
                        fontSize = 12.sp,
                        fontWeight = if (isToday) FontWeight.Bold else FontWeight.Medium,
                        color = if (isToday) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = date.format(df),
                        fontSize = 9.sp,
                        color = if (isToday) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // 5 大节 × 7 天网格
        for (big in 1..BigSections.COUNT) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(96.dp)
                    .padding(vertical = 1.dp)
            ) {
                Column(
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .width(44.dp)
                        .fillMaxHeight()
                ) {
                    for (k in 0..1) {
                        val periodIndex = (big - 1) * 2 + k
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${periodIndex + 1}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.width(22.dp),
                                maxLines = 1,
                                softWrap = false
                            )
                            Column {
                                Text(
                                    text = periodStart[periodIndex],
                                    fontSize = 7.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                                Text(
                                    text = periodEnd[periodIndex],
                                    fontSize = 7.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                        }
                    }
                }
                for (day in 1..7) {
                    val date = weekMonday.plusDays((day - 1).toLong())
                    val isToday = date == today
                    val courses = allSlots.filter {
                        it.day == day && it.bigSection == big && it.activeIn(displayedWeek)
                    }
                    DayCell(
                        courses = courses,
                        isToday = isToday,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxSize()
                            .padding(horizontal = 1.dp)
                            .clickable {
                                addTarget = day to big
                                showAddDialog = true
                            }
                    )
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "手动加课",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.width(8.dp))
            TextButton(onClick = { showAddDialog = true }) { Text("+ 添加") }
        }
        if (manualCourses.isNotEmpty()) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(14.dp))
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            ) {
                manualCourses.forEach { course ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier
                                .width(4.dp)
                                .height(22.dp)
                                .background(courseColor(course.name), RoundedCornerShape(2.dp))
                        ) {}
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "周${Weekdays.short[course.day - 1]} ${BigSections.shortLabels.getOrNull(course.bigSection - 1) ?: ""} ${course.name}${if (course.room.isNotBlank()) "  @" + course.room else ""}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = { onDeleteManual(course.id) }) { Text("删除") }
                    }
                }
            }
        }

        Text(
            text = "上次数据：${formatTime(lastSync)} · 点空白格可加课",
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 8.dp, bottom = 20.dp)
        )
    }

    if (showAddDialog) {
        AddCourseDialog(
            initialDay = addTarget?.first ?: (today.dayOfWeek.value),
            initialBigSection = addTarget?.second ?: 1,
            onDismiss = {
                showAddDialog = false
                addTarget = null
            },
            onConfirm = { name, room, teacher, day, bigSection ->
                onAddManual(name, room, teacher, day, bigSection)
                showAddDialog = false
                addTarget = null
            }
        )
    }
}

@Composable
private fun DayCell(
    courses: List<CourseSlot>,
    isToday: Boolean,
    modifier: Modifier = Modifier
) {
    val base = if (isToday) {
        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
    } else {
        Color.Transparent
    }
    Box(
        modifier = modifier
            .background(base, RoundedCornerShape(6.dp))
            .border(
                width = 0.5.dp,
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                shape = RoundedCornerShape(6.dp)
            )
    ) {
        if (courses.isNotEmpty()) {
            Row(
                Modifier
                    .fillMaxSize()
                    .padding(2.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                courses.forEach { course ->
                    Column(
                        Modifier
                            .weight(1f)
                            .fillMaxSize()
                            .background(courseColor(course.name), RoundedCornerShape(8.dp))
                            .padding(horizontal = 4.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = course.name,
                            fontSize = 11.sp,
                            lineHeight = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.White,
                            maxLines = 4,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (course.room.isNotBlank()) {
                            Text(
                                text = "@" + course.room,
                                fontSize = 9.sp,
                                color = Color.White.copy(alpha = 0.9f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AddCourseDialog(
    initialDay: Int,
    initialBigSection: Int,
    onDismiss: () -> Unit,
    onConfirm: (String, String, String, Int, Int) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var room by remember { mutableStateOf("") }
    var teacher by remember { mutableStateOf("") }
    var day by remember { mutableStateOf(initialDay.coerceIn(1, 7)) }
    var bigSection by remember { mutableStateOf(initialBigSection.coerceIn(1, BigSections.COUNT)) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("手动加课") },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(name.trim(), room.trim(), teacher.trim(), day, bigSection) },
                enabled = name.isNotBlank()
            ) { Text("保存") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("取消") }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("课程名") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = room,
                    onValueChange = { room = it },
                    label = { Text("地点") },
                    placeholder = { Text("J7-205") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = teacher,
                    onValueChange = { teacher = it },
                    label = { Text("教师") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                Text("星期", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (d in 1..7) {
                        SelectChip(
                            label = Weekdays.short[d - 1],
                            selected = day == d,
                            onClick = { day = d }
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Text("大节", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (s in 1..BigSections.COUNT) {
                        SelectChip(
                            label = BigSections.shortLabels[s - 1],
                            selected = bigSection == s,
                            onClick = { bigSection = s }
                        )
                    }
                }
            }
        }
    )
}

@Composable
private fun SelectChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .background(
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                shape = RoundedCornerShape(10.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun hostOf(baseUrl: String): String =
    baseUrl.removePrefix("https://").removePrefix("http://").trimEnd('/')

private fun formatTime(millis: Long): String {
    if (millis <= 0L) return "尚未同步"
    return SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(millis))
}

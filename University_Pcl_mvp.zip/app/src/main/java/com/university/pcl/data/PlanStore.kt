package com.university.pcl.data

import android.content.Context
import kotlinx.serialization.json.Json
import java.io.File

/**
 * 「计划统计表」的本地存储（JSON 文件，纯离线，和课表/排班一样不联网）。
 * 桌面组件的快捷操作与 App 界面都通过它读写，保证两处数据一致。
 */
class PlanStore(context: Context) {

    private val context: Context = context.applicationContext
    private val dir = File(this.context.filesDir, "plans")
    private val file = File(dir, "plans.json")
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun load(): List<PlanItem> {
        if (!file.exists()) return emptyList()
        return runCatching {
            json.decodeFromString(PlanFile.serializer(), file.readText()).items
                .filter { it.title.isNotBlank() }
        }.getOrDefault(emptyList())
    }

    fun save(items: List<PlanItem>) {
        runCatching {
            dir.mkdirs()
            val cleaned = items
                .filter { it.title.isNotBlank() }
                .map { item ->
                    // 强制 id 非空（老数据/手工构造的兜底）
                    if (item.id.isBlank()) item.copy(id = PlanText.newId()) else item
                }
            file.writeText(json.encodeToString(PlanFile.serializer(), PlanFile(cleaned)))
        }
    }

    /** 修改并落盘：返回更新后的完整列表，方便界面/组件立刻重绘。 */
    fun mutate(block: (List<PlanItem>) -> List<PlanItem>): List<PlanItem> {
        val updated = block(load())
        save(updated)
        return updated
    }
}

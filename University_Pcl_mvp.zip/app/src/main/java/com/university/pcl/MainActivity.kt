package com.university.pcl

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.university.pcl.data.CacheStore
import com.university.pcl.data.Prefs
import com.university.pcl.data.ScheduleCache
import com.university.pcl.data.ScheduleRepository
import com.university.pcl.ui.HomeContent
import com.university.pcl.ui.SettingsContent
import com.university.pcl.ui.UniversityPclTheme
import com.university.pcl.widget.WidgetRefreshScheduler
import com.university.pcl.widget.WidgetUpdater
import kotlinx.coroutines.launch
import java.time.LocalDate

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WidgetRefreshScheduler.ensureScheduled(applicationContext)
        setContent {
            UniversityPclTheme {
                AppRoot()
            }
        }
    }
}

@Composable
private fun AppRoot() {
    val context = LocalContext.current
    val prefs = remember { Prefs(context) }
    val repo = remember { ScheduleRepository(context) }
    val scope = rememberCoroutineScope()

    var tab by remember { mutableStateOf(0) }
    var cache by remember { mutableStateOf<ScheduleCache?>(repo.cached()) }
    var loggedIn by remember { mutableStateOf(prefs.isLoggedIn) }
    var week by remember { mutableStateOf(repo.currentWeek()) }
    var term by remember { mutableStateOf(prefs.term) }
    var manualCourses by remember { mutableStateOf(repo.manualCourses()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var lastSync by remember { mutableStateOf(prefs.lastSync) }

    fun refresh() {
        if (loading) return
        scope.launch {
            loading = true
            message = null
            val result = repo.refresh()
            loading = false
            result.onSuccess { updated ->
                cache = updated
                week = updated.week
                term = updated.term
                lastSync = updated.fetchedAt
                loggedIn = true
                message = "已更新（第 ${updated.week} 周）"
                WidgetUpdater.update(context)
            }.onFailure { error ->
                message = error.message ?: "刷新失败"
                loggedIn = prefs.isLoggedIn
            }
        }
    }

    val loginLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            loggedIn = prefs.isLoggedIn
            if (loggedIn) {
                message = "登录成功，正在同步课表…"
                refresh()
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                loading = true
                message = "正在导入课表…"
                val result = repo.importXls(uri)
                loading = false
                result.onSuccess { imported ->
                    cache = imported
                    week = imported.week
                    term = imported.term
                    lastSync = imported.fetchedAt
                    message = "导入成功：${imported.items.size} 条课程（第 ${imported.week} 周）"
                    WidgetUpdater.update(context)
                }.onFailure { error ->
                    message = error.message ?: "导入失败"
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        if (prefs.isLoggedIn) refresh()
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceVariant) {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Text("课") },
                    label = { Text("课表") }
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Text("设") },
                    label = { Text("设置") }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (tab == 0) {
                HomeContent(
                    cache = cache,
                    manualCourses = manualCourses,
                    loggedIn = loggedIn,
                    week = week,
                    semesterStart = prefs.semesterStart,
                    baseUrl = prefs.baseUrl,
                    loading = loading,
                    message = message,
                    lastSync = lastSync,
                    onLogin = {
                        loginLauncher.launch(Intent(context, LoginActivity::class.java))
                    },
                    onRefresh = { refresh() },
                    onAddManual = { name, room, teacher, day, bigSection ->
                        repo.addManualCourse(name, room, teacher, day, bigSection)
                        manualCourses = repo.manualCourses()
                        message = "已添加：$name"
                        scope.launch { WidgetUpdater.update(context) }
                    },
                    onDeleteManual = { id ->
                        repo.removeManualCourse(id)
                        manualCourses = repo.manualCourses()
                        message = "已删除"
                        scope.launch { WidgetUpdater.update(context) }
                    }
                )
            } else {
                SettingsContent(
                    initialUrl = prefs.baseUrl,
                    initialTerm = term,
                    initialWeek = prefs.week,
                    initialStart = prefs.semesterStart,
                    loggedIn = loggedIn,
                    onSave = { url, newTerm, newWeek, semesterStart ->
                        prefs.baseUrl = url
                        prefs.term = newTerm
                        prefs.week = newWeek
                        prefs.semesterStart = semesterStart
                        term = newTerm
                        week = repo.currentWeek()
                        message = "设置已保存"
                        if (prefs.isLoggedIn) {
                            refresh()
                        } else {
                            cache = null
                            lastSync = 0L
                            scope.launch { WidgetUpdater.update(context) }
                        }
                    },
                    onLogin = {
                        loginLauncher.launch(Intent(context, LoginActivity::class.java))
                    },
                    onImport = {
                        importLauncher.launch(
                            arrayOf(
                                "application/vnd.ms-excel",
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                "application/octet-stream",
                                "*/*"
                            )
                        )
                    },
                    onLogout = {
                        prefs.clearSession()
                        CacheStore(context).clear()
                        cache = null
                        lastSync = 0L
                        loggedIn = false
                        message = "已清除登录状态"
                        scope.launch { WidgetUpdater.update(context) }
                    }
                )
            }
        }
    }
}

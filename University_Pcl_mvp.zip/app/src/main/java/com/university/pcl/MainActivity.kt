package com.university.pcl

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.university.pcl.data.DutyScheduler
import com.university.pcl.data.DutyShift
import com.university.pcl.data.FreeTimetable
import com.university.pcl.data.Prefs
import com.university.pcl.data.RosterStore
import com.university.pcl.data.ScheduleCache
import com.university.pcl.data.ScheduleRepository
import com.university.pcl.ui.HomeContent
import com.university.pcl.ui.RosterContent
import com.university.pcl.ui.SettingsContent
import com.university.pcl.ui.UniversityPclTheme
import com.university.pcl.widget.WidgetRefreshScheduler
import com.university.pcl.widget.WidgetUpdater
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WidgetRefreshScheduler.ensureScheduled(applicationContext)
        setContent {
            UniversityPclTheme {
                AppRoot()
            }
        }
    }
}

@Composable
private fun AppRoot() {
    val context = LocalContext.current
    val prefs = remember { Prefs(context) }
    val repo = remember { ScheduleRepository(context) }
    val rosterStore = remember { RosterStore(context) }
    val scope = rememberCoroutineScope()

    val pagerState = rememberPagerState(pageCount = { 3 })
    var cache by remember { mutableStateOf<ScheduleCache?>(repo.cached()) }
    var manualCourses by remember { mutableStateOf(repo.manualCourses()) }
    var week by remember { mutableStateOf(repo.currentWeek()) }
    var autoWeek by remember { mutableStateOf(repo.autoWeek()) }
    var term by remember { mutableStateOf(prefs.term) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var lastSync by remember { mutableStateOf(prefs.lastSync) }

    // 排班（空课表 + 值班表）状态
    var freeTimetable by remember { mutableStateOf<FreeTimetable?>(rosterStore.loadFreeTimetable()) }
    var dutyRoster by remember { mutableStateOf(rosterStore.loadRoster()) }
    var rosterLoading by remember { mutableStateOf(false) }
    var rosterMessage by remember { mutableStateOf<String?>(null) }
    var rosterPerSlot by remember { mutableStateOf(prefs.rosterPerSlot) }
    var rosterAvoidSameDay by remember { mutableStateOf(prefs.rosterAvoidSameDay) }
    var rosterAvoidSameWeek by remember { mutableStateOf(prefs.rosterAvoidSameWeek) }

    fun applyCache(updated: ScheduleCache, successMessage: String) {
        cache = updated
        week = updated.week
        term = updated.term
        lastSync = updated.fetchedAt
        message = successMessage
        scope.launch { WidgetUpdater.update(context) }
    }

    fun reparse() {
        if (loading) return
        scope.launch {
            loading = true
            message = null
            val result = repo.reparseImported()
            loading = false
            result.onSuccess { applyCache(it, "已重新解析：${it.items.size} 条课程") }
                .onFailure { message = it.message ?: "解析失败" }
        }
    }

    fun generateRoster(start: Int, end: Int, need: Int, avoidDay: Boolean, avoidWeek: Boolean) {
        val free = freeTimetable ?: return
        rosterPerSlot = need
        rosterAvoidSameDay = avoidDay
        rosterAvoidSameWeek = avoidWeek
        prefs.rosterPerSlot = need
        prefs.rosterAvoidSameDay = avoidDay
        prefs.rosterAvoidSameWeek = avoidWeek

        val kept = dutyRoster.filterNot { it.week in start..end }
        val fresh = DutyScheduler.generate(free, start, end, need, avoidDay, avoidWeek)
        val merged = (kept + fresh)
            .filter { it.names.isNotEmpty() }
            .sortedWith(compareBy<DutyShift>({ it.week }, { it.day }, { it.bigSection }))
        dutyRoster = merged
        rosterStore.saveRoster(merged)

        val filled = fresh.count { it.names.isNotEmpty() }
        val empty = fresh.count { it.names.isEmpty() }
        rosterMessage = buildString {
            append("已生成第 $start–$end 周：$filled 个时段")
            if (empty > 0) append("；$empty 个时段空课表里没人有空")
        }
    }

    fun editRosterSlot(day: Int, bigSection: Int, names: List<String>) {
        val cleaned = names.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        val kept = dutyRoster.filterNot {
            it.week == week && it.day == day && it.bigSection == bigSection
        }
        val merged = (kept + DutyShift(week, day, bigSection, cleaned))
            .filter { it.names.isNotEmpty() }
            .sortedWith(compareBy<DutyShift>({ it.week }, { it.day }, { it.bigSection }))
        dutyRoster = merged
        rosterStore.saveRoster(merged)
        rosterMessage = if (cleaned.isEmpty()) {
            "已清空该时段"
        } else {
            "第 $week 周已更新：${cleaned.joinToString("、")}"
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                loading = true
                message = "正在导入…"
                val result = repo.importXls(uri)
                loading = false
                result.onSuccess { applyCache(it, "导入成功：${it.items.size} 条课程（第 ${it.week} 周）") }
                    .onFailure { message = it.message ?: "导入失败" }
            }
        }
    }

    val rosterImportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                rosterLoading = true
                rosterMessage = "正在导入空课表…"
                val result = rosterStore.importFreeTimetable(uri)
                rosterLoading = false
                result.onSuccess { table ->
                    freeTimetable = table
                    rosterMessage = buildString {
                        append("已导入空课表：${table.members.size} 人、${table.days.size} 天")
                        if (dutyRoster.isNotEmpty()) append("。空课表已更新，建议重新「自动排班」")
                    }
                }.onFailure { rosterMessage = it.message ?: "空课表导入失败" }
            }
        }
    }

    fun changeWeek(newWeek: Int) {
        prefs.week = newWeek.coerceAtLeast(1)
        week = prefs.week
        autoWeek = repo.autoWeek()
        message = "第 ${prefs.week} 周"
        rosterMessage = null
        scope.launch { WidgetUpdater.update(context) }
    }

    fun resetWeek() {
        prefs.week = 0
        autoWeek = repo.autoWeek()
        week = autoWeek
        message = "已按校历自动算周次（第 $week 周）"
        rosterMessage = null
        scope.launch { WidgetUpdater.update(context) }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceVariant) {
                NavigationBarItem(
                    selected = pagerState.currentPage == 0,
                    onClick = { scope.launch { pagerState.animateScrollToPage(0) } },
                    icon = { Text("课") },
                    label = { Text("课表") }
                )
                NavigationBarItem(
                    selected = pagerState.currentPage == 1,
                    onClick = { scope.launch { pagerState.animateScrollToPage(1) } },
                    icon = { Text("排") },
                    label = { Text("排班") }
                )
                NavigationBarItem(
                    selected = pagerState.currentPage == 2,
                    onClick = { scope.launch { pagerState.animateScrollToPage(2) } },
                    icon = { Text("设") },
                    label = { Text("设置") }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                beyondViewportPageCount = 1
            ) { page ->
                when (page) {
                    0 -> HomeContent(
                        cache = cache,
                        manualCourses = manualCourses,
                        week = week,
                        autoWeek = autoWeek,
                        loading = loading,
                        message = message,
                        lastSync = lastSync,
                        onRefresh = { reparse() },
                        onWeekChange = { changeWeek(it) },
                        onWeekReset = { resetWeek() },
                        onAddManual = { name, room, teacher, day, bigSection ->
                            repo.addManualCourse(name, room, teacher, day, bigSection)
                            manualCourses = repo.manualCourses()
                            message = "已添加：$name"
                            scope.launch { WidgetUpdater.update(context) }
                        },
                        onDeleteManual = { id ->
                            repo.removeManualCourse(id)
                            manualCourses = repo.manualCourses()
                            message = "已删除"
                            scope.launch { WidgetUpdater.update(context) }
                        }
                    )

                    1 -> RosterContent(
                        free = freeTimetable,
                        roster = dutyRoster,
                        week = week,
                        autoWeek = autoWeek,
                        perSlot = rosterPerSlot,
                        avoidSameDay = rosterAvoidSameDay,
                        avoidSameWeek = rosterAvoidSameWeek,
                        message = rosterMessage,
                        onWeekChange = { changeWeek(it) },
                        onWeekReset = { resetWeek() },
                        onGenerate = { start, end, need, avoidDay, avoidWeek ->
                            generateRoster(start, end, need, avoidDay, avoidWeek)
                        },
                        onEditSlot = { day, bigSection, names -> editRosterSlot(day, bigSection, names) },
                        onOpenSettings = { scope.launch { pagerState.animateScrollToPage(2) } },
                        onClearWeek = {
                            val remaining = dutyRoster.filterNot { it.week == week }
                            dutyRoster = remaining
                            rosterStore.saveRoster(remaining)
                            rosterMessage = "已清空第 $week 周排班"
                        }
                    )

                    else -> SettingsContent(
                        initialTerm = term,
                        initialWeek = prefs.week,
                        initialStart = prefs.semesterStart,
                        freeTimetable = freeTimetable,
                        rosterLoading = rosterLoading,
                        onImportRoster = {
                            rosterImportLauncher.launch(
                                arrayOf(
                                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                    "application/vnd.ms-excel",
                                    "application/octet-stream",
                                    "*/*"
                                )
                            )
                        },
                        onSave = { newTerm, newWeek, semesterStart ->
                            prefs.term = newTerm
                            prefs.week = newWeek
                            prefs.semesterStart = semesterStart
                            term = newTerm
                            autoWeek = repo.autoWeek()
                            week = repo.currentWeek()
                            message = "设置已保存"
                        },
                        onImport = {
                            importLauncher.launch(
                                arrayOf(
                                    "application/vnd.ms-excel",
                                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                    "application/octet-stream",
                                    "*/*"
                                )
                            )
                        }
                    )
                }
            }
        }
    }
}

package com.university.pcl

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.university.pcl.data.Prefs
import com.university.pcl.data.ScheduleCache
import com.university.pcl.data.ScheduleRepository
import com.university.pcl.ui.HomeContent
import com.university.pcl.ui.SettingsContent
import com.university.pcl.ui.UniversityPclTheme
import com.university.pcl.widget.WidgetRefreshScheduler
import com.university.pcl.widget.WidgetUpdater
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WidgetRefreshScheduler.ensureScheduled(applicationContext)
        setContent {
            UniversityPclTheme {
                AppRoot()
            }
        }
    }
}

@Composable
private fun AppRoot() {
    val context = LocalContext.current
    val prefs = remember { Prefs(context) }
    val repo = remember { ScheduleRepository(context) }
    val scope = rememberCoroutineScope()

    var tab by remember { mutableStateOf(0) }
    var cache by remember { mutableStateOf<ScheduleCache?>(repo.cached()) }
    var manualCourses by remember { mutableStateOf(repo.manualCourses()) }
    var week by remember { mutableStateOf(repo.currentWeek()) }
    var autoWeek by remember { mutableStateOf(repo.autoWeek()) }
    var term by remember { mutableStateOf(prefs.term) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var lastSync by remember { mutableStateOf(prefs.lastSync) }

    fun applyCache(updated: ScheduleCache, successMessage: String) {
        cache = updated
        week = updated.week
        term = updated.term
        lastSync = updated.fetchedAt
        message = successMessage
        scope.launch { WidgetUpdater.update(context) }
    }

    fun reparse() {
        if (loading) return
        scope.launch {
            loading = true
            message = null
            val result = repo.reparseImported()
            loading = false
            result.onSuccess { applyCache(it, "已重新解析：${it.items.size} 条课程") }
                .onFailure { message = it.message ?: "解析失败" }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                loading = true
                message = "正在导入…"
                val result = repo.importXls(uri)
                loading = false
                result.onSuccess { applyCache(it, "导入成功：${it.items.size} 条课程（第 ${it.week} 周）") }
                    .onFailure { message = it.message ?: "导入失败" }
            }
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceVariant) {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Text("课") },
                    label = { Text("课表") }
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Text("设") },
                    label = { Text("设置") }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = tab,
                transitionSpec = {
                    val forward = tab == 1
                    val slideSpec = tween<androidx.compose.ui.unit.IntOffset>(260)
                    val fadeSpec = tween<Float>(200)
                    if (forward) {
                        (slideInHorizontally(animationSpec = slideSpec) { it } + fadeIn(fadeSpec)) togetherWith
                            (slideOutHorizontally(animationSpec = slideSpec) { -it } + fadeOut(fadeSpec))
                    } else {
                        (slideInHorizontally(animationSpec = slideSpec) { -it } + fadeIn(fadeSpec)) togetherWith
                            (slideOutHorizontally(animationSpec = slideSpec) { it } + fadeOut(fadeSpec))
                    }
                },
                label = "tab"
            ) { targetTab ->
                if (targetTab == 0) {
                HomeContent(
                    cache = cache,
                    manualCourses = manualCourses,
                    week = week,
                    autoWeek = autoWeek,
                    loading = loading,
                    message = message,
                    lastSync = lastSync,
                    onRefresh = { reparse() },
                    onWeekChange = { newWeek ->
                        prefs.week = newWeek.coerceAtLeast(1)
                        week = prefs.week
                        autoWeek = repo.autoWeek()
                        message = "第 ${prefs.week} 周"
                        scope.launch { WidgetUpdater.update(context) }
                    },
                    onWeekReset = {
                        prefs.week = 0
                        autoWeek = repo.autoWeek()
                        week = autoWeek
                        message = "已按校历自动算周次（第 $week 周）"
                        scope.launch { WidgetUpdater.update(context) }
                    },
                    onAddManual = { name, room, teacher, day, bigSection ->
                        repo.addManualCourse(name, room, teacher, day, bigSection)
                        manualCourses = repo.manualCourses()
                        message = "已添加：$name"
                        scope.launch { WidgetUpdater.update(context) }
                    },
                    onDeleteManual = { id ->
                        repo.removeManualCourse(id)
                        manualCourses = repo.manualCourses()
                        message = "已删除"
                        scope.launch { WidgetUpdater.update(context) }
                    }
                )
                } else {
                SettingsContent(
                    initialTerm = term,
                    initialWeek = prefs.week,
                    initialStart = prefs.semesterStart,
                    onSave = { newTerm, newWeek, semesterStart ->
                        prefs.term = newTerm
                        prefs.week = newWeek
                        prefs.semesterStart = semesterStart
                        term = newTerm
                        autoWeek = repo.autoWeek()
                        week = repo.currentWeek()
                        message = "设置已保存"
                    },
                    onImport = {
                        importLauncher.launch(
                            arrayOf(
                                "application/vnd.ms-excel",
                                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                "application/octet-stream",
                                "*/*"
                            )
                        )
                    }
                )
                }
            }
        }
    }
}

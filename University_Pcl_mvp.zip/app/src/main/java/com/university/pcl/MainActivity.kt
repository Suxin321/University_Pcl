package com.university.pcl

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import com.university.pcl.data.BigSections
import com.university.pcl.data.DutyScheduler
import com.university.pcl.data.DutyShift
import com.university.pcl.data.FreeTableEditor
import com.university.pcl.data.FreeTimetable
import com.university.pcl.data.FreeTimetableParser
import com.university.pcl.data.Prefs
import com.university.pcl.data.RosterRequest
import com.university.pcl.data.RosterStore
import com.university.pcl.data.RosterXlsxExporter
import com.university.pcl.data.ScheduleCache
import com.university.pcl.data.ScheduleRepository
import com.university.pcl.ui.HomeContent
import com.university.pcl.ui.RosterContent
import com.university.pcl.ui.SettingsContent
import com.university.pcl.ui.UniversityPclTheme
import com.university.pcl.widget.WidgetRefreshScheduler
import com.university.pcl.widget.WidgetUpdater
import kotlinx.coroutines.launch
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WidgetRefreshScheduler.ensureScheduled(applicationContext)
        setContent {
            UniversityPclTheme {
                AppRoot()
            }
        }
    }
}

@Composable
private fun AppRoot() {
    val context = LocalContext.current
    val prefs = remember { Prefs(context) }
    val repo = remember { ScheduleRepository(context) }
    val rosterStore = remember { RosterStore(context) }
    val scope = rememberCoroutineScope()

    val pagerState = rememberPagerState(pageCount = { 3 })
    var cache by remember { mutableStateOf<ScheduleCache?>(repo.cached()) }
    var manualCourses by remember { mutableStateOf(repo.manualCourses()) }
    var week by remember { mutableStateOf(repo.currentWeek()) }
    var autoWeek by remember { mutableStateOf(repo.autoWeek()) }
    var term by remember { mutableStateOf(prefs.term) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var lastSync by remember { mutableStateOf(prefs.lastSync) }

    // 排班（空课表 + 值班表）状态
    var freeTimetable by remember { mutableStateOf<FreeTimetable?>(rosterStore.loadFreeTimetable()) }
    var dutyRoster by remember { mutableStateOf(rosterStore.loadRoster()) }
    var rosterLoading by remember { mutableStateOf(false) }
    var rosterMessage by remember { mutableStateOf<String?>(null) }
    var rosterPerSlot by remember { mutableStateOf(prefs.rosterPerSlot) }
    var rosterAvoidSameDay by remember { mutableStateOf(prefs.rosterAvoidSameDay) }
    var rosterAvoidSameWeek by remember { mutableStateOf(prefs.rosterAvoidSameWeek) }
    var rosterSections by remember { mutableStateOf(prefs.rosterSections) }
    var rosterSlotTimes by remember { mutableStateOf(prefs.rosterSlotTimes) }
    var rosterMembers by remember { mutableStateOf(prefs.rosterMembers) }
    var rosterDays by remember { mutableStateOf(prefs.rosterDays) }
    var rosterAllowRepeat by remember { mutableStateOf(prefs.rosterAllowRepeat) }
    var rosterAdjust by remember { mutableStateOf(prefs.rosterAdjust) }

    fun applyCache(updated: ScheduleCache, successMessage: String) {
        cache = updated
        week = updated.week
        term = updated.term
        lastSync = updated.fetchedAt
        message = successMessage
        scope.launch { WidgetUpdater.update(context) }
    }

    fun reparse() {
        if (loading) return
        scope.launch {
            loading = true
            message = null
            val result = repo.reparseImported()
            loading = false
            result.onSuccess { applyCache(it, "已重新解析：${it.items.size} 条课程") }
                .onFailure { message = it.message ?: "解析失败" }
        }
    }

    fun generateRoster(request: RosterRequest) {
        val free = freeTimetable ?: return
        rosterPerSlot = request.perSlot
        rosterAvoidSameDay = request.avoidSameDay
        rosterAvoidSameWeek = request.avoidSameWeek
        rosterSections = request.sections.ifEmpty { (1..BigSections.COUNT).toList() }
        rosterMembers = request.members.filter { it in free.members }
        rosterDays = request.days.filter { it in free.days }
        rosterAllowRepeat = request.allowRepeat
        prefs.rosterPerSlot = request.perSlot
        prefs.rosterAvoidSameDay = request.avoidSameDay
        prefs.rosterAvoidSameWeek = request.avoidSameWeek
        prefs.rosterSections = rosterSections
        prefs.rosterMembers = rosterMembers
        prefs.rosterDays = rosterDays
        prefs.rosterAllowRepeat = request.allowRepeat

        val kept = dutyRoster.filterNot { it.week in request.startWeek..request.endWeek }
        val fresh = DutyScheduler.generate(free, request)
        val merged = (kept + fresh)
            .filter { it.names.isNotEmpty() }
            .sortedWith(compareBy<DutyShift>({ it.week }, { it.day }, { it.bigSection }))
        dutyRoster = merged
        rosterStore.saveRoster(merged)

        val dayList = request.days.filter { it in free.days }.distinct().sorted()
            .ifEmpty { free.days }
        val sectionList = request.sections.filter { it in 1..BigSections.COUNT }.distinct().sorted()
            .ifEmpty { (1..BigSections.COUNT).toList() }
        val memberSet = request.members.filter { it in free.members }.toSet()
        var full = 0
        var short = 0
        var noOneFree = 0
        for (w in request.startWeek..request.endWeek) {
            for (d in dayList) {
                for (b in sectionList) {
                    val eligible = free.freeNames(d, b, w)
                        .filter { memberSet.isEmpty() || it in memberSet }
                    val got = fresh.firstOrNull { it.week == w && it.day == d && it.bigSection == b }
                        ?.names?.size ?: 0
                    when {
                        eligible.isEmpty() -> noOneFree++
                        got >= request.perSlot -> full++
                        else -> short++
                    }
                }
            }
        }
        rosterMessage = buildString {
            append("已生成第 ${request.startWeek}–${request.endWeek} 周：$full 个时段排满")
            if (short > 0) append("，$short 个因不重复限制留空")
            if (noOneFree > 0) append("，$noOneFree 个时段没人有空")
        }
    }

    fun setAdjust(name: String, delta: Int) {
        val updated = rosterAdjust.toMutableMap()
        if (delta == 0) updated.remove(name) else updated[name] = delta.coerceIn(-99, 99)
        rosterAdjust = updated
        prefs.rosterAdjust = updated
    }

    fun saveMember(name: String, slotWeeksText: Map<Pair<Int, Int>, String>) {
        val free = freeTimetable ?: return
        val clean = name.trim()
        if (clean.isEmpty()) { rosterMessage = "成员姓名不能为空"; return }
        if (slotWeeksText.isEmpty()) { rosterMessage = "至少勾一个时段"; return }
        val slots = slotWeeksText.mapValues { (_, text) ->
            val (allWeeks, weeks) = FreeTimetableParser.parseWeekSpec(text)
            FreeTableEditor.SlotWeeks(allWeeks, weeks)
        }
        val updated = FreeTableEditor.setMemberSlots(free, clean, slots)
        freeTimetable = updated
        rosterStore.saveFreeTimetable(updated)
        rosterMessage = "已保存成员：$clean"
    }

    fun deleteMember(name: String) {
        val free = freeTimetable ?: return
        val updated = FreeTableEditor.removeMember(free, name)
        freeTimetable = updated
        rosterStore.saveFreeTimetable(updated)
        rosterMessage = "已删除成员：$name"
    }

    fun batchAdjust(names: List<String>, mode: String, value: Int) {
        if (names.isEmpty()) return
        val amount = value.coerceIn(0, 99)
        val updated = rosterAdjust.toMutableMap()
        names.forEach { name ->
            val current = updated[name] ?: 0
            val next = when (mode) {
                "plus" -> current + amount
                "minus" -> current - amount
                else -> amount
            }.coerceIn(-99, 99)
            if (next == 0) updated.remove(name) else updated[name] = next
        }
        rosterAdjust = updated
        prefs.rosterAdjust = updated
        val label = when (mode) {
            "plus" -> "+$amount"
            "minus" -> "-$amount"
            else -> "设为 $amount"
        }
        rosterMessage = "已批量调整 ${names.size} 人（$label）"
    }

    fun exportRosterXlsx(startWeek: Int, endWeek: Int) {
        val free = freeTimetable ?: return
        val memberList = if (rosterMembers.isEmpty()) free.members else
            free.members.filter { it in rosterMembers }.ifEmpty { free.members }
        runCatching {
            val bytes = RosterXlsxExporter.buildRoster(
                shifts = dutyRoster,
                startWeek = startWeek,
                endWeek = endWeek,
                // 导出表格固定 周一~周日 × 5 大节，没排的格子留空，不隐藏
                days = (1..7).toList(),
                sections = (1..BigSections.COUNT).toList(),
                slotTimes = rosterSlotTimes,
                members = memberList,
                adjust = rosterAdjust
            )
            val dir = File(context.cacheDir, "exports").apply { mkdirs() }
            val file = File(dir, RosterXlsxExporter.fileName(startWeek, endWeek))
            file.writeBytes(bytes)
            val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(send, "导出值班表"))
            rosterMessage = "已生成：${file.name}"
        }.onFailure { rosterMessage = it.message ?: "导出失败" }
    }

    fun resetAllRoster(clearAdjust: Boolean) {
        dutyRoster = emptyList()
        rosterStore.saveRoster(emptyList())
        if (clearAdjust) {
            rosterAdjust = emptyMap()
            prefs.rosterAdjust = emptyMap()
            rosterMessage = "已重置全部排班和手动调整"
        } else {
            rosterMessage = "已重置全部排班"
        }
    }

    fun editRosterSlot(day: Int, bigSection: Int, names: List<String>) {
        val cleaned = names.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        val kept = dutyRoster.filterNot {
            it.week == week && it.day == day && it.bigSection == bigSection
        }
        val merged = (kept + DutyShift(week, day, bigSection, cleaned))
            .filter { it.names.isNotEmpty() }
            .sortedWith(compareBy<DutyShift>({ it.week }, { it.day }, { it.bigSection }))
        dutyRoster = merged
        rosterStore.saveRoster(merged)
        rosterMessage = if (cleaned.isEmpty()) {
            "已清空该时段"
        } else {
            "第 $week 周已更新：${cleaned.joinToString("、")}"
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                loading = true
                message = "正在导入…"
                val result = repo.importXls(uri)
                loading = false
                result.onSuccess { applyCache(it, "导入成功：${it.items.size} 条课程（第 ${it.week} 周）") }
                    .onFailure { message = it.message ?: "导入失败" }
            }
        }
    }

    val rosterImportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                rosterLoading = true
                rosterMessage = "正在导入空课表…"
                val result = rosterStore.importFreeTimetable(uri)
                rosterLoading = false
                result.onSuccess { table ->
                    freeTimetable = table
                    rosterMessage = buildString {
                        append("已导入空课表：${table.members.size} 人、${table.days.size} 天")
                        if (dutyRoster.isNotEmpty()) append("。空课表已更新，建议重新「自动排班」")
                    }
                }.onFailure { rosterMessage = it.message ?: "空课表导入失败" }
            }
        }
    }

    fun changeWeek(newWeek: Int) {
        prefs.week = newWeek.coerceAtLeast(1)
        week = prefs.week
        autoWeek = repo.autoWeek()
        message = "第 ${prefs.week} 周"
        rosterMessage = null
        scope.launch { WidgetUpdater.update(context) }
    }

    fun resetWeek() {
        prefs.week = 0
        autoWeek = repo.autoWeek()
        week = autoWeek
        message = "已按校历自动算周次（第 $week 周）"
        rosterMessage = null
        scope.launch { WidgetUpdater.update(context) }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceVariant) {
                NavigationBarItem(
                    selected = pagerState.currentPage == 0,
                    onClick = { scope.launch { pagerState.animateScrollToPage(0) } },
                    icon = { Text("课") },
                    label = { Text("课表") }
                )
                NavigationBarItem(
                    selected = pagerState.currentPage == 1,
                    onClick = { scope.launch { pagerState.animateScrollToPage(1) } },
                    icon = { Text("排") },
                    label = { Text("排班") }
                )
                NavigationBarItem(
                    selected = pagerState.currentPage == 2,
                    onClick = { scope.launch { pagerState.animateScrollToPage(2) } },
                    icon = { Text("设") },
                    label = { Text("设置") }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            HorizontalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                beyondViewportPageCount = 1
            ) { page ->
                when (page) {
                    0 -> HomeContent(
                        cache = cache,
                        manualCourses = manualCourses,
                        week = week,
                        autoWeek = autoWeek,
                        loading = loading,
                        message = message,
                        lastSync = lastSync,
                        onRefresh = { reparse() },
                        onWeekChange = { changeWeek(it) },
                        onWeekReset = { resetWeek() },
                        onAddManual = { name, room, teacher, day, bigSection ->
                            repo.addManualCourse(name, room, teacher, day, bigSection)
                            manualCourses = repo.manualCourses()
                            message = "已添加：$name"
                            scope.launch { WidgetUpdater.update(context) }
                        },
                        onDeleteManual = { id ->
                            repo.removeManualCourse(id)
                            manualCourses = repo.manualCourses()
                            message = "已删除"
                            scope.launch { WidgetUpdater.update(context) }
                        }
                    )

                    1 -> RosterContent(
                        free = freeTimetable,
                        roster = dutyRoster,
                        week = week,
                        autoWeek = autoWeek,
                        perSlot = rosterPerSlot,
                        avoidSameDay = rosterAvoidSameDay,
                        avoidSameWeek = rosterAvoidSameWeek,
                        sections = rosterSections,
                        slotTimes = rosterSlotTimes,
                        members = rosterMembers,
                        days = rosterDays,
                        allowRepeat = rosterAllowRepeat,
                        adjust = rosterAdjust,
                        message = rosterMessage,
                        onWeekChange = { changeWeek(it) },
                        onWeekReset = { resetWeek() },
                        onGenerate = { request -> generateRoster(request) },
                        onEditSlot = { day, bigSection, names -> editRosterSlot(day, bigSection, names) },
                        onExportXlsx = { startWeek, endWeek -> exportRosterXlsx(startWeek, endWeek) },
                        onSetAdjust = { name, delta -> setAdjust(name, delta) },
                        onBatchAdjust = { names, mode, value -> batchAdjust(names, mode, value) },
                        onResetAll = { clearAdjust -> resetAllRoster(clearAdjust) },
                        onOpenSettings = { scope.launch { pagerState.animateScrollToPage(2) } },
                        onClearWeek = {
                            val remaining = dutyRoster.filterNot { it.week == week }
                            dutyRoster = remaining
                            rosterStore.saveRoster(remaining)
                            rosterMessage = "已清空第 $week 周排班"
                        }
                    )

                    else -> SettingsContent(
                        initialTerm = term,
                        initialWeek = prefs.week,
                        initialStart = prefs.semesterStart,
                        freeTimetable = freeTimetable,
                        rosterLoading = rosterLoading,
                        slotTimes = rosterSlotTimes,
                        courseCount = cache?.items?.size ?: 0,
                        lastSync = lastSync,
                        isActive = pagerState.currentPage == 2,
                        onSaveSlotTimes = { times ->
                            rosterSlotTimes = times
                            prefs.rosterSlotTimes = times
                            rosterSlotTimes = prefs.rosterSlotTimes
                            rosterMessage = "值班时段已保存"
                        },
                        onSaveMember = { name, slotWeeksText ->
                            saveMember(name, slotWeeksText)
                        },
                        onDeleteMember = { name -> deleteMember(name) },
                        onImportRoster = {
                            rosterImportLauncher.launch(
                                arrayOf(
                                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                    "application/vnd.ms-excel",
                                    "application/octet-stream",
                                    "*/*"
                                )
                            )
                        },
                        onSave = { newTerm, newWeek, semesterStart ->
                            prefs.term = newTerm
                            prefs.week = newWeek
                            prefs.semesterStart = semesterStart
                            term = newTerm
                            autoWeek = repo.autoWeek()
                            week = repo.currentWeek()
                            message = "设置已保存"
                        },
                        onImport = {
                            importLauncher.launch(
                                arrayOf(
                                    "application/vnd.ms-excel",
                                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                    "application/octet-stream",
                                    "*/*"
                                )
                            )
                        }
                    )
                }
            }
        }
    }
}

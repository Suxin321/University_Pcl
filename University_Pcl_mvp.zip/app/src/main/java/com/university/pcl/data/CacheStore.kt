package com.university.pcl.data

import android.content.Context
import kotlinx.serialization.json.Json
import java.io.File

/** 课表缓存（JSON 文件），组件与 App 共用。 */
class CacheStore(context: Context) {

    private val dir = File(context.applicationContext.filesDir, "schedule")
    private val file = File(dir, "cache.json")
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun load(): ScheduleCache? {
        if (!file.exists()) return null
        return runCatching {
            json.decodeFromString(ScheduleCache.serializer(), file.readText())
        }.getOrNull()
    }

    fun save(cache: ScheduleCache) {
        runCatching {
            dir.mkdirs()
            file.writeText(json.encodeToString(ScheduleCache.serializer(), cache))
        }
    }

    fun clear() {
        runCatching { if (file.exists()) file.delete() }
    }
}

package com.university.pcl

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.university.pcl.data.Prefs
import com.university.pcl.data.ScheduleRepository
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.json.JSONTokener

/**
 * 自动获取课表：
 * 1. 打开「学期理论课表」页面（优先用设置里粘贴的地址 / 自动从教务主页菜单里找）；
 * 2. 页面跨 iframe 扫描「导出」按钮并自动点击；
 * 3. 拦截下载/导出请求 -> 用 Cookie 下载 .xls -> 解析 -> 替换缓存；
 * 4. 从页面读学期/周次，自动校准「第几周」。
 */
class AutoExportActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var webView: WebView
    private lateinit var status: TextView
    private var captured = false
    private var started = false
    private var rounds = 0

    private val exportRegex = Regex("""(?i)(\.xls|daochu|daochu_|export|excel|kbdow|kbdoc)""")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        CookieManager.getInstance().setAcceptCookie(true)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val hint = TextView(this).apply {
            text = "正在打开「学期理论课表」。App 会自动点「导出」并接住下载；找不到时可在设置里粘贴课表页地址。"
            textSize = 12f
            setPadding(28, 28, 28, 10)
        }
        status = TextView(this).apply {
            text = "准备中…"
            textSize = 11f
            setTextColor(Color.parseColor("#3482FF"))
            setPadding(28, 0, 28, 10)
        }
        webView = WebView(this)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        val retry = Button(this).apply {
            text = "重新尝试"
            setOnClickListener {
                captured = false
                rounds = 0
                setStatus("重新尝试…")
                startLoad()
            }
        }

        root.addView(hint)
        root.addView(status)
        root.addView(
            webView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        root.addView(retry)
        setContentView(root)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = true
            displayZoomControls = false
            userAgentString =
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
        }
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                request?.url?.toString()?.let { noteRequest(it) }
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                request?.url?.toString()?.let { noteRequest(it) }
                return false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.postDelayed({ inspectPage() }, 1400)
            }
        }
        webView.setDownloadListener { url, _, _, _, _ ->
            if (url.startsWith("blob:")) {
                setStatus("导出是前端生成的（blob），抓不到文件。请把这句话发我，我换方案。")
                return@setDownloadListener
            }
            capture(url)
        }

        startLoad()
    }

    private fun startLoad() {
        val theory = prefs.theoryUrl
        if (theory.isNotBlank()) {
            load(theory)
        } else {
            setStatus("正在从教务主页找「学期理论课表」入口…")
            Thread {
                val found = runCatching {
                    ScheduleRepository(applicationContext).findTheoryPageUrl()
                }.getOrNull()
                runOnUiThread {
                    if (found != null) {
                        prefs.theoryUrl = found
                        load(found)
                    } else {
                        load(prefs.baseUrl + "/jsxsd/framework/xsMainV.htmlx")
                    }
                }
            }.start()
        }
    }

    private fun load(url: String) {
        started = true
        setStatus("打开：$url")
        webView.loadUrl(url)
    }

    private fun inspectPage() {
        webView.evaluateJavascript(JS_PROBE) { raw ->
            val text = runCatching { JSONTokener(raw).nextValue() as? String }.getOrNull()
            val json = runCatching { JSONObject(text ?: return@evaluateJavascript) }.getOrNull()
                ?: return@evaluateJavascript
            applyPageInfo(json)

            val exportCount = json.optInt("exportCount", 0)
            val hasTheoryLink = json.optBoolean("hasTheoryLink", false)
            if (exportCount > 0) {
                setStatus("找到「导出」按钮，点击中…")
                webView.evaluateJavascript(JS_CLICK_EXPORT) { }
                webView.postDelayed({ webView.evaluateJavascript(JS_CLICK_CONFIRM) { } }, 1500)
            } else if (hasTheoryLink && rounds < 2) {
                rounds++
                setStatus("当前是菜单页，尝试点进「学期理论课表」…")
                webView.evaluateJavascript(JS_CLICK_THEORY) { }
                webView.postDelayed({ inspectPage() }, 1800)
            } else if (rounds < 1 && prefs.theoryUrl.isBlank()) {
                rounds++
                setStatus("没找到导出按钮，尝试从主页菜单再进一次…")
                webView.evaluateJavascript(JS_CLICK_THEORY) { }
                webView.postDelayed({ inspectPage() }, 1800)
            } else {
                setStatus(
                    "没找到「导出」。当前页面：${json.optString("title")}\n" +
                        "地址：${json.optString("url")}\n" +
                        "把这段地址发我，或在设置里粘贴「学期理论课表」页面地址后重试。"
                )
            }
        }
    }

    private fun applyPageInfo(json: JSONObject) {
        val parts = ArrayList<String>()
        parts += "页面：${json.optString("title")}"
        val term = json.optString("term", "")
        if (term.isNotBlank()) {
            prefs.term = term
            parts += "学期：$term"
        }
        val week = json.optString("zc", "").toIntOrNull()
            ?: json.optString("weekText", "").toIntOrNull()
        if (week != null && week in 1..30) {
            prefs.week = week
            parts += "第 $week 周"
        }
        setStatus(parts.joinToString(" | "))
    }

    private fun noteRequest(url: String) {
        if (captured || !started) return
        if (url.startsWith("data:") || url.startsWith("blob:")) return
        if (url.contains(".css") || url.contains(".js")) return
        if (!exportRegex.containsMatchIn(url)) return
        capture(url)
    }

    private fun capture(url: String) {
        if (captured) return
        captured = true
        setStatus("捕获导出地址，下载解析中…\n$url")
        val cookie = CookieManager.getInstance().getCookie(prefs.baseUrl).orEmpty()
        if (cookie.isNotBlank()) prefs.cookies = cookie
        Thread {
            val result = runBlocking {
                ScheduleRepository(applicationContext).downloadXlsFromUrl(url)
            }
            runOnUiThread {
                result.onSuccess { cache ->
                    Toast.makeText(this, "自动获取成功：${cache.items.size} 条课程（第 ${cache.week} 周）", Toast.LENGTH_LONG).show()
                    setResult(RESULT_OK)
                    finish()
                }.onFailure { error ->
                    setStatus("下载/解析失败：${error.message}\n可手动点「导出」再试，或把地址发我。")
                    captured = false
                }
            }
        }.start()
    }

    private fun setStatus(text: String) {
        status.text = text
    }

    override fun onPause() {
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onDestroy() {
        runCatching {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }

    companion object {
        private const val JS_PROBE = """(function(){
try{
  function docs(){var out=[];function walk(w){try{out.push(w.document);for(var i=0;i<w.frames.length;i++)walk(w.frames[i]);}catch(e){}}walk(window);return out;}
  var ds=docs();
  var out={title:document.title||'',url:location.href||'',frames:ds.length,exportCount:0,hasTheoryLink:false,zc:'',term:'',weekText:''};
  ds.forEach(function(d){
    var zc=d.querySelector('select[name=zc]');
    if(zc&&zc.selectedIndex>=0&&zc.options[zc.selectedIndex]&&!out.zc){out.zc=zc.options[zc.selectedIndex].value;}
    var t=d.querySelector('select[name=xnxq01id]');
    if(t&&t.selectedIndex>=0&&t.options[t.selectedIndex]&&!out.term){out.term=t.options[t.selectedIndex].value;}
    var body=d.body?d.body.innerText:'';
    var m=body.match(/第\s*(\d{1,2})\s*周/); if(m&&!out.weekText){out.weekText=m[1];}
    var els=[].slice.call(d.querySelectorAll('a,button,span,div,li,td'));
    els.forEach(function(e){var s=(e.innerText||'').trim();
      if(s==='导出'||s==='导出课表'||(s.length<8&&/导出/.test(s))){out.exportCount++;}
      if(/学期理论课表/.test(s)){out.hasTheoryLink=true;}
    });
  });
  return JSON.stringify(out);
}catch(e){return JSON.stringify({title:'',url:'',exportCount:0,hasTheoryLink:false});}
})()"""
        private const val JS_CLICK_EXPORT = """(function(){
try{
  function docs(){var out=[];function walk(w){try{out.push(w.document);for(var i=0;i<w.frames.length;i++)walk(w.frames[i]);}catch(e){}}walk(window);return out;}
  var all=[];docs().forEach(function(d){all=all.concat([].slice.call(d.querySelectorAll('a,button,span,div,li,td')));});
  var ex=all.filter(function(e){var s=(e.innerText||'').trim();return s==='导出'||s==='导出课表'||(s.length<8&&/导出/.test(s));});
  if(ex.length){ex[ex.length-1].click();return 'ok';}return 'none';
}catch(e){return 'err';}
})()"""
        private const val JS_CLICK_CONFIRM = """(function(){
try{
  function docs(){var out=[];function walk(w){try{out.push(w.document);for(var i=0;i<w.frames.length;i++)walk(w.frames[i]);}catch(e){}}walk(window);return out;}
  var all=[];docs().forEach(function(d){all=all.concat([].slice.call(d.querySelectorAll('button,a,span,div')));});
  var ok=all.filter(function(e){var s=(e.innerText||'').trim();return s==='确定'||s==='确认';});
  if(ok.length){ok[ok.length-1].click();return 'ok';}return 'none';
}catch(e){return 'err';}
})()"""
        private const val JS_CLICK_THEORY = """(function(){
try{
  function docs(){var out=[];function walk(w){try{out.push(w.document);for(var i=0;i<w.frames.length;i++)walk(w.frames[i]);}catch(e){}}walk(window);return out;}
  var all=[];docs().forEach(function(d){all=all.concat([].slice.call(d.querySelectorAll('a,button,span,div,li,td')));});
  var th=all.filter(function(e){return /学期理论课表/.test((e.innerText||'').trim());});
  if(th.length){th[0].click();return 'ok';}return 'none';
}catch(e){return 'err';}
})()"""
    }
}

package com.university.pcl

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.university.pcl.data.Prefs
import com.university.pcl.data.ScheduleRepository
import kotlinx.coroutines.runBlocking

/**
 * 自动获取课表：打开课表页后自动点「导出」，捕获下载地址 -> 下载 .xls -> 解析 -> 替换缓存。
 * 捕获到的地址会保存，之后「刷新」可以直接自动下载，不再打开网页。
 */
class AutoExportActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var webView: WebView
    private lateinit var status: TextView
    private var captured = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        CookieManager.getInstance().setAcceptCookie(true)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val hint = TextView(this).apply {
            text = "已打开课表页。App 会自动点右上角「导出」；如果没反应，你手动点一下「导出」，下载会自动被接管。"
            textSize = 12f
            setPadding(28, 28, 28, 10)
        }
        status = TextView(this).apply {
            text = "准备中…"
            textSize = 12f
            setTextColor(Color.parseColor("#3482FF"))
            setPadding(28, 0, 28, 10)
        }
        webView = WebView(this)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        val retry = Button(this).apply {
            text = "自动点「导出」"
            setOnClickListener { clickExport() }
        }

        root.addView(hint)
        root.addView(status)
        root.addView(
            webView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        root.addView(retry)
        setContentView(root)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = userAgentString.replace("; wv", "")
        }
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean = false

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                status.text = "页面已加载，尝试自动导出…"
                view?.postDelayed({ clickExport() }, 1500)
            }
        }
        webView.setDownloadListener { url, _, _, _, _ ->
            if (captured) return@setDownloadListener
            captured = true
            status.text = "捕获到下载地址，正在解析…"
            downloadAndParse(url)
        }

        webView.loadUrl(prefs.baseUrl + "/jsxsd/xskb/xskb_list.do")
    }

    private fun clickExport() {
        webView.evaluateJavascript(JS_CLICK_EXPORT) { result ->
            status.text = "自动点击结果：$result"
        }
        webView.postDelayed({
            webView.evaluateJavascript(JS_CLICK_CONFIRM) { }
        }, 1600)
    }

    private fun downloadAndParse(url: String) {
        val cookie = CookieManager.getInstance().getCookie(prefs.baseUrl).orEmpty()
        if (cookie.isNotBlank()) prefs.cookies = cookie
        Thread {
            val result = runBlocking {
                ScheduleRepository(applicationContext).downloadXlsFromUrl(url)
            }
            runOnUiThread {
                result.onSuccess { cache ->
                    Toast.makeText(this, "自动获取成功：${cache.items.size} 条课程", Toast.LENGTH_LONG).show()
                    setResult(RESULT_OK)
                    finish()
                }.onFailure { error ->
                    status.text = "失败：${error.message}\n（可以手动点「导出」再试一次）"
                    captured = false
                }
            }
        }.start()
    }

    override fun onPause() {
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onDestroy() {
        runCatching {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }

    companion object {
        private const val JS_CLICK_EXPORT = """(function(){try{var all=Array.prototype.slice.call(document.querySelectorAll('a,button,span,div,li'));var c=all.filter(function(e){var t=(e.innerText||'').trim();return t==='导出'||t==='导出课表';});if(c.length){c[c.length-1].click();return 'ok';}var d=all.filter(function(e){return /导出/.test(e.innerText||'')&&(e.innerText||'').length<8;});if(d.length){d[0].click();return 'ok2';}return 'notfound';}catch(e){return 'err';}})()"""
        private const val JS_CLICK_CONFIRM = """(function(){try{var all=Array.prototype.slice.call(document.querySelectorAll('button,a,span,div'));var c=all.filter(function(e){var t=(e.innerText||'').trim();return t==='确定'||t==='确认';});if(c.length){c[c.length-1].click();return 'ok';}return 'none';}catch(e){return 'err';}})()"""
    }
}

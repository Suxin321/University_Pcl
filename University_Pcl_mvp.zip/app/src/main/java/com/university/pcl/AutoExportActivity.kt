package com.university.pcl

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.university.pcl.data.Prefs
import com.university.pcl.data.ScheduleRepository
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.json.JSONTokener

/**
 * 自动获取课表：
 * 1. 打开「学期理论课表」（设置里粘贴的地址 > 自动从主页菜单解析 > 默认候选）；
 * 2. 跨 iframe 扫描「导出」按钮/链接，能直接拿到导出链接就直接下载，否则自动点击；
 * 3. 拦截网络请求里的导出下载，用 Cookie 下载 .xls -> 解析 -> 替换缓存；
 * 4. 从页面读学期/周次做校准（周次也可由系统日期+校历推算）。
 */
class AutoExportActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var webView: WebView
    private lateinit var status: TextView
    private var captured = false
    private var started = false
    private var rounds = 0
    private var inspectAttempts = 0

    private val exportRegex = Regex("""(?i)(\.xls|daochu|export|excel|kbdow|kbdoc)""")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        CookieManager.getInstance().setAcceptCookie(true)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val hint = TextView(this).apply {
            text = "正在打开「学期理论课表」：会自动找「导出」并接住下载。若卡住，可点「复制当前地址」发我，或到设置里粘贴课表页地址。"
            textSize = 12f
            setPadding(28, 28, 28, 10)
        }
        status = TextView(this).apply {
            text = "准备中…"
            textSize = 11f
            setTextColor(Color.parseColor("#3482FF"))
            setPadding(28, 0, 28, 10)
        }
        webView = WebView(this)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val retry = Button(this).apply {
            text = "重新尝试"
            setOnClickListener {
                captured = false
                rounds = 0
                inspectAttempts = 0
                setStatus("重新尝试…")
                startLoad()
            }
        }
        val copy = Button(this).apply {
            text = "复制当前地址"
            setOnClickListener {
                val url = webView.url.orEmpty()
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("url", url))
                Toast.makeText(this@AutoExportActivity, "已复制：$url", Toast.LENGTH_LONG).show()
            }
        }
        buttons.addView(retry)
        buttons.addView(copy)

        root.addView(hint)
        root.addView(status)
        root.addView(
            webView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        root.addView(buttons)
        setContentView(root)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = true
            displayZoomControls = false
            userAgentString =
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
        }
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                request?.url?.toString()?.let { noteRequest(it) }
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                request?.url?.toString()?.let { noteRequest(it) }
                return false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.postDelayed({ inspectPage() }, 1500)
            }
        }
        webView.setDownloadListener { url, _, _, _, _ ->
            if (url.startsWith("blob:")) {
                setStatus("导出是前端生成的（blob），抓不到文件。请把这句话发我，我换方案。")
                return@setDownloadListener
            }
            capture(url)
        }

        startLoad()
    }

    private fun startLoad() {
        val theory = prefs.theoryUrl
        if (theory.isNotBlank() && isPageUrl(theory)) {
            load(theory)
            return
        }
        setStatus("正在从教务主页找「学期理论课表」入口…")
        Thread {
            val found = runCatching {
                ScheduleRepository(applicationContext).findTheoryPageUrl()
            }.getOrNull()
            runOnUiThread {
                if (found != null) {
                    prefs.theoryUrl = found
                    load(found)
                } else {
                    load(prefs.baseUrl + "/jsxsd/framework/xsMainV.htmlx")
                }
            }
        }.start()
    }

    private fun isPageUrl(url: String): Boolean {
        val u = url.lowercase()
        if (u.contains(".css") || u.contains(".js") || u.endsWith(".png") || u.endsWith(".jpg")) {
            return false
        }
        return u.contains("/jsxsd/") || u.contains(".do") || u.contains(".htmlx") || u.contains(".jsp")
    }

    private fun load(url: String) {
        started = true
        setStatus("打开：$url")
        webView.loadUrl(url)
    }

    private fun inspectPage() {
        webView.evaluateJavascript(JS_PROBE) { raw ->
            val text = runCatching { JSONTokener(raw).nextValue() as? String }.getOrNull()
            val json = runCatching { JSONObject(text ?: return@evaluateJavascript) }.getOrNull()
                ?: return@evaluateJavascript
            applyPageInfo(json)

            val hrefs = json.optJSONArray("exportHrefs")
            if (hrefs != null && hrefs.length() > 0) {
                val url = hrefs.optString(0)
                if (url.isNotBlank() && !url.startsWith("blob:")) {
                    capture(url)
                    return@evaluateJavascript
                }
            }

            val exportCount = json.optInt("exportCount", 0)
            val hasTheoryLink = json.optBoolean("hasTheoryLink", false)
            when {
                exportCount > 0 -> {
                    setStatus("找到「导出」按钮，点击中…")
                    webView.evaluateJavascript(JS_CLICK_EXPORT) { }
                    webView.postDelayed({ webView.evaluateJavascript(JS_CLICK_CONFIRM) { } }, 1500)
                }
                hasTheoryLink && rounds < 2 -> {
                    rounds++
                    setStatus("当前是菜单页，点进「学期理论课表」…")
                    webView.evaluateJavascript(JS_CLICK_THEORY) { }
                    webView.postDelayed({ inspectPage() }, 1800)
                }
                inspectAttempts < 4 -> {
                    inspectAttempts++
                    setStatus("页面加载中，等待导出按钮…（第 $inspectAttempts 次）")
                    webView.postDelayed({ inspectPage() }, 1600)
                }
                else -> {
                    setStatus(
                        "没找到「导出」。页面：${json.optString("title")}\n" +
                            "地址：${json.optString("url")}\n" +
                            "点下方「复制当前地址」发我，或在设置里粘贴「学期理论课表」页面地址。"
                    )
                }
            }
        }
    }

    private fun applyPageInfo(json: JSONObject) {
        val parts = ArrayList<String>()
        parts += "页面：${json.optString("title")}"
        val term = json.optString("term", "")
        if (term.isNotBlank()) {
            prefs.term = term
            parts += "学期：$term"
        }
        val week = json.optString("zc", "").toIntOrNull()
            ?: json.optString("weekText", "").toIntOrNull()
        if (week != null && week in 1..30) {
            prefs.week = week
            parts += "第 $week 周"
        }
        setStatus(parts.joinToString(" | "))
    }

    private fun noteRequest(url: String) {
        if (captured || !started) return
        if (url.startsWith("data:") || url.startsWith("blob:")) return
        if (url.contains(".css") || url.contains(".js")) return
        if (!exportRegex.containsMatchIn(url)) return
        capture(url)
    }

    private fun capture(url: String) {
        if (captured) return
        captured = true
        setStatus("捕获导出地址，下载解析中…\n$url")
        val cookie = CookieManager.getInstance().getCookie(prefs.baseUrl).orEmpty()
        if (cookie.isNotBlank()) prefs.cookies = cookie
        Thread {
            val result = runBlocking {
                ScheduleRepository(applicationContext).downloadXlsFromUrl(url)
            }
            runOnUiThread {
                result.onSuccess { cache ->
                    Toast.makeText(this, "自动获取成功：${cache.items.size} 条课程（第 ${cache.week} 周）", Toast.LENGTH_LONG).show()
                    setResult(RESULT_OK)
                    finish()
                }.onFailure { error ->
                    setStatus("下载/解析失败：${error.message}\n可手动点「导出」再试，或把地址发我。")
                    captured = false
                }
            }
        }.start()
    }

    private fun setStatus(text: String) {
        status.text = text
    }

    override fun onPause() {
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onDestroy() {
        runCatching {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }

    companion object {
        private const val JS_PROBE = """(function(){
try{
  function docs(){var o=[];function w(x){try{o.push(x.document);for(var i=0;i<x.frames.length;i++)w(x.frames[i]);}catch(e){}}w(window);return o;}
  var ds=docs();
  var out={title:document.title||'',url:location.href||'',frames:ds.length,exportCount:0,exportHrefs:[],hasTheoryLink:false,zc:'',term:'',weekText:''};
  function textOf(e){var r=[];try{r.push((e.innerText||e.textContent||'').trim());}catch(x){}try{r.push((e.value||'').toString().trim());}catch(x){}try{r.push((e.getAttribute('title')||e.getAttribute('aria-label')||'').trim());}catch(x){}return r;}
  ds.forEach(function(d){
    try{
      var zc=d.querySelector('select[name=zc]');
      if(zc&&zc.selectedIndex>=0&&zc.options[zc.selectedIndex]&&!out.zc){out.zc=zc.options[zc.selectedIndex].value;}
      var t=d.querySelector('select[name=xnxq01id]');
      if(t&&t.selectedIndex>=0&&t.options[t.selectedIndex]&&!out.term){out.term=t.options[t.selectedIndex].value;}
      var body=d.body?d.body.innerText:'';
      var m=body.match(/第\s*(\d{1,2})\s*周/); if(m&&!out.weekText){out.weekText=m[1];}
      var els=[].slice.call(d.querySelectorAll('a,button,span,div,li,td,input'));
      els.forEach(function(e){
        var cand=textOf(e);
        for(var k=0;k<cand.length;k++){var s=cand[k];if(!s)continue;if(s==='导出'||s==='导出课表'||(s.length<8&&/导出/.test(s))){out.exportCount++;break;}}
        try{if(/学期理论课表/.test((e.innerText||'').trim()))out.hasTheoryLink=true;}catch(x){}
        var href='';try{href=e.href||e.getAttribute('href')||'';}catch(x){}
        if(href&&/daochu|export|\.xls|kbdow|kbdoc/i.test(href)&&out.exportHrefs.length<5){out.exportHrefs.push(href);}
      });
    }catch(x){}
  });
  return JSON.stringify(out);
}catch(e){return JSON.stringify({title:'',url:'',exportCount:0,exportHrefs:[],hasTheoryLink:false});}
})()"""
        private const val JS_CLICK_EXPORT = """(function(){
try{
  function docs(){var o=[];function w(x){try{o.push(x.document);for(var i=0;i<x.frames.length;i++)w(x.frames[i]);}catch(e){}}w(window);return o;}
  var all=[];docs().forEach(function(d){all=all.concat([].slice.call(d.querySelectorAll('a,button,span,div,li,td,input')));});
  var ex=all.filter(function(e){var s='';try{s=(e.innerText||e.textContent||e.value||'').trim();}catch(x){}return s==='导出'||s==='导出课表'||(s.length<8&&/导出/.test(s));});
  if(ex.length){ex[ex.length-1].click();return 'ok';}return 'none';
}catch(e){return 'err';}
})()"""
        private const val JS_CLICK_CONFIRM = """(function(){
try{
  function docs(){var o=[];function w(x){try{o.push(x.document);for(var i=0;i<x.frames.length;i++)w(x.frames[i]);}catch(e){}}w(window);return o;}
  var all=[];docs().forEach(function(d){all=all.concat([].slice.call(d.querySelectorAll('button,a,span,div')));});
  var ok=all.filter(function(e){var s=(e.innerText||'').trim();return s==='确定'||s==='确认';});
  if(ok.length){ok[ok.length-1].click();return 'ok';}return 'none';
}catch(e){return 'err';}
})()"""
        private const val JS_CLICK_THEORY = """(function(){
try{
  function docs(){var o=[];function w(x){try{o.push(x.document);for(var i=0;i<x.frames.length;i++)w(x.frames[i]);}catch(e){}}w(window);return o;}
  var all=[];docs().forEach(function(d){all=all.concat([].slice.call(d.querySelectorAll('a,button,span,div,li,td')));});
  var th=all.filter(function(e){return /学期理论课表/.test((e.innerText||'').trim());});
  if(th.length){th[0].click();return 'ok';}return 'none';
}catch(e){return 'err';}
})()"""
    }
}

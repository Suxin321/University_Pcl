package com.university.pcl

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.university.pcl.data.Prefs
import com.university.pcl.data.ScheduleRepository
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.json.JSONTokener

/**
 * 自动获取课表：
 * 1. 打开「学期理论课表」页面（桌面 UA + 多候选地址）；
 * 2. 从页面里读出当前学期/周次（用于自动校准「第几周」）；
 * 3. 自动点「导出」，拦截导出的下载请求 -> 用 Cookie 下载 .xls -> 解析 -> 替换缓存；
 * 4. 捕获到的导出地址会保存，之后「刷新」直接自动下载。
 */
class AutoExportActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var webView: WebView
    private lateinit var status: TextView
    private var captured = false
    private var candidateIndex = 0
    private var pageRounds = 0

    private val candidates = listOf(
        "/jsxsd/xskb/xskb_list.do?Ves632DSdyV=NEW_XSD_XKB",
        "/jsxsd/xskb/xskb_list.do",
        "/jsxsd/framework/xsMainV.htmlx"
    )
    private val exportRegex = Regex("""(?i)(\.xls|daochu|daochu_|export|excel|kbdow|kbdoc)""")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        CookieManager.getInstance().setAcceptCookie(true)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val hint = TextView(this).apply {
            text = "正在打开「学期理论课表」：会自动点「导出」并把下载抓下来。\n如果自动没成功，你手动点一下页面里的「导出」也可以，下载会被接管。"
            textSize = 12f
            setPadding(28, 28, 28, 10)
        }
        status = TextView(this).apply {
            text = "准备中…"
            textSize = 11f
            setTextColor(Color.parseColor("#3482FF"))
            setPadding(28, 0, 28, 10)
        }
        webView = WebView(this)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        val retry = Button(this).apply {
            text = "重新尝试自动导出"
            setOnClickListener {
                setStatus("重新尝试…")
                loadCandidate()
            }
        }

        root.addView(hint)
        root.addView(status)
        root.addView(
            webView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        root.addView(retry)
        setContentView(root)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            useWideViewPort = true
            loadWithOverviewMode = true
            builtInZoomControls = true
            displayZoomControls = false
            userAgentString =
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
        }
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val url = request?.url?.toString().orEmpty()
                if (url.isNotEmpty()) noteRequest(url)
                return super.shouldInterceptRequest(view, request)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val url = request?.url?.toString().orEmpty()
                if (url.isNotEmpty()) noteRequest(url)
                return false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.postDelayed({ inspectPage() }, 1200)
            }
        }
        webView.setDownloadListener { url, _, _, _, _ ->
            if (url.startsWith("blob:")) {
                setStatus("导出是前端生成的（blob），暂时抓不到文件。\n请把这句话告诉我，我换方案。")
                return@setDownloadListener
            }
            capture(url)
        }

        loadCandidate()
    }

    private fun loadCandidate() {
        pageRounds = 0
        val path = candidates[candidateIndex % candidates.size]
        candidateIndex++
        setStatus("打开：$path")
        webView.loadUrl(prefs.baseUrl + path)
    }

    private fun inspectPage() {
        webView.evaluateJavascript(JS_PROBE) { raw ->
            val text = runCatching {
                JSONTokener(raw).nextValue() as? String
            }.getOrNull() ?: return@evaluateJavascript
            val json = runCatching { JSONObject(text) }.getOrNull() ?: return@evaluateJavascript
            applyPageInfo(json)

            val exportCount = json.optInt("exportCount", 0)
            val hasTheoryLink = json.optBoolean("hasTheoryLink", false)
            if (exportCount > 0) {
                setStatus("找到「导出」按钮，正在点击…")
                webView.evaluateJavascript(JS_CLICK_EXPORT) { }
                webView.postDelayed({ webView.evaluateJavascript(JS_CLICK_CONFIRM) { } }, 1500)
            } else if (hasTheoryLink && pageRounds < 1) {
                pageRounds++
                setStatus("没有导出按钮，尝试点进「学期理论课表」…")
                webView.evaluateJavascript(JS_CLICK_THEORY) { }
            } else if (pageRounds < 1) {
                pageRounds++
                webView.postDelayed({ loadCandidate() }, 800)
            } else {
                setStatus("没找到导出按钮。若你已登录，请手动点页面里的「导出」；否则先登录。")
            }
        }
    }

    private fun applyPageInfo(json: JSONObject) {
        val weekText = json.optString("weekText", "")
        val zc = json.optString("zc", "")
        val term = json.optString("term", "")
        val parts = ArrayList<String>()
        parts += "页面：${json.optString("title", "")}"
        if (term.isNotBlank()) {
            prefs.term = term
            parts += "学期：$term"
        }
        val week = zc.toIntOrNull() ?: weekText.toIntOrNull()
        if (week != null && week in 1..30) {
            prefs.week = week
            parts += "周次：第 $week 周"
        }
        setStatus(parts.joinToString(" | "))
    }

    private fun noteRequest(url: String) {
        if (captured) return
        if (!exportRegex.containsMatchIn(url)) return
        if (url.startsWith("data:") || url.startsWith("blob:")) return
        if (url.contains(".css") || url.contains(".js")) return
        capture(url)
    }

    private fun capture(url: String) {
        if (captured) return
        captured = true
        setStatus("捕获导出地址，正在下载解析…\n$url")
        val cookie = CookieManager.getInstance().getCookie(prefs.baseUrl).orEmpty()
        if (cookie.isNotBlank()) prefs.cookies = cookie
        Thread {
            val result = runBlocking {
                ScheduleRepository(applicationContext).downloadXlsFromUrl(url)
            }
            runOnUiThread {
                result.onSuccess { cache ->
                    Toast.makeText(this, "自动获取成功：${cache.items.size} 条课程（第 ${cache.week} 周）", Toast.LENGTH_LONG).show()
                    setResult(RESULT_OK)
                    finish()
                }.onFailure { error ->
                    setStatus("下载/解析失败：${error.message}\n可以手动点「导出」再试，或把这段发我。")
                    captured = false
                }
            }
        }.start()
    }

    private fun setStatus(text: String) {
        status.text = text
    }

    override fun onPause() {
        CookieManager.getInstance().flush()
        super.onPause()
    }

    override fun onDestroy() {
        runCatching {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }

    companion object {
        private const val JS_PROBE = """(function(){try{var out={title:document.title||'',url:location.href||''};var zc=document.querySelector('select[name=zc]');if(zc&&zc.selectedIndex>=0&&zc.options[zc.selectedIndex]){out.zc=zc.options[zc.selectedIndex].value;}var t=document.querySelector('select[name=xnxq01id]');if(t&&t.selectedIndex>=0&&t.options[t.selectedIndex]){out.term=t.options[t.selectedIndex].value;}var body=document.body?document.body.innerText:'';var m=body.match(/第\s*(\d{1,2})\s*周/);if(m){out.weekText=m[1];}var els=[].slice.call(document.querySelectorAll('a,button,span,div,li'));var ex=els.filter(function(e){var s=(e.innerText||'').trim();return s==='导出'||s==='导出课表'||(s.length<8&&/导出/.test(s));});out.exportCount=ex.length;var th=els.filter(function(e){return /学期理论课表/.test((e.innerText||'').trim());});out.hasTheoryLink=th.length>0;return JSON.stringify(out);}catch(e){return JSON.stringify({title:'',url:'',exportCount:0,hasTheoryLink:false});}})()"""
        private const val JS_CLICK_EXPORT = """(function(){try{var els=[].slice.call(document.querySelectorAll('a,button,span,div,li'));var ex=els.filter(function(e){var s=(e.innerText||'').trim();return s==='导出'||s==='导出课表'||(s.length<8&&/导出/.test(s));});if(ex.length){ex[ex.length-1].click();return 'ok';}return 'none';}catch(e){return 'err';}})()"""
        private const val JS_CLICK_CONFIRM = """(function(){try{var els=[].slice.call(document.querySelectorAll('button,a,span,div'));var ok=els.filter(function(e){var s=(e.innerText||'').trim();return s==='确定'||s==='确认'||s==='导出';});if(ok.length){ok[ok.length-1].click();return 'ok';}return 'none';}catch(e){return 'err';}})()"""
        private const val JS_CLICK_THEORY = """(function(){try{var els=[].slice.call(document.querySelectorAll('a,button,span,div,li'));var th=els.filter(function(e){return /学期理论课表/.test((e.innerText||'').trim());});if(th.length){th[0].click();return 'ok';}return 'none';}catch(e){return 'err';}})()"""
    }
}

package com.university.pcl.ui.browser

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.university.pcl.data.BrowserBookmark
import com.university.pcl.data.BrowserDownloadEntry
import com.university.pcl.data.BrowserHistoryEntry
import com.university.pcl.data.BrowserSettings
import com.university.pcl.data.BrowserUrls
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 浏览器内部的四个二级页（书签 / 历史 / 下载 / 设置）。 */
enum class BrowserPage { Bookmarks, History, Downloads, Settings }

private val SITE_COLORS = listOf(
    Color(0xFF3482FF), Color(0xFFF59E0B), Color(0xFF10B981), Color(0xFFEF4444),
    Color(0xFF8B5CF6), Color(0xFFEC4899), Color(0xFF0EA5E9), Color(0xFF64748B)
)

private fun seedColor(seed: String): Color {
    var hash = 0
    seed.forEach { hash = hash * 31 + it.code }
    return SITE_COLORS[((hash % SITE_COLORS.size) + SITE_COLORS.size) % SITE_COLORS.size]
}

private data class QuickSite(val name: String, val url: String, val color: Color)

private val QUICK_SITES = listOf(
    QuickSite("百度", "https://www.baidu.com", Color(0xFF2932E1)),
    QuickSite("B 站", "https://www.bilibili.com", Color(0xFFFB7299)),
    QuickSite("知乎", "https://www.zhihu.com", Color(0xFF1772F6)),
    QuickSite("GitHub", "https://github.com", Color(0xFF24292F)),
    QuickSite("微博", "https://m.weibo.cn", Color(0xFFE6162D)),
    QuickSite("淘宝", "https://www.taobao.com", Color(0xFFFF5000)),
    QuickSite("网易云", "https://music.163.com", Color(0xFFC20C0C)),
    QuickSite("校园网", "https://www.sdust.edu.cn", Color(0xFF10B981))
)

/* ============================ 新标签页 ============================ */

@Composable
fun BrowserHomePage(
    engine: String,
    recent: List<BrowserHistoryEntry>,
    onSearch: (String) -> Unit,
    onOpen: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(20.dp))
        Text(
            text = "浏览",
            fontSize = 27.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(16.dp))

        Surface(
            shape = RoundedCornerShape(23.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SearchGlyph(muted)
                Spacer(Modifier.width(8.dp))
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = {
                        if (query.isNotBlank()) {
                            onSearch(query)
                            query = ""
                        }
                    }),
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    modifier = Modifier.weight(1f),
                    decorationBox = { inner ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (query.isEmpty()) {
                                Text("搜索或输入网址", color = muted, style = MaterialTheme.typography.bodyLarge)
                            }
                            inner()
                        }
                    }
                )
            }
        }

        Spacer(Modifier.height(18.dp))
        QUICK_SITES.chunked(4).forEach { chunk ->
            Row(Modifier.fillMaxWidth()) {
                chunk.forEach { site ->
                    QuickSiteTile(site, Modifier.weight(1f)) { onOpen(site.url) }
                }
                repeat(4 - chunk.size) { Spacer(Modifier.weight(1f)) }
            }
            Spacer(Modifier.height(4.dp))
        }

        if (recent.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            Text("最近访问", fontSize = 12.sp, color = muted, modifier = Modifier.padding(start = 2.dp))
            Spacer(Modifier.height(8.dp))
            Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface) {
                Column {
                    recent.take(6).forEach { entry ->
                        BrowserListRow(
                            title = entry.title.ifBlank { BrowserUrls.displayUrl(entry.url) },
                            subtitle = BrowserUrls.displayUrl(entry.url),
                            color = seedColor(entry.url),
                            onClick = { onOpen(entry.url) }
                        )
                    }
                }
            }
        }
        Spacer(Modifier.height(28.dp))
        Text(
            text = "搜索引擎：$engine · 全部数据只存在本机",
            fontSize = 11.sp,
            color = muted,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Spacer(Modifier.height(18.dp))
    }
}

/** 画一个放大镜（避免引入 material-icons-extended）。 */
@Composable
private fun SearchGlyph(color: Color) {
    Canvas(modifier = Modifier.size(16.dp)) {
        val radius = size.minDimension * 0.30f
        val center = Offset(size.width * 0.42f, size.height * 0.42f)
        drawCircle(
            color = color,
            radius = radius,
            center = center,
            style = Stroke(width = 1.8.dp.toPx())
        )
        drawLine(
            color = color,
            start = Offset(center.x + radius * 0.72f, center.y + radius * 0.72f),
            end = Offset(size.width * 0.92f, size.height * 0.92f),
            strokeWidth = 1.8.dp.toPx(),
            cap = StrokeCap.Round
        )
    }
}

@Composable
private fun QuickSiteTile(site: QuickSite, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(15.dp))
                .background(site.color),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = site.name.take(1),
                color = Color.White,
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = site.name,
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/* ============================ 通用行 / 头部 ============================ */

@Composable
private fun BrowserListRow(
    title: String,
    subtitle: String,
    color: Color,
    onClick: () -> Unit,
    trailing: (@Composable () -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(color),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = title.take(1).uppercase(),
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (trailing != null) {
            Spacer(Modifier.width(6.dp))
            trailing()
        }
    }
}

@Composable
private fun BrowserSubHeader(
    title: String,
    onBack: () -> Unit,
    trailing: (@Composable () -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 4.dp, end = 12.dp, top = 4.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .clickable(onClick = onBack),
            contentAlignment = Alignment.Center
        ) {
            Text("‹", fontSize = 27.sp, color = MaterialTheme.colorScheme.onSurface)
        }
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.weight(1f)
        )
        trailing?.invoke()
    }
}

@Composable
private fun EmptyHint(text: String) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
    }
}

private fun formatTime(millis: Long): String =
    SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(millis))

/* ============================ 书签 ============================ */

@Composable
fun BrowserBookmarksPage(
    items: List<BrowserBookmark>,
    onOpen: (BrowserBookmark) -> Unit,
    onDelete: (BrowserBookmark) -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        BrowserSubHeader("书签", onBack)
        if (items.isEmpty()) {
            EmptyHint("还没有书签。打开网页后点地址栏右边的星标即可收藏。")
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(items, key = { it.id }) { item ->
                    BrowserListRow(
                        title = item.title.ifBlank { BrowserUrls.displayUrl(item.url) },
                        subtitle = BrowserUrls.displayUrl(item.url),
                        color = seedColor(item.url),
                        onClick = { onOpen(item) },
                        trailing = {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .clickable { onDelete(item) },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("×", fontSize = 18.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    )
                }
            }
        }
    }
}

/* ============================ 历史 ============================ */

@Composable
fun BrowserHistoryPage(
    items: List<BrowserHistoryEntry>,
    onOpen: (BrowserHistoryEntry) -> Unit,
    onClear: () -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        BrowserSubHeader("历史记录", onBack, trailing = {
            Text(
                text = "清空",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable(onClick = onClear)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            )
        })
        if (items.isEmpty()) {
            EmptyHint("暂无历史记录。无痕模式下访问的网页不会保存在这里。")
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(items, key = { it.url + it.visitedAt }) { item ->
                    BrowserListRow(
                        title = item.title.ifBlank { BrowserUrls.displayUrl(item.url) },
                        subtitle = "${BrowserUrls.displayUrl(item.url)} · ${formatTime(item.visitedAt)}",
                        color = seedColor(item.url),
                        onClick = { onOpen(item) }
                    )
                }
            }
        }
    }
}

/* ============================ 下载 ============================ */

@Composable
fun BrowserDownloadsPage(
    items: List<BrowserDownloadEntry>,
    onClear: () -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        BrowserSubHeader("下载", onBack, trailing = {
            Text(
                text = "清空",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable(onClick = onClear)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            )
        })
        if (items.isEmpty()) {
            EmptyHint("暂无下载。网页触发下载后，会交给系统下载器并显示在这里。")
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                items(items, key = { it.id }) { item ->
                    BrowserListRow(
                        title = item.name,
                        subtitle = "${BrowserUrls.displayUrl(item.url)} · ${item.status}",
                        color = seedColor(item.name),
                        onClick = {}
                    )
                }
            }
        }
    }
}

/* ============================ 浏览器设置 ============================ */

@Composable
fun BrowserSettingsPage(
    settings: BrowserSettings,
    blockedCount: Int,
    onChange: (BrowserSettings) -> Unit,
    onClearData: () -> Unit,
    onBack: () -> Unit
) {
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            BrowserSubHeader("浏览器设置", onBack)
        }

        item {
            Column(Modifier.fillMaxWidth()) {
                Text(
                    "搜索引擎",
                    fontSize = 12.sp,
                    color = muted,
                    modifier = Modifier.padding(start = 18.dp, top = 14.dp, bottom = 8.dp)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    BrowserUrls.engines.forEach { engine ->
                        FilterChip(
                            selected = settings.searchEngine == engine,
                            onClick = { onChange(settings.copy(searchEngine = engine)) },
                            label = { Text(engine, fontSize = 12.5.sp) }
                        )
                    }
                }
            }
        }

        item {
            Column(Modifier.fillMaxWidth()) {
                SectionLabel("浏览")
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .padding(horizontal = 16.dp)
                        .fillMaxWidth()
                ) {
                    Column {
                        BrowserToggleRow(
                            title = "广告拦截",
                            subtitle = "本地规则，不联网 · 本次已拦 $blockedCount 项",
                            checked = settings.adBlock,
                            onCheckedChange = { onChange(settings.copy(adBlock = it)) }
                        )
                        BrowserToggleRow(
                            title = "桌面版网站",
                            subtitle = "按电脑版排版显示（全局生效）",
                            checked = settings.desktopMode,
                            onCheckedChange = { onChange(settings.copy(desktopMode = it)) }
                        )
                        BrowserToggleRow(
                            title = "深色网页",
                            subtitle = "让网页内容跟随系统深色（Android 13+）",
                            checked = settings.forceDark,
                            onCheckedChange = { onChange(settings.copy(forceDark = it)) }
                        )
                        BrowserToggleRow(
                            title = "默认无痕",
                            subtitle = "新建标签页默认无痕，不记录历史",
                            checked = settings.defaultIncognito,
                            onCheckedChange = { onChange(settings.copy(defaultIncognito = it)) }
                        )
                    }
                }
            }
        }

        item {
            Column(Modifier.fillMaxWidth()) {
                SectionLabel("数据与隐私")
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .padding(horizontal = 16.dp)
                        .fillMaxWidth()
                ) {
                    Column {
                        BrowserInfoRow("系统返回键", "先网页后退，再回主页，最后回课表页，不退出 App")
                        BrowserInfoRow("网站权限", "定位 / 相机 / 麦克风默认拒绝，可在系统设置里放开")
                        BrowserInfoRow("数据存储", "书签 / 历史 / 设置只存在本机，不上传")
                    }
                }
                OutlinedButton(
                    onClick = onClearData,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Text("清除浏览数据（历史 / 下载记录 / Cookie）", fontSize = 13.sp)
                }
            }
        }

        item {
            Column(Modifier.fillMaxWidth()) {
                SectionLabel("关于")
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier
                        .padding(horizontal = 16.dp)
                        .fillMaxWidth()
                ) {
                    Column {
                        BrowserInfoRow("版本", "University_Pcl 1.1.0 · 浏览页")
                        BrowserInfoRow("内核", "系统 WebView（Chromium），跟随系统更新")
                    }
                }
                Spacer(Modifier.height(28.dp))
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        fontSize = 12.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 18.dp, top = 22.dp, bottom = 8.dp)
    )
}

@Composable
private fun BrowserToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.width(10.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun BrowserInfoRow(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 11.dp)) {
        Text(title, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface)
        Text(
            subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

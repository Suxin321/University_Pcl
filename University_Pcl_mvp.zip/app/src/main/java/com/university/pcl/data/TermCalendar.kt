package com.university.pcl.data

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters

/**
 * 周次自动判断：优先用手填的开学日期；没填时按内置校历/学期规则近似推算，
 * 这样「第几周」可以由系统日期自动算出，不依赖教务页面。
 */
object TermCalendar {

    // 已知学期第 1 周周一（精确值优先）
    private val exactStarts = mapOf(
        "2026-2027-1" to "2026-08-31",
        "2025-2026-1" to "2025-09-01",
        "2025-2026-2" to "2026-02-23",
        "2024-2025-2" to "2025-02-24"
    )

    fun startOf(term: String): String? {
        val key = term.trim()
        if (key.isEmpty()) return null
        exactStarts[key]?.let { return it }
        return runCatching {
            val parts = key.split("-")
            if (parts.size < 3) return null
            val year = parts[0].toInt()
            val half = parts[2].toInt()
            val anchor = if (half == 2) LocalDate.of(year + 1, 2, 15) else LocalDate.of(year, 8, 25)
            anchor.with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY)).toString()
        }.getOrNull()
    }
}

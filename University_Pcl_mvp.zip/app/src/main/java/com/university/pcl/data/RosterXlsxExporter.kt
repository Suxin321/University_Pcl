package com.university.pcl.data

import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * 导出值班表 .xlsx（仿照「新媒体第13周j14值班表」的结构）：
 * - 每周一张「第N周值班表」：A 列值班时间，后面是周一~周日的名字；
 * - 最后一张「值班次数统计」：A 列「序号. 姓名」，C 列次数。
 *
 * 纯手写 OOXML（inline string，不依赖 jxl 的写功能，也不涉及 java.awt），Android 可直接跑。
 */
object RosterXlsxExporter {

    fun fileName(startWeek: Int, endWeek: Int): String =
        if (startWeek >= endWeek) "第${startWeek}周值班表.xlsx" else "第${startWeek}-${endWeek}周值班表.xlsx"

    /** 值班时间显示成「8：00-9：50」（全角冒号、12 小时制），和样本一致。 */
    fun dutyTimeLabel(raw: String): String {
        val text = raw.trim()
        if (text.isEmpty()) return ""
        val m = Regex("""^(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})$""").find(text) ?: return text
        val startHour = m.groupValues[1].toIntOrNull() ?: return text
        val startMinute = m.groupValues[2]
        val endHour = m.groupValues[3].toIntOrNull() ?: return text
        val endMinute = m.groupValues[4]
        fun hour12(hour: Int): Int {
            val h = ((hour % 24) + 24) % 24
            return if (h % 12 == 0) 12 else h % 12
        }
        return "${hour12(startHour)}：$startMinute-${hour12(endHour)}：$endMinute"
    }

    fun buildRoster(
        shifts: List<DutyShift>,
        startWeek: Int,
        endWeek: Int,
        days: List<Int>,
        sections: List<Int>,
        slotTimes: List<String>,
        members: List<String>,
        adjust: Map<String, Int>
    ): ByteArray {
        val start = startWeek.coerceAtLeast(1)
        val end = endWeek.coerceAtLeast(start)
        val dayList = (if (days.isEmpty()) (1..5).toList() else days).distinct().sorted()
        val sectionList = (if (sections.isEmpty()) (1..BigSections.COUNT).toList() else sections)
            .filter { it in 1..BigSections.COUNT }.distinct().sorted()
        val byWeek = shifts.groupBy { it.week }

        val sheets = ArrayList<Sheet>()
        for (week in start..end) {
            val slots = byWeek[week].orEmpty().associateBy { it.day to it.bigSection }
            val rows = ArrayList<List<Cell>>()
            rows.add(listOf(Cell.Text("")) + dayList.map { Cell.Text(Weekdays.long[it - 1]) })
            for (big in sectionList) {
                val row = ArrayList<Cell>()
                row.add(Cell.Text(dutyTimeLabel(slotTimes.getOrElse(big - 1) { "" })))
                for (day in dayList) {
                    val names = slots[day to big]?.names.orEmpty()
                    row.add(Cell.Text(if (names.isEmpty()) "" else names.joinToString("、")))
                }
                rows.add(row)
            }
            sheets.add(Sheet("第${week}周值班表", rows))
        }

        val counts = HashMap<String, Int>()
        shifts.forEach { shift ->
            if (shift.week in start..end) {
                shift.names.forEach { name -> counts[name] = (counts[name] ?: 0) + 1 }
            }
        }
        val statRows = ArrayList<List<Cell>>()
        val memberList = if (members.isEmpty()) counts.keys.toList() else members
        memberList.forEachIndexed { index, name ->
            val total = (counts[name] ?: 0) + (adjust[name] ?: 0)
            statRows.add(listOf(Cell.Text("${index + 1}. $name"), Cell.Text(""), Cell.Number(total)))
        }
        sheets.add(Sheet("值班次数统计", statRows))

        return buildWorkbook(sheets)
    }

    // ---------- OOXML ----------

    private sealed class Cell {
        data class Text(val value: String) : Cell()
        data class Number(val value: Int) : Cell()
    }

    private data class Sheet(val name: String, val rows: List<List<Cell>>)

    private fun buildWorkbook(sheets: List<Sheet>): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            zip.writeEntry("[Content_Types].xml", contentTypes(sheets.size))
            zip.writeEntry("_rels/.rels", rootRels())
            zip.writeEntry("xl/workbook.xml", workbookXml(sheets))
            zip.writeEntry("xl/_rels/workbook.xml.rels", workbookRels(sheets.size))
            sheets.forEachIndexed { index, sheet ->
                zip.writeEntry("xl/worksheets/sheet${index + 1}.xml", sheetXml(sheet))
            }
        }
        return out.toByteArray()
    }

    private fun ZipOutputStream.writeEntry(path: String, content: String) {
        putNextEntry(ZipEntry(path))
        write(content.toByteArray(Charsets.UTF_8))
        closeEntry()
    }

    private fun contentTypes(sheetCount: Int): String {
        val overrides = (1..sheetCount).joinToString("") {
            "<Override PartName=\"/xl/worksheets/sheet$it.xml\" " +
                "ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
$overrides
</Types>"""
    }

    private fun rootRels(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>"""

    private fun workbookXml(sheets: List<Sheet>): String {
        val items = sheets.mapIndexed { index, sheet ->
            "<sheet name=\"${xmlEscape(sheet.name.take(31))}\" sheetId=\"${index + 1}\" r:id=\"rId${index + 1}\"/>"
        }.joinToString("")
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets>$items</sheets>
</workbook>"""
    }

    private fun workbookRels(sheetCount: Int): String {
        val items = (1..sheetCount).joinToString("") {
            "<Relationship Id=\"rId$it\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet$it.xml\"/>"
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
$items
</Relationships>"""
    }

    private fun sheetXml(sheet: Sheet): String {
        val maxCols = sheet.rows.maxOfOrNull { it.size } ?: 1
        val cols = buildString {
            append("<cols>")
            for (c in 1..maxCols) {
                val width = if (c == 1) 14 else 12
                append("<col min=\"$c\" max=\"$c\" width=\"$width\" customWidth=\"1\"/>")
            }
            append("</cols>")
        }
        val rowsXml = buildString {
            sheet.rows.forEachIndexed { rowIndex, row ->
                append("<row r=\"${rowIndex + 1}\">")
                row.forEachIndexed { colIndex, cell ->
                    val ref = columnLetter(colIndex) + (rowIndex + 1)
                    when (cell) {
                        is Cell.Text -> append(
                            "<c r=\"$ref\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${xmlEscape(cell.value)}</t></is></c>"
                        )
                        is Cell.Number -> append("<c r=\"$ref\"><v>${cell.value}</v></c>")
                    }
                }
                append("</row>")
            }
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
$cols
<sheetData>$rowsXml</sheetData>
</worksheet>"""
    }

    private fun columnLetter(index: Int): String {
        var n = index
        val sb = StringBuilder()
        while (n >= 0) {
            sb.insert(0, ('A' + n % 26))
            n = n / 26 - 1
        }
        return sb.toString()
    }

    private fun xmlEscape(text: String): String = buildString {
        text.forEach { ch ->
            when (ch) {
                '&' -> append("&amp;")
                '<' -> append("&lt;")
                '>' -> append("&gt;")
                '"' -> append("&quot;")
                '\'' -> append("&apos;")
                else -> if (ch.code < 32 && ch != '\t' && ch != '\n' && ch != '\r') Unit else append(ch)
            }
        }
    }
}

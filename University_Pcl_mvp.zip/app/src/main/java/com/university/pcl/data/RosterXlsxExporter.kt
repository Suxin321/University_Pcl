package com.university.pcl.data

import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * 导出值班表 .xlsx（仿照「新媒体第13周j14值班表」的结构）：
 * - 每周一张「第N周值班表」：A 列值班时间，后面是周一~周日的名字；
 * - 最后一张「值班次数统计」：A 列「序号. 姓名」，C 列次数。
 *
 * 手写标准 OOXML（sharedStrings + styles + docProps），手机上各种预览器（WPS / 文件管理器 /
 * 微信内置预览）都能正常显示；不依赖 jxl 写功能，也不涉及 java.awt。
 */
object RosterXlsxExporter {

    fun fileName(startWeek: Int, endWeek: Int): String =
        if (startWeek >= endWeek) "第${startWeek}周值班表.xlsx" else "第${startWeek}-${endWeek}周值班表.xlsx"

    /** 值班时间显示成「8：00-9：50」（全角冒号、12 小时制），和样本一致。 */
    fun dutyTimeLabel(raw: String): String {
        val text = raw.trim()
        if (text.isEmpty()) return ""
        val m = Regex("""^(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})$""").find(text) ?: return text
        val startHour = m.groupValues[1].toIntOrNull() ?: return text
        val startMinute = m.groupValues[2]
        val endHour = m.groupValues[3].toIntOrNull() ?: return text
        val endMinute = m.groupValues[4]
        fun hour12(hour: Int): Int {
            val h = ((hour % 24) + 24) % 24
            return if (h % 12 == 0) 12 else h % 12
        }
        return "${hour12(startHour)}：$startMinute-${hour12(endHour)}：$endMinute"
    }

    fun buildRoster(
        shifts: List<DutyShift>,
        startWeek: Int,
        endWeek: Int,
        days: List<Int>,
        sections: List<Int>,
        slotTimes: List<String>,
        members: List<String>,
        adjust: Map<String, Int>
    ): ByteArray {
        val start = startWeek.coerceAtLeast(1)
        val end = endWeek.coerceAtLeast(start)
        val dayList = (if (days.isEmpty()) (1..5).toList() else days).distinct().sorted()
        val sectionList = (if (sections.isEmpty()) (1..BigSections.COUNT).toList() else sections)
            .filter { it in 1..BigSections.COUNT }.distinct().sorted()
        val byWeek = shifts.groupBy { it.week }

        val sheets = ArrayList<Sheet>()
        val header = ArrayList<Cell>()
        header.add(Cell.Text(""))
        dayList.forEach { header.add(Cell.Text(Weekdays.long[it - 1])) }
        for (week in start..end) {
            val slots = byWeek[week].orEmpty().associateBy { it.day to it.bigSection }
            val rows = ArrayList<List<Cell>>()
            rows.add(header)
            for (big in sectionList) {
                val row = ArrayList<Cell>()
                row.add(Cell.Text(dutyTimeLabel(slotTimes.getOrElse(big - 1) { "" })))
                for (day in dayList) {
                    val names = slots[day to big]?.names.orEmpty()
                    row.add(Cell.Text(if (names.isEmpty()) "" else names.joinToString("、")))
                }
                rows.add(row)
            }
            sheets.add(Sheet("第${week}周值班表", rows))
        }

        val counts = HashMap<String, Int>()
        shifts.forEach { shift ->
            if (shift.week in start..end) {
                shift.names.forEach { name -> counts[name] = (counts[name] ?: 0) + 1 }
            }
        }
        val statRows = ArrayList<List<Cell>>()
        val memberList = if (members.isEmpty()) counts.keys.toList() else members
        memberList.forEachIndexed { index, name ->
            val total = (counts[name] ?: 0) + (adjust[name] ?: 0)
            statRows.add(listOf(Cell.Text("${index + 1}. $name"), Cell.Text(""), Cell.Number(total)))
        }
        sheets.add(Sheet("值班次数统计", statRows))

        return buildWorkbook(sheets)
    }

    // ---------- OOXML ----------

    private sealed class Cell {
        data class Text(val value: String) : Cell()
        data class Number(val value: Int) : Cell()
    }

    private data class Sheet(val name: String, val rows: List<List<Cell>>)

    private fun buildWorkbook(sheets: List<Sheet>): ByteArray {
        // 先收集共享字符串，再用 sharedStrings 引用（比 inlineStr 兼容性更好）
        val sharedStrings = LinkedHashMap<String, Int>()
        fun intern(text: String): Int = sharedStrings.getOrPut(text) { sharedStrings.size }

        val sheetXmlList = sheets.map { sheetXml(it, ::intern) }
        val sheetCount = sheets.size
        val sharedIndex = sheetCount + 1
        val stylesIndex = sheetCount + 2

        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            zip.writeEntry("[Content_Types].xml", contentTypes(sheetCount))
            zip.writeEntry("_rels/.rels", rootRels())
            zip.writeEntry("xl/workbook.xml", workbookXml(sheets))
            zip.writeEntry("xl/_rels/workbook.xml.rels", workbookRels(sheetCount, sharedIndex, stylesIndex))
            zip.writeEntry("xl/styles.xml", stylesXml())
            zip.writeEntry("xl/sharedStrings.xml", sharedStringsXml(sharedStrings.keys.toList()))
            sheetXmlList.forEachIndexed { index, xml ->
                zip.writeEntry("xl/worksheets/sheet${index + 1}.xml", xml)
            }
            zip.writeEntry("docProps/core.xml", corePropsXml())
            zip.writeEntry("docProps/app.xml", appPropsXml(sheets))
        }
        return out.toByteArray()
    }

    private fun ZipOutputStream.writeEntry(path: String, content: String) {
        putNextEntry(ZipEntry(path))
        write(content.toByteArray(Charsets.UTF_8))
        closeEntry()
    }

    private fun contentTypes(sheetCount: Int): String {
        val overrides = (1..sheetCount).joinToString("") {
            "<Override PartName=\"/xl/worksheets/sheet$it.xml\" " +
                "ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>
<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
$overrides
</Types>"""
    }

    private fun rootRels(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>"""

    private fun workbookXml(sheets: List<Sheet>): String {
        val items = sheets.mapIndexed { index, sheet ->
            "<sheet name=\"${xmlEscape(sheet.name.take(31))}\" sheetId=\"${index + 1}\" r:id=\"rId${index + 1}\"/>"
        }.joinToString("")
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets>$items</sheets>
</workbook>"""
    }

    private fun workbookRels(sheetCount: Int, sharedIndex: Int, stylesIndex: Int): String {
        val items = StringBuilder()
        for (index in 1..sheetCount) {
            items.append(
                "<Relationship Id=\"rId$index\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" " +
                    "Target=\"worksheets/sheet$index.xml\"/>"
            )
        }
        items.append(
            "<Relationship Id=\"rId$sharedIndex\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings\" " +
                "Target=\"sharedStrings.xml\"/>"
        )
        items.append(
            "<Relationship Id=\"rId$stylesIndex\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" " +
                "Target=\"styles.xml\"/>"
        )
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
$items
</Relationships>"""
    }

    private fun stylesXml(): String = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="2">
<font><sz val="11"/><name val="宋体"/></font>
<font><b/><sz val="11"/><name val="宋体"/></font>
</fonts>
<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>
<borders count="1"><border/></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="2">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>
</cellXfs>
</styleSheet>"""

    private fun sharedStringsXml(list: List<String>): String {
        val items = list.joinToString("") { text ->
            "<si><t xml:space=\"preserve\">${xmlEscape(text)}</t></si>"
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="${list.size}" uniqueCount="${list.size}">$items</sst>"""
    }

    private fun corePropsXml(): String {
        val now = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US)
            .format(java.util.Date())
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
<dc:creator>University_Pcl</dc:creator>
<cp:lastModifiedBy>University_Pcl</cp:lastModifiedBy>
<dcterms:created xsi:type="dcterms:W3CDTF">$now</dcterms:created>
<dcterms:modified xsi:type="dcterms:W3CDTF">$now</dcterms:modified>
</cp:coreProperties>"""
    }

    private fun appPropsXml(sheets: List<Sheet>): String {
        val titles = sheets.joinToString("") { "<vt:lpstr>${xmlEscape(it.name)}</vt:lpstr>" }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties" xmlns:vt="http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes">
<Application>University_Pcl</Application>
$titles
</Properties>"""
    }

    private fun sheetXml(sheet: Sheet, intern: (String) -> Int): String {
        val maxCols = sheet.rows.maxOfOrNull { it.size } ?: 1
        val maxRows = sheet.rows.size
        val cols = buildString {
            append("<cols>")
            for (c in 1..maxCols) {
                val width = if (c == 1) 14 else 12
                append("<col min=\"$c\" max=\"$c\" width=\"$width\" customWidth=\"1\"/>")
            }
            append("</cols>")
        }
        val rowsXml = buildString {
            sheet.rows.forEachIndexed { rowIndex, row ->
                append("<row r=\"${rowIndex + 1}\">")
                row.forEachIndexed { colIndex, cell ->
                    val ref = columnLetter(colIndex) + (rowIndex + 1)
                    // 第 1 行（表头）加粗
                    val styleAttr = if (rowIndex == 0) " s=\"1\"" else ""
                    when (cell) {
                        is Cell.Text -> append("<c r=\"$ref\"$styleAttr t=\"s\"><v>${intern(cell.value)}</v></c>")
                        is Cell.Number -> append("<c r=\"$ref\"$styleAttr><v>${cell.value}</v></c>")
                    }
                }
                append("</row>")
            }
        }
        return """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<dimension ref="A1:${columnLetter(maxCols - 1)}$maxRows"/>
$cols
<sheetData>$rowsXml</sheetData>
</worksheet>"""
    }

    private fun columnLetter(index: Int): String {
        var n = index
        val sb = StringBuilder()
        while (n >= 0) {
            sb.insert(0, ('A' + n % 26))
            n = n / 26 - 1
        }
        return sb.toString()
    }

    private fun xmlEscape(text: String): String = buildString {
        text.forEach { ch ->
            when (ch) {
                '&' -> append("&amp;")
                '<' -> append("&lt;")
                '>' -> append("&gt;")
                '"' -> append("&quot;")
                '\'' -> append("&apos;")
                else -> if (ch.code < 32 && ch != '\t' && ch != '\n' && ch != '\r') Unit else append(ch)
            }
        }
    }
}

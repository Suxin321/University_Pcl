package com.university.pcl.data

/** 把排班导出成文字（值班表），用于复制 / 分享到群里。 */
object RosterExporter {

    /**
     * 生成「第 N 周值班表」文字。
     *
     * 每个时段一行：`周一 1-2节：张三、李四`；没人可排的时段写 `—`。
     */
    fun text(
        shifts: List<DutyShift>,
        startWeek: Int,
        endWeek: Int,
        days: List<Int>,
        bigCount: Int = BigSections.COUNT
    ): String {
        val start = startWeek.coerceAtLeast(1)
        val end = endWeek.coerceAtLeast(start)
        val dayList = days.ifEmpty { (1..5).toList() }
        val byWeek = shifts.groupBy { it.week }
        val sb = StringBuilder()
        for (week in start..end) {
            if (week > start) sb.append('\n')
            sb.append("第 ").append(week).append(" 周值班表\n")
            val slotMap = byWeek[week].orEmpty().associateBy { it.day to it.bigSection }
            for (day in dayList) {
                for (big in 1..bigCount) {
                    val names = slotMap[day to big]?.names.orEmpty()
                    sb.append(Weekdays.long.getOrElse(day - 1) { "周$day" })
                        .append(' ')
                        .append(BigSections.shortLabels.getOrElse(big - 1) { "$big" })
                        .append("节：")
                        .append(if (names.isEmpty()) "—" else names.joinToString("、"))
                        .append('\n')
                }
            }
        }
        return sb.toString().trimEnd()
    }
}

package com.university.pcl.widget

import android.appwidget.AppWidgetManager
import android.content.Context
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver

class ScheduleWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = ScheduleWidget()

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        super.onUpdate(context, appWidgetManager, appWidgetIds)
        // 每次系统让组件更新（添加组件 / 应用更新 / 重启等）都确保自动刷新调度还在，
        // 避免用户装完新版本后每分钟刷新没有挂上。
        WidgetRefreshScheduler.ensureScheduled(context.applicationContext)
    }
}

# University_Pcl - MVP 未开启混淆
-keep class com.university.pcl.data.** { *; }

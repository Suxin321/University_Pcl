# 第二轮聚焦复审（只读，不再重复第一轮已通过项）

> 复审对象：本轮 12 处改动（`data/CacheStore.kt`、`data/QiangzhiParser.kt`、`data/ScheduleRepository.kt`、`widget/RefreshWorker.kt`、`widget/WidgetRefreshScheduler.kt`、`widget/WidgetUpdater.kt`、`widget/ScheduleWidget.kt`、`LoginActivity.kt`、`MainActivity.kt`、`res/values-night/themes.xml`、`app/src/test/.../QiangzhiParserTest.kt`、`gradle/wrapper/gradle-wrapper.properties`）+ `app/build.gradle.kts` 新增的 `testImplementation`。
> 方式：全文件重读 + 逐条推演；本机无 bash/JDK/Android SDK，**仍未执行构建与测试**，结论为静态推演。

## 结论

- **🔴 必错：无。** 本轮改动没有引入新的编译错误（import / 语法 / API 签名 / 作用域 / 空安全均通过）。
- **测试断言：没有会失败的用例。** 8 个 `QiangzhiParserTest` 用例按新 parser 实现逐条推演全部通过（"1-16周(1-2节)"、"(单)"、"(双)"、节次优先于行号、多课拆分、空格子都覆盖到了）。
- 另有 2 处 🟠（条件触发，不阻断编译）与 6 条 🟡，见下。

---

## 🔴 必错（本轮）：无

逐文件核对记录（确认「没有编译错误」的依据）：

| 文件 | 核对点 | 结论 |
|---|---|---|
| `data/CacheStore.kt` | `load()` 改块体后无非局部 return；`clear()` 语法/`runCatching` 在块体内使用 | ✅ |
| `data/QiangzhiParser.kt` | `Regex` 字面量合法（`[-,~]`、`[-,~～]`、非捕获组）；`sectionInWeekText.find(...)?.groupValues?.get(1)?.toIntOrNull()?.let{} ?: rowFallback` 类型为 Int；`substringBefore("(")`/`replace`/`findAll().forEach` + `return@forEach` 合法 | ✅ |
| `data/ScheduleRepository.kt` | 删掉 `if (items.isEmpty()) throw` 后 `runCatching` 末表达式仍为 `ScheduleCache` | ✅ |
| `widget/RefreshWorker.kt` | `return try { ... } finally { ... }` 为合法表达式体；`finally` 内 suspend 调用（`WidgetUpdater.update`）在 suspend fun 中合法；`when { ... }` 各分支均 `Result` | ✅ |
| `widget/WidgetRefreshScheduler.kt` | 新增 `import androidx.work.Constraints` / `NetworkType` 存在；`PeriodicWorkRequest.Builder.setConstraints(Constraints)` 返回自身可继续 `.build()`；`enqueueUniquePeriodicWork(name, policy, request)` 签名匹配 | ✅ |
| `widget/WidgetUpdater.kt` | `import kotlin.coroutines.cancellation.CancellationException`（Kotlin ≥1.4 标准库 typealias，Kotlin 2.0.21 可用）；catch 顺序（Cancellation → Exception）合法，`catch (_: Exception)` 合法；`throw e` 合法 | ✅ |
| `widget/ScheduleWidget.kt` | 新增 `import Prefs/WeekUtil` 存在且被使用；`currentWeek(context)` 为类内私有成员、在 `withContext{ }` 中经隐式 `this` 调用合法；`todaySlots(cache: ScheduleCache?, week: Int): List<com.university.pcl.data.CourseSlot>` 返回类型与 `filter{}.orEmpty()` 一致；`FullContent(cache, week, night, openApp)` / `CompactContent(...)` 调用与四处声明（含两个 `@Composable` 调用点）参数个数/顺序/类型全部一致；无残留旧签名调用 | ✅ |
| `LoginActivity.kt` | `setAcceptThirdPartyCookies(webView, true)`（API 21+）；`collectCookies()` 里 `mapNotNull{getCookie}`→`flatMap`→`map`→`filter`→`distinctBy`→`joinToString` 类型链正确；`onPause` override 合法 | ✅ |
| `MainActivity.kt` | 新增 `import CacheStore` 且被使用；`onSave` lambda 4 个参数与 `SettingsContent.onSave: (url, term, week, semesterStart)` 顺序一致、赋值映射正确（`term=newTerm`、`week=newWeek`）；在 lambda 中调用局部函数 `refresh()`（作用域内已声明）合法；`scope.launch { WidgetUpdater.update(context) }` 合法；`onLogout` 中 `CacheStore(context).clear()` 合法 | ✅ |
| `res/values-night/themes.xml` | `Theme.UniversityPcl` 同名 + night 限定符是标准覆盖（不是重复资源）；父样式 `android:Theme.Material.NoActionBar` 为框架内置深色主题；`#242424` 合法颜色 | ✅ |
| `app/src/test/.../QiangzhiParserTest.kt` | 包名 `com.university.pcl` 与目录一致；`org.junit.*` 依赖已由新增 `testImplementation("junit:junit:4.13.2")` 提供；`StringBuilder`/`vararg List<String>`/`List(7){...}`/`assertEquals(Pair, Pair)` 重载解析均合法；测试只依赖 Jsoup 与纯 Kotlin 数据类，**不需要 Robolectric/Android 运行时** | ✅ |
| `gradle/wrapper/gradle-wrapper.properties` | `networkTimeout=60000` 是 wrapper 支持的键 | ✅ |

---

## 🟠 很可能错（不阻断编译，但本轮改动可能在真机上「看起来修了、其实没生效」）

### 1. `widget/WidgetRefreshScheduler.kt:24-30` — `KEEP` 会让「新增联网约束」在已有安装上不生效

**问题**：`enqueueUniquePeriodicWork(PERIODIC_WORK, ExistingPeriodicWorkPolicy.KEEP, ...)` 的语义是「已存在同名 work 就保留旧的」。任何**之前装过本 App 的设备**（开发机一定装过第一轮 APK）上，`pcl_periodic_refresh` 这条 6h 周期 work 已经存在（旧版没有联网约束），`KEEP` 会保留旧请求 → **本轮加的 `setConstraints(CONNECTED)` 永远不生效**，无网时照样白跑并重试，和改动前的行为一样。

**修复**（改周期/约束时应更新已有 work）：

```kotlin
WorkManager.getInstance(context).enqueueUniquePeriodicWork(
    PERIODIC_WORK,
    ExistingPeriodicWorkPolicy.UPDATE,   // 用 UPDATE 而不是 KEEP，新约束/周期才会替换旧 work
    PeriodicWorkRequestBuilder<RefreshWorker>(6, TimeUnit.HOURS)
        .setConstraints(constraints)
        .build()
)
```

### 2. `widget/RefreshWorker.kt:28-32` — `finally` 里先 `update` 后 `scheduleDaily`，协程被取消时仍会断日更链

**问题**：本轮目标就是「任何路径都重排下一天 00:05」。但 `finally` 第一句 `WidgetUpdater.update(applicationContext)` 是 suspend 且内部会重新抛出 `CancellationException`；一旦 worker 被系统停止（force-stop / 约束变化 / 进程被杀后 coroutine 取消），`update` 在第一个挂起点就抛 `CancellationException`，**后面的 `WidgetRefreshScheduler.scheduleDaily(...)` 不会执行**，日更链还是会断（要靠下次打开 App 的 `ensureScheduled` 才恢复）。概率不高，但正好是本次修复想兜住的那类路径。

**修复**（无副作用的调度放前面；组件刷新放 try 里兜住）：

```kotlin
} finally {
    // 先排下一天（非 suspend，不会被取消打断）
    WidgetRefreshScheduler.scheduleDaily(applicationContext)
    // 组件刷新是"尽力而为"，失败/取消都不影响上面的重排
    try {
        WidgetUpdater.update(applicationContext)
    } catch (e: kotlinx.coroutines.CancellationException) {
        throw e
    } catch (_: Exception) {
        // 忽略
    }
}
```

---

## 🟡 建议（本轮改动相关）

1. **`QiangzhiParser.kt:85`**：`substringBefore("(")` 只对「周次后面带括号」的格式安全。若真机上 `font[title='周次(节次)']` 的文本是**无括号**但带节次的写法（如 `1-16周 1-2节`、`1-16周1-2节`），`head` 会变成 `1-161-2节`，`weekRange` 取到 `1-161` → `weeks = 1..161`（过滤形同失效）。建议改为先按「周」截断，并给周次加上限做兜底：

   ```kotlin
   val head = normalized.substringBefore("周").ifBlank { normalized.substringBefore("(") }
       .replace(" ", "")
   ...
   for (week in from..to) if (week in 1..30) weeks.add(week)
   // single 分支同理：if (from <= 30) weeks.add(from)
   ```

   并补一个用例：`parseWeekText("1-16周1-2节")` 期望 `(1..16) to 0`，而不是 1..161。

2. **`.github/workflows/android.yml:28-29`**：新增了单元测试，但 CI 只跑 `assembleDebug`，而 **`assembleDebug` 不会编译/运行 `src/test`**，测试写错也发现不了。建议加一步（可与构建合并）：

   ```yaml
   - name: Build & unit test
     run: ./gradlew assembleDebug testDebugUnitTest --stacktrace --no-daemon
   ```

3. **`app/src/test/.../QiangzhiParserTest.kt`**：建议补 3 个用例，覆盖本轮最容易回归的点：
   - 合并节次：`courseCell(..., "1-16周(3-5节)", ...)` → 大节应为 **2**（取首节 3 → 2），而不是按 3-5 的末节或行号；
   - 只有节次、周次缺失：`"1-2节"` → `weeks == emptyList` 且 `bigSection == 1`（走节次分支）；
   - `parseWeekText("第1-16周")`（带「第」前缀）→ `(1..16) to 0`（当前实现能过，但没锁定）。

4. **`LoginActivity.kt:87-101` + `Prefs.kt:12-16`**：本轮 `collectCookies()` 用了 4 个由 `prefs.baseUrl` 拼出的 URL。若用户在设置里把地址清空/填成不带 scheme 的字符串（`Prefs.baseUrl` 的 getter 只兜底 null，不兜底空串与非法值），`getCookie`/`loadUrl` 行为不可预期。建议 getter 兜底 + 登录前校验：

   ```kotlin
   // Prefs
   get() = (sp.getString(KEY_BASE_URL, DEFAULT_URL) ?: DEFAULT_URL).takeIf { it.isNotBlank() } ?: DEFAULT_URL

   // LoginActivity.onCreate，加载前
   val base = prefs.baseUrl
   if (!(base.startsWith("http://") || base.startsWith("https://"))) {
       Toast.makeText(this, "教务地址需以 http(s):// 开头，请到设置里修改", Toast.LENGTH_LONG).show()
       finish(); return
   }
   ```

5. **`MainActivity.kt:163-170`**：`message = "设置已保存"` 之后立刻 `refresh()`，而 `refresh()` 内部第一句就是 `message = null`，保存反馈实际看不到（未登录分支则一直停在「设置已保存」，行为不一致）。建议把刷新提示合并成一句，例如 `message = "设置已保存，正在同步…"`，失败时由 `onFailure` 覆盖；或 `refresh()` 增加参数 `silent = true`。

6. **`widget/WidgetUpdater.kt:14`**：吞掉异常但不落日志，组件刷新失败（Glance/RemoteViews 兼容问题正是本项目最大风险之一）时无任何线索。建议在 catch 里加 `Log.w("WidgetUpdater", "updateAll failed", e)`（`import android.util.Log`），便于真机排查 HyperOS 上的组件不刷新问题。

---

## 第一轮 🔴 与主要 🟠 的修复确认（本轮已核对生效）

- `data/CacheStore.kt` 表达式体 return → **已改块体，编译错误消除**；`clear()` 已加。
- `data/QiangzhiParser.kt` 周次解析 → **"1-16周(1-2节)" 现在得到 (1..16)+parity 0**；大节改为节次优先、行号回退，且 `parseWeekText` 对 `(单)/(双)` 的 parity 在截断前从完整串判断，未被截断破坏。
- `data/ScheduleRepository.kt` 空课表 → **不再抛错，照常写缓存**。
- `widget/RefreshWorker.kt` → 成功/失败/未登录都会走 `finally` 重排（仅剩上面 🟠2 的取消路径）。
- `widget/ScheduleWidget.kt` → 周次改为渲染时用 `Prefs+WeekUtil` 现算，`FullContent/CompactContent` 新签名与调用点全部对齐。
- `LoginActivity.kt` → Cookie 多路径合并 + 具体路径优先 + 第三方 Cookie + `onPause` flush，逻辑正确。
- `MainActivity.kt` → 保存设置后按新设置 `refresh()`（登录态）或清 `cache` 刷组件（未登录态）；退出登录清磁盘缓存 + 刷组件，均正确。
- `values-night/themes.xml` → 合法，暗色启动背景不再闪白。

# University_Pcl MVP 静态审查报告（未编译）

> 审查方式：`read`/`grep` 全量通读 16 个 `.kt`、全部 Gradle 脚本、Manifest、res、wrapper、CI；本机无 bash/JDK/Android SDK（沙箱后端不可用），**未执行任何构建**，结论来自逐行阅读 + 固定版本 API 知识。
> 范围：`/sdcard/Dsh_project/University_Pcl`。本次只审查、未改任何源码。
> 版本基线：AGP 8.7.3 / Gradle 8.9 / Kotlin 2.0.21 / compose-bom 2024.10.01 / Glance 1.1.1 / work-runtime-ktx 2.9.1 / OkHttp 4.12.0 / Jsoup 1.18.1 / kotlinx-serialization-json 1.7.3 / minSdk 26 / compileSdk 35 / JDK 17。

---

## 结论速览

| 档位 | 数量 | 说明 |
|---|---|---|
| 🔴 必错（编译/资源失败） | **1** | `data/CacheStore.kt:14-15`：表达式体函数里出现 `return`，Kotlin 直接编译失败 |
| 🟠 很可能错（运行崩溃/逻辑错） | 7 | Cookie 取不全、空课表当失败、日更 Work 链会断、保存设置不重拉、退出登录不清缓存、大节/周次归一化假设风险、组件跨周显示陈旧 |
| 🟡 建议 | 15 | 构建加固、主线程 IO、Lifecycle 刷新、图标/主题、Work 约束、错误吞掉等 |

**其余所有项（Gradle DSL、插件 id、wrapper、Manifest 与 `@xxx/yyy` 引用、Glance 1.1.1 包名与符号、Compose BOM API、Jsoup/OkHttp/WorkManager/kotlinx.serialization 调用、`Modifier.weight` 作用域、`getOrNull`/`toIntOrNull` 边界）已逐项核对，未发现别的确定阻断项**——清单见文末「已核对通过」，这是审查结论而不是遗漏。

---

## 🔴 必错（编译/资源失败）

### 1. `data/CacheStore.kt:13-17` — 表达式体函数里 `return`，编译报错

**问题**：`load()` 是**表达式体函数**（`fun load(): ScheduleCache? = runCatching { ... }`），而 `runCatching` 是 `inline`，块里的 `return null` 是**非局部返回**（返回给 `load()`）。Kotlin 不允许表达式体函数里出现 `return`，报：

```
error: returns are not allowed for functions with expression body. Use block body in '{...}'
```

即 `RETURN_IN_FUNCTION_WITH_EXPRESSION_BODY`，`assembleDebug` 必然停在 `:app:compileDebugKotlin`。

**现状代码**：

```kotlin
fun load(): ScheduleCache? = runCatching {
    if (!file.exists()) return null          // ← 编译错误
    json.decodeFromString(ScheduleCache.serializer(), file.readText())
}.getOrNull()
```

**修复（推荐：改块体）**：

```kotlin
fun load(): ScheduleCache? {
    if (!file.exists()) return null
    return runCatching {
        json.decodeFromString(ScheduleCache.serializer(), file.readText())
    }.getOrNull()
}
```

**修复（备选：保留表达式体，用局部返回）**：

```kotlin
fun load(): ScheduleCache? = runCatching {
    if (!file.exists()) return@runCatching null
    json.decodeFromString(ScheduleCache.serializer(), file.readText())
}.getOrNull()
```

---

## 🟠 很可能错（运行崩溃/逻辑错）

### 1. `LoginActivity.kt:72` — Cookie 只按根路径取，会漏掉 `Path=/jsxsd` 的会话 Cookie

**问题**：`CookieManager.getCookie(prefs.baseUrl)` 按 URL 的 **path** 过滤（根路径 `/` 只返回 path 为 `/` 的 Cookie）。强智的 `JSESSIONID` 通常带 `Path=/jsxsd`（CAS 还涉及 `my.sdust.edu.cn` 域）。结果是：用户明明登录成功，却可能只存到 `bzb_njw`/`SERVERID_gld`，之后 OkHttp 请求 `/jsxsd/xskb/xskb_list.do` 被当未登录 → 永远「登录已过期，请重新登录」。另外 WebView 默认不接受第三方 Cookie，CAS 域跳转场景可能登录失败。

**修复**（多 URL 合并 + 去重，并开启第三方 Cookie）：

```kotlin
// onCreate() 里、webView 创建后加：
CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

// completeLogin() 改为：
private fun collectCookies(): String {
    val cm = CookieManager.getInstance()
    return listOf(
        prefs.baseUrl,
        prefs.baseUrl + "/jsxsd/",
        prefs.baseUrl + "/jsxsd/xskb/xskb_list.do"
    ).mapNotNull { cm.getCookie(it) }
        .flatMap { it.split(";") }
        .map { it.trim() }
        .filter { it.contains('=') }
        .distinctBy { it.substringBefore('=') }
        .joinToString("; ")
}
```

### 2. `data/ScheduleRepository.kt:60-61` — 空课表被当成「失败」

**问题**：`if (items.isEmpty()) throw IOException("未解析到课程...")`。假期、空白周、或接口对某周返回空表时，这是**合法结果**，但代码会：① 不写缓存（组件/界面继续显示很旧的周次）；② 让 `RefreshWorker` 走失败重试；③ 用户看到「未解析到课程，请检查学期/周次设置」，被误导去改设置。

**修复**（空列表照常落缓存，只在日志里提示）：

```kotlin
val items = QiangzhiParser.parse(body)
// 空课表是合法结果（假期/空周），不要当失败
val cache = ScheduleCache(System.currentTimeMillis(), term, week, items)
cacheStore.save(cache)
prefs.term = term
prefs.lastSync = cache.fetchedAt
cache
```

### 3. `widget/RefreshWorker.kt:17、25-30` + `WidgetRefreshScheduler.kt:28-36` — 每天 00:05 的日更链会断

**问题**：跨天刷新是一条「OneTimeWork 跑完再排下一天」的链。但 worker 在以下路径**直接 return，不再调用 `scheduleDaily`**：① 未登录（`:17`）；② 失败且 `runAttemptCount >= 2` 走 success 分支（`:25-30`，只更新组件不重排）；③ 异常退出。链条一断，就只能等用户下次打开 App 时 `ensureScheduled()` 才恢复——而 HyperOS 上「打开 App」本身就不保证，属于最坏组合：**跨天后组件长期显示昨天的课表**。

**修复**（`finally` 里必排下一天；成功路径也保留）：

```kotlin
override suspend fun doWork(): Result {
    return try {
        val prefs = Prefs(applicationContext)
        if (!prefs.isLoggedIn) return Result.success()

        val result = ScheduleRepository(applicationContext).refresh()
        if (result.isSuccess) {
            WidgetUpdater.update(applicationContext)
            Result.success()
        } else if (runAttemptCount < 2) {
            Result.retry()
        } else {
            WidgetUpdater.update(applicationContext)
            Result.success()
        }
    } finally {
        // 无论成功 / 失败 / 未登录，都重排下一天 00:05，避免日更链断掉
        WidgetRefreshScheduler.scheduleDaily(applicationContext)
    }
}
```

（更稳的做法：日更改用 `PeriodicWorkRequestBuilder<RefreshWorker>(1, TimeUnit.DAYS)` + `ExistingPeriodicWorkPolicy.UPDATE`，失败不会断链，代价是「00:05 准点」变成随 Doze 漂移。）

### 4. `MainActivity.kt:155-163` — 保存设置后不按新设置重新拉取（需求「设置保存后端内状态刷新」未实现）

**问题**：`onSave` 只写了 `prefs`、`term`、`week`，**没有清缓存/重新请求**；`cache` 仍是旧学期/旧周次的数据，`lastSync`、桌面组件也都不变。用户改完学期/周次后必须再手动点「刷新」，否则看到的是旧数据，且 `week` 与 `cache.week` 不一致，过滤结果会「看起来对但其实是上一周」。

**修复**：

```kotlin
onSave = { url, newTerm, newWeek, semesterStart ->
    prefs.baseUrl = url
    prefs.term = newTerm
    prefs.week = newWeek
    prefs.semesterStart = semesterStart
    term = newTerm
    week = repo.currentWeek()
    message = "设置已保存"
    if (prefs.isLoggedIn) {
        refresh()                       // 按新设置立即重拉（refresh() 在同作用域内可用）
    } else {
        cache = null
        scope.launch { WidgetUpdater.update(context) }
    }
},
```

### 5. `MainActivity.kt:167-171` — 退出登录不清缓存/组件，桌面组件继续显示旧课表

**问题**：`prefs.clearSession()` 只清 Cookie + lastSync，**内存里的 `cache`、磁盘 `cache.json`、桌面组件**都还在。退出登录后组件仍展示课程 + 地点（隐私问题），且下次未登录也不会被覆盖。

**修复**：给 `CacheStore` 加 `clear()`，退出时调用并刷新组件。

```kotlin
// data/CacheStore.kt 追加：
fun clear() {
    runCatching { if (file.exists()) file.delete() }
}

// MainActivity.onLogout：
onLogout = {
    prefs.clearSession()
    CacheStore(context).clear()
    cache = null
    lastSync = 0L
    loggedIn = false
    message = "已清除登录状态"
    scope.launch { WidgetUpdater.update(context) }
},
```

（需要 `import com.university.pcl.data.CacheStore`。）

### 6. `widget/ScheduleWidget.kt:75、157` — 组件按「缓存时抓取的周次」过滤，跨周后显示陈旧课表

**问题**：`val week = cache?.week ?: 0`，`cache.week` 是**上次抓取时**的周次。周一一到、后台刷新被 HyperOS 冻结（或日更链断了），组件就用上周周次过滤课程 → 单双周课、1-8 周短课全部显示错。App 首页用的是「现算周次」（`HomeContent` 的 `activeWeek`），组件与首页会不一致。

**修复**（组件内现算当前周，与首页统一）：

```kotlin
// ScheduleWidget.provideGlance：
val prefs = Prefs(context.applicationContext)
val cache = withContext(Dispatchers.IO) { CacheStore(context).load() }
val computedWeek = WeekUtil.weekFromStart(prefs.semesterStart)
val week = if (computedWeek > 0) computedWeek else prefs.week.coerceAtLeast(1)
val night = ...
val openApp: Action = actionStartActivity(Intent(context, MainActivity::class.java))
provideContent {
    if (LocalSize.current.height < 200.dp) {
        CompactContent(cache, week, night, openApp)
    } else {
        FullContent(cache, week, night, openApp)
    }
}
```

同时把 `FullContent` / `CompactContent` 的签名从 `cache: ScheduleCache?` 改为 `cache: ScheduleCache?, week: Int`，函数体里删掉 `val week = cache?.week ?: 0`（现状第 75、157 行）。需要 `import com.university.pcl.data.Prefs`、`import com.university.pcl.data.WeekUtil`。

### 7. `data/QiangzhiParser.kt:30`（配合 `:69-101`）— 大节/周次归一化全靠「行号假设」，错位会静默显示错课

**问题 A（大节）**：`val bigSection = (index / 7 / 2 + 1).coerceIn(1, 5)` 假定「`div.kbcontent` 严格 7 列/行、每大节正好 2 小节、无 rowspan」。强智课表的 `rowspan` 合并、`3-5 节` 合并课、加行的作息表都会让 `index/7` 与真实小节错位；而 UI 是 `bigSection == index` 精确过滤（`HomeScreen.kt:146`、`ScheduleWidget.kt:116`），一旦错位就是「把课塞进错误的大节」而不是报错，很难被发现。

**问题 B（周次）**：`parseWeekText` 先 `replace("周","")` 再删括号，若 `font[title='周次(节次)']` 的文本实际带节次（标题名就暗示它同时含「周次(节次)」，如 `1-16周(1-2节)`），处理后会变成 `1-161-2节`，两个正则都匹配不上 → `weeks` 为空 → `activeIn()` 恒 `true`（**所有课每周都显示**，周次/单双周过滤整体失效）。

**修复 A（优先用节次字段，行号只做回退）**：

```kotlin
// parseOne 内（把 bigFallback 从 parse() 传进来）
private fun parseOne(body: Element, day: Int, bigFallback: Int): CourseSlot? {
    val fonts = body.select("font")
    fun fontText(title: String): String =
        fonts.firstOrNull { it.attr("title") == title }?.text()?.trim().orEmpty()
    ...
    val weekText = fontText("周次(节次)")
    val bigFromJieci = Regex("""(\d+)\s*(?:[-,~]\s*\d+)?\s*节""").find(weekText)
        ?.groupValues?.get(1)?.toIntOrNull()
        ?.let { ((it - 1) / 2 + 1).coerceIn(1, BigSections.COUNT) }
    val bigSection = bigFromJieci ?: bigFallback
    ...
}
```

**修复 B（先截出「周」前的周次段再解析）**：

```kotlin
fun parseWeekText(raw: String): Pair<List<Int>, Int> {
    if (raw.isBlank()) return emptyList<Int>() to 0
    val parity = when {
        raw.contains("单") -> 1
        raw.contains("双") -> 2
        else -> 0
    }
    val head = raw.replace('（', '(').replace('）', ')').substringBefore("(") // 丢掉 (单)/(1-2节)
    val weeks = LinkedHashSet<Int>()
    Regex("""(\d+)(?:\s*[-~～]\s*(\d+))?""").findAll(head).forEach { m ->
        val from = m.groupValues[1].toIntOrNull() ?: return@forEach
        val to = m.groupValues[2].toIntOrNull()
        if (to != null && to >= from) for (w in from..to) weeks.add(w) else weeks.add(from)
    }
    return weeks.toList() to parity
}
```

**另外**：`parse()` 入口建议加一行防御日志/断言，真机一跑就能发现结构变化：

```kotlin
val cells = doc.select("div.kbcontent")
require(cells.size % 7 == 0) { "kbcontent=${cells.size}，不是 7 的倍数，强智表格结构可能变了" }
```

---

## 🟡 建议（不阻断编译，但建议改）

1. **`app/build.gradle.kts:32-34` `kotlinOptions`**：Kotlin 2.0 起已弃用（当前 2.0.21 仍可用，只有 warning）。建议提前迁移，避免升 Kotlin 2.2 后报错：
   ```kotlin
   kotlin { compilerOptions { jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17) } }
   ```
2. **`gradlew` / `gradlew.bat` 是手写的最小启动器**（无 `DEFAULT_JVM_OPTS`/`JAVA_OPTS`、无 `APP_HOME` 符号链接处理）。已确认 `gradle-wrapper.jar` 内含 `org/gradle/wrapper/GradleWrapperMain`（能启动），CI 也有 `chmod +x` 兜底；仍建议用 `gradle wrapper --gradle-version 8.9` 重新生成标准脚本，避免以后 GUI/IDE 或 CI 的边角问题。
3. **`gradle/wrapper/gradle-wrapper.properties`**：可加 `distributionSha256Sum`（官方 8.9-bin 的校验和）防下载损坏，非必需。
4. **`MainActivity.kt:55-60` 组合期同步读盘**：`remember { Prefs(context) }`（读 SharedPreferences）和 `repo.cached()`（读 `cache.json`）都在主线程组合阶段执行。文件很小通常没事，但建议：

   ```kotlin
   var cache by remember { mutableStateOf<ScheduleCache?>(null) }
   LaunchedEffect(Unit) { cache = withContext(Dispatchers.IO) { repo.cached() } }
   ```

5. **`MainActivity.kt:103-105` 只在首次组合刷新**：从后台回前台、跨天再打开 App 都不会刷新（需求里的「打开 App 兜底刷新」不完整）。建议用 `LifecycleEventObserver` 监听 `ON_RESUME`（或用 `repeatOnLifecycle(Lifecycle.State.RESUMED)`），超过 N 分钟才刷新，避免频繁打教务系统。
6. **`res/drawable/ic_launcher.xml`**：矢量图直接当 `android:icon` 可编译可运行，但部分启动器会裁切/糊；建议补 `mipmap-anydpi-v26/ic_launcher.xml` 自适应图标（前景+背景色），并在 Manifest 加 `android:roundIcon`。
7. **`res/values/themes.xml:4` `windowBackground=@android:color/white`** + 只有浅色主题：深色模式下启动会闪白（Compose 内部已经是暗色 scheme）。建议加 `res/values-night/themes.xml`，`windowBackground` 用 `#242424`（与 `Theme.kt` 的 `DarkColors.background` 一致）。
8. **`res/xml/network_security_config.xml:11`**：`jwglxt.sdust.edu.cn` 实测 HTTPS 正常，无需放行明文；只保留 `my.sdust.edu.cn`（CAS 的 http 跳转）即可，减小攻击面。
9. **`widget/WidgetRefreshScheduler.kt:20-24`**：6 小时周期任务没加网络约束，无网时会白跑并进重试。建议加：

   ```kotlin
   val constraints = Constraints.Builder()
       .setRequiredNetworkType(NetworkType.CONNECTED)
       .build()
   PeriodicWorkRequestBuilder<RefreshWorker>(6, TimeUnit.HOURS)
       .setConstraints(constraints)
       .build()
   ```
10. **`widget/WidgetUpdater.kt:9`**：`runCatching` 把一切异常（含 `CancellationException`）都吞掉且不落日志，组件刷新失败时完全无感。建议 `catch (e: Exception) { if (e is CancellationException) throw e; Log.w("WidgetUpdater", "updateAll failed", e) }`。同理 `ScheduleRepository` 的 `runCatching` 也会吞掉协程取消。
11. **`widget/ScheduleWidget.kt:13` 显式 `import androidx.glance.action.Action`**：Glance 1.1.1 存在、当前没问题；但可去掉显式类型降低升级风险：`val openApp = actionStartActivity(Intent(context, MainActivity::class.java))`。
12. **组件生命周期**：需求里的「组件被删要取消任务」未实现。可 override `onDisabled(context)`/`onDeleted(...)` 取消 `pcl_periodic_refresh` 与 `pcl_daily_refresh`，省电。
13. **`LoginActivity`**：未处理 WebView 返回栈（网页内按返回直接退出登录流程），建议加返回键先 `webView.canGoBack()/goBack()`；另外 `onPause` 里 `CookieManager.getInstance().flush()` 更保险。
14. **CI（`.github/workflows/android.yml`）**：依赖 `ubuntu-latest` 自带 SDK；为防镜像缺 `platforms;android-35`，可加一步兜底 `android-actions/setup-android@v3` + `sdkmanager "platforms;android-35" "build-tools;35.0.0"`。
15. **`app/src/main/res/xml/widget_schedule_info.xml`**：建议补 `android:previewImage`/`android:previewLayout`，小部件选择器里不会只显示默认加载图；`minHeight="110dp"` 与 `targetCellHeight="4"` 混用不冲突（minHeight 只用于 4×2 的下限），可保留。

---

## 已核对通过（不是遗漏，逐项确认无问题）

- **Gradle**：插件 id（`com.android.application` / `org.jetbrains.kotlin.android` / `...plugin.compose` / `...plugin.serialization`）与根 `build.gradle.kts` 版本 2.0.21 匹配；`namespace`/`applicationId`/`compileSdk 35`/`minSdk 26` 合法；`buildFeatures.compose = true` 配合 Kotlin 2.0 的 compose 插件正确；`packaging { resources { excludes += ... } }` 是 AGP 8 正确 DSL；`settings.gradle.kts` 的 `RepositoriesMode.FAIL_ON_PROJECT_REPOS`（Kotlin DSL 默认导入）与仓库配置正确；wrapper `distributionUrl=gradle-8.9-bin`，jar 内含 `GradleWrapperMain`；依赖坐标/版本均与给定基线一致，Compose 依赖由 BOM 管版本。
- **Manifest / res**：`.MainActivity`/`.LoginActivity`/`.widget.ScheduleWidgetReceiver` 声明与包路径一致；有 intent-filter 的组件都带 `android:exported`；`@drawable/ic_launcher`、`@string/app_name|login_title|widget_label|widget_desc`、`@style/Theme.UniversityPcl`、`@xml/network_security_config`、`@xml/widget_schedule_info` 全部存在；`@layout/glance_default_loading_layout` 由 glance-appwidget 1.1.1 提供；`appwidget-provider` 属性（`description`/`min*`/`targetCell*`/`resizeMode`/`widgetCategory`/`updatePeriodMillis=0`）合法；主题父样式 `android:Theme.Material.Light.NoActionBar` 存在。
- **Glance 1.1.1**：`provideContent`（androidx.glance.appwidget 的 `suspend fun GlanceAppWidget.provideContent` 扩展，已 import、在 `provideGlance` 的 suspend 上下文中调用）；`GlanceAppWidget.provideGlance` override 签名；`updateAll` suspend 扩展；`cornerRadius(Dp)`（androidx.glance.appwidget）；`actionStartActivity(Intent): Action`（androidx.glance.appwidget.action）；`background(ColorProvider)`（androidx.glance）；`ColorProvider`（androidx.glance.unit）；`Text/TextStyle/FontWeight`（androidx.glance.text，只用到 Normal/Medium/Bold）；`Alignment.CenterVertically/Top`、`Row/Column` 的 `horizontalAlignment/verticalAlignment`；`LocalSize.current.height`；`defaultWeight()` 为 RowScope 成员、未 import；`Spacer`/`fillMaxSize`/`fillMaxWidth`/`padding`/`width`/`height` 包名正确；`Text(maxLines=...)` 参数存在。
- **Compose BOM 2024.10.01**：`Scaffold(containerColor/bottomBar)`、`NavigationBar(containerColor)`、`NavigationBarItem`、`Text(fontSize/fontWeight/color/maxLines)`、`TextButton(enabled)`、`OutlinedButton(enabled)`、`OutlinedTextField(label/placeholder/singleLine)`、`HorizontalDivider(modifier/thickness/color)`、`lightColorScheme/darkColorScheme` 的 `surfaceVariant` 等参数、`Typography()`、`Modifier.weight/background(color,shape)/clickable/padding/horizontalScroll/verticalScroll` 全部存在且作用域正确（`weight` 只在 Row 内容 lambda 内用）；`rememberLauncherForActivityResult`、`enableEdgeToEdge` 的包与签名正确。
- **数据层**：`@Serializable` data class 全部字段有默认值 + `Json { ignoreUnknownKeys; encodeDefaults }` + `serializer()` 用法正确；OkHttp 4 的 `okhttp3.HttpUrl.Companion.toHttpUrlOrNull`、`Response.body?.string()`、`execute().use {}` 正确；`runCatching` 里调 suspend（`withContext`/`result.onSuccess` 均为 inline）合法；Jsoup 1.18 的 `Jsoup.parse/parseBodyFragment`、`Element.ownText()/select()/attr()`、`Elements.forEachIndexed` 正确；`String.split(vararg Char)`、`Regex.find`、`MatchResult.groupValues`、`toIntOrNull`/`getOrNull`/`coerceIn` 边界都安全；WorkManager 2.9.1 的 `enqueueUniquePeriodicWork/enqueueUniqueWork/setInitialDelay/CoroutineWorker/runAttemptCount` 正确；`java.time`（minSdk 26 可用）。

---

## 一次编译通过概率

**现状（不改代码）：低。**
理由：`data/CacheStore.kt:14-15` 是**确定的 Kotlin 编译错误**，`assembleDebug` 必停在 `:app:compileDebugKotlin`，与资源/依赖无关。

**修掉上面唯一 🔴 后：中高（约 80%）。**
理由：版本已核实、Gradle DSL/资源引用/Manifest/Glance 1.1.1 符号/Compose BOM API 均逐项对得上，没有发现第二个确定阻断项；残余不确定性只在外界：① Glance 1.1.1 的少量符号签名（`Action`/`clickable` 重载，已知该版本可用，风险低）；② CI runner 是否预装 `platforms;android-35`（可用兜底步骤消除）；③ 真机 HTML 结构与「周次(节次)」文本格式（只影响运行逻辑，不影响编译）。

> 提醒：编译通过 ≠ 能用。上述 🟠 第 1、2、6、7 条一旦在真机命中，表现是「登录了拉不到课表 / 组件显示错课 / 周次过滤失效」，建议编译通过后优先用真实账号 + 真实 HTML 复核。
